/***
  BEGIN LICENSE
	
  Copyright (C) 2011 Mario Guerriero <mefrio.g@gmail.com>	
  This program is free software: you can redistribute it and/or modify it	
  under the terms of the GNU Lesser General Public License version 3, as published	
  by the Free Software Foundation.
	
  This program is distributed in the hope that it will be useful, but	
  WITHOUT ANY WARRANTY; without even the implied warranties of	
  MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR	
  PURPOSE.  See the GNU General Public License for more details.
	
  You should have received a copy of the GNU General Public License along	
  with this program.  If not, see <http://www.gnu.org/licenses/>
  
  END LICENSE	
***/ 


#if SWITCHBOARD      
namespace Alm {
    class AlmPlug : Pantheon.Switchboard.Plug 
     {
  
     	private PrivacyWidget privacy_widget;
     	private Blacklist blacklist;
		   
         public AlmPlug () 
         {
        	blacklist = new Blacklist();
        	privacy_widget = new PrivacyWidget(blacklist);
        	add (privacy_widget);
         }
       
     }

}
#endif

public static int main (string[] args) 
{
    Gtk.init (ref args);

#if SWITCHBOARD 
    var plug = new Alm.AlmPlug ();
    plug.register ("Activity log manager");
    plug.show_all (); 
#endif

    Gtk.main ();
	
    return 0;
}

