/* aide, Advanced Intrusion Detection Environment
 *
 * Copyright (C) 2002,2006 Rami Lehti, Pablo Virolainen, Richard van den
 * Berg
 * $Header$
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _URL_H_INCLUDED
#define _URL_H_INCLUDED

typedef enum {
  url_file, url_stdout, url_stdin, url_stderr, url_fd, url_http,
  url_sql, url_syslog, url_database, url_multiwriter, 
  url_gzip, url_string, url_ftp, url_https, 
  url_unknown
} URL_TYPE;


typedef struct url_t {
  /* Everything before the first ':' */
  URL_TYPE type;
  char* value;
  void* data; /* We might want to pass some list's to multiwriter */ 
} url_t;



#endif
