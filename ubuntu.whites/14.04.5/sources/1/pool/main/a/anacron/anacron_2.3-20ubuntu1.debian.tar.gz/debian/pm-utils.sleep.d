#!/bin/sh

# This script makes anacron jobs start to run when the machine is woken up.
# For a laptop, these are the closest parallels to turning on a desktop.

case $1 in
    resume|thaw)
	start -q anacron || :
	;;
    suspend|hibernate)
	stop -q anacron || :
	;;
esac
