# Dependencies for addresses.$O:
addresses.$O: $(SRC_DIR)/addresses.c
addresses.$O: $(BLD_TOP)config.h
addresses.$O: $(BLD_TOP)forbuild.h
addresses.$O: $(SRC_TOP)prologue.h
addresses.$O: $(SRC_DIR)/addresses.h
addresses.$O: $(SRC_DIR)/log.h
addresses.$O: $(SRC_DIR)/dynld.h
addresses.$O: $(SRC_DIR)/pid.h
addresses.$O: $(SRC_DIR)/program.h

# Dependencies for api_control.$O:
api_control.$O: $(SRC_DIR)/api_control.c
api_control.$O: $(BLD_TOP)config.h
api_control.$O: $(BLD_TOP)forbuild.h
api_control.$O: $(SRC_TOP)prologue.h
api_control.$O: $(SRC_DIR)/log.h
api_control.$O: $(SRC_DIR)/api_control.h
api_control.$O: $(SRC_DIR)/async.h
api_control.$O: $(SRC_DIR)/async_io.h
api_control.$O: $(SRC_DIR)/brl.h
api_control.$O: $(SRC_DIR)/brldefs.h
api_control.$O: $(SRC_DIR)/driver.h
api_control.$O: $(SRC_DIR)/io_generic.h
api_control.$O: $(SRC_DIR)/ktbdefs.h
api_control.$O: $(SRC_DIR)/serialdefs.h
api_control.$O: $(SRC_DIR)/usbdefs.h
api_control.$O: brlapi_constants.h
api_control.$O: $(SRC_DIR)/brlapi_keycodes.h
api_control.$O: $(SRC_DIR)/brltty.h
api_control.$O: $(SRC_DIR)/cmd.h
api_control.$O: $(SRC_DIR)/cmddefs.h
api_control.$O: $(SRC_DIR)/ctb.h
api_control.$O: $(SRC_DIR)/ctbdefs.h
api_control.$O: $(SRC_DIR)/ktb.h
api_control.$O: $(SRC_DIR)/menu.h
api_control.$O: $(SRC_DIR)/pid.h
api_control.$O: $(SRC_DIR)/prefs.h
api_control.$O: $(SRC_DIR)/program.h
api_control.$O: $(SRC_DIR)/scrdefs.h
api_control.$O: $(SRC_DIR)/ses.h
api_control.$O: $(SRC_DIR)/spk.h
api_control.$O: $(SRC_DIR)/spkdefs.h
api_control.$O: $(SRC_DIR)/timing.h
api_control.$O: $(SRC_DIR)/tunedefs.h
api_control.$O: $(SRC_DIR)/tunes.h

# Dependencies for apitest.$O:
apitest.$O: $(SRC_DIR)/apitest.c
apitest.$O: $(BLD_TOP)config.h
apitest.$O: $(BLD_TOP)forbuild.h
apitest.$O: $(SRC_TOP)prologue.h
apitest.$O: $(SRC_DIR)/options.h
apitest.$O: $(SRC_DIR)/pid.h
apitest.$O: $(SRC_DIR)/program.h
apitest.$O: $(SRC_DIR)/brldefs.h
apitest.$O: brlapi_constants.h
apitest.$O: $(SRC_DIR)/brlapi_keycodes.h
apitest.$O: $(SRC_DIR)/cmd.h
apitest.$O: $(SRC_DIR)/cmddefs.h
apitest.$O: brlapi.h

# Dependencies for async_alarm.$O:
async_alarm.$O: $(SRC_DIR)/async_alarm.c
async_alarm.$O: $(BLD_TOP)config.h
async_alarm.$O: $(BLD_TOP)forbuild.h
async_alarm.$O: $(SRC_TOP)prologue.h
async_alarm.$O: $(SRC_DIR)/log.h
async_alarm.$O: $(SRC_DIR)/async.h
async_alarm.$O: $(SRC_DIR)/async_alarm.h
async_alarm.$O: $(SRC_DIR)/timing.h
async_alarm.$O: $(SRC_DIR)/async_internal.h
async_alarm.$O: $(SRC_DIR)/queue.h

# Dependencies for async_data.$O:
async_data.$O: $(SRC_DIR)/async_data.c
async_data.$O: $(BLD_TOP)config.h
async_data.$O: $(BLD_TOP)forbuild.h
async_data.$O: $(SRC_TOP)prologue.h
async_data.$O: $(SRC_DIR)/log.h
async_data.$O: $(SRC_DIR)/async.h
async_data.$O: $(SRC_DIR)/async_thread.h
async_data.$O: $(SRC_DIR)/timing.h
async_data.$O: $(SRC_DIR)/win_pthread.h
async_data.$O: $(SRC_DIR)/async_internal.h
async_data.$O: $(SRC_DIR)/queue.h
async_data.$O: $(SRC_DIR)/pid.h
async_data.$O: $(SRC_DIR)/program.h

# Dependencies for async_event.$O:
async_event.$O: $(SRC_DIR)/async_event.c
async_event.$O: $(BLD_TOP)config.h
async_event.$O: $(BLD_TOP)forbuild.h
async_event.$O: $(SRC_TOP)prologue.h
async_event.$O: $(SRC_DIR)/log.h
async_event.$O: $(SRC_DIR)/async.h
async_event.$O: $(SRC_DIR)/async_io.h
async_event.$O: $(SRC_DIR)/async_event.h
async_event.$O: $(SRC_DIR)/async_internal.h
async_event.$O: $(SRC_DIR)/queue.h
async_event.$O: $(SRC_DIR)/file.h

# Dependencies for async_handle.$O:
async_handle.$O: $(SRC_DIR)/async_handle.c
async_handle.$O: $(BLD_TOP)config.h
async_handle.$O: $(BLD_TOP)forbuild.h
async_handle.$O: $(SRC_TOP)prologue.h
async_handle.$O: $(SRC_DIR)/log.h
async_handle.$O: $(SRC_DIR)/async.h
async_handle.$O: $(SRC_DIR)/async_internal.h
async_handle.$O: $(SRC_DIR)/queue.h

# Dependencies for async_io.$O:
async_io.$O: $(SRC_DIR)/async_io.c
async_io.$O: $(BLD_TOP)config.h
async_io.$O: $(BLD_TOP)forbuild.h
async_io.$O: $(SRC_TOP)prologue.h
async_io.$O: $(SRC_DIR)/system_msdos.h
async_io.$O: $(SRC_DIR)/log.h
async_io.$O: $(SRC_DIR)/async.h
async_io.$O: $(SRC_DIR)/async_io.h
async_io.$O: $(SRC_DIR)/async_internal.h
async_io.$O: $(SRC_DIR)/queue.h
async_io.$O: $(SRC_DIR)/timing.h

# Dependencies for async_signal.$O:
async_signal.$O: $(SRC_DIR)/async_signal.c
async_signal.$O: $(BLD_TOP)config.h
async_signal.$O: $(BLD_TOP)forbuild.h
async_signal.$O: $(SRC_TOP)prologue.h
async_signal.$O: $(SRC_DIR)/log.h
async_signal.$O: $(SRC_DIR)/async.h
async_signal.$O: $(SRC_DIR)/async_event.h
async_signal.$O: $(SRC_DIR)/async_signal.h
async_signal.$O: $(SRC_DIR)/async_internal.h
async_signal.$O: $(SRC_DIR)/queue.h

# Dependencies for async_task.$O:
async_task.$O: $(SRC_DIR)/async_task.c
async_task.$O: $(BLD_TOP)config.h
async_task.$O: $(BLD_TOP)forbuild.h
async_task.$O: $(SRC_TOP)prologue.h
async_task.$O: $(SRC_DIR)/log.h
async_task.$O: $(SRC_DIR)/async.h
async_task.$O: $(SRC_DIR)/async_event.h
async_task.$O: $(SRC_DIR)/async_task.h
async_task.$O: $(SRC_DIR)/async_internal.h
async_task.$O: $(SRC_DIR)/queue.h

# Dependencies for async_thread.$O:
async_thread.$O: $(SRC_DIR)/async_thread.c
async_thread.$O: $(BLD_TOP)config.h
async_thread.$O: $(BLD_TOP)forbuild.h
async_thread.$O: $(SRC_TOP)prologue.h
async_thread.$O: $(SRC_DIR)/log.h
async_thread.$O: $(SRC_DIR)/async.h
async_thread.$O: $(SRC_DIR)/async_signal.h
async_thread.$O: $(SRC_DIR)/async_thread.h
async_thread.$O: $(SRC_DIR)/timing.h
async_thread.$O: $(SRC_DIR)/win_pthread.h

# Dependencies for async_wait.$O:
async_wait.$O: $(SRC_DIR)/async_wait.c
async_wait.$O: $(BLD_TOP)config.h
async_wait.$O: $(BLD_TOP)forbuild.h
async_wait.$O: $(SRC_TOP)prologue.h
async_wait.$O: $(SRC_DIR)/log.h
async_wait.$O: $(SRC_DIR)/async.h
async_wait.$O: $(SRC_DIR)/async_wait.h
async_wait.$O: $(SRC_DIR)/async_internal.h
async_wait.$O: $(SRC_DIR)/queue.h
async_wait.$O: $(SRC_DIR)/timing.h

# Dependencies for atb_compile.$O:
atb_compile.$O: $(SRC_DIR)/atb_compile.c
atb_compile.$O: $(BLD_TOP)config.h
atb_compile.$O: $(BLD_TOP)forbuild.h
atb_compile.$O: $(SRC_TOP)prologue.h
atb_compile.$O: $(SRC_DIR)/file.h
atb_compile.$O: $(SRC_DIR)/datafile.h
atb_compile.$O: $(SRC_DIR)/queue.h
atb_compile.$O: $(SRC_DIR)/dataarea.h
atb_compile.$O: $(SRC_DIR)/atb.h
atb_compile.$O: $(SRC_DIR)/atb_internal.h

# Dependencies for atb_translate.$O:
atb_translate.$O: $(SRC_DIR)/atb_translate.c
atb_translate.$O: $(BLD_TOP)config.h
atb_translate.$O: $(BLD_TOP)forbuild.h
atb_translate.$O: $(SRC_TOP)prologue.h
atb_translate.$O: $(SRC_DIR)/log.h
atb_translate.$O: $(SRC_DIR)/file.h
atb_translate.$O: $(SRC_DIR)/atb.h
atb_translate.$O: $(SRC_DIR)/atb_internal.h
atb_translate.$O: attr.auto.h

# Dependencies for auth.$O:
auth.$O: $(SRC_DIR)/auth.c
auth.$O: $(BLD_TOP)config.h
auth.$O: $(BLD_TOP)forbuild.h
auth.$O: $(SRC_TOP)prologue.h
auth.$O: $(SRC_DIR)/log.h
auth.$O: $(SRC_DIR)/parse.h
auth.$O: $(SRC_DIR)/auth.h

# Dependencies for beep.$O:
beep.$O: $(SRC_DIR)/beep.c
beep.$O: $(BLD_TOP)config.h
beep.$O: $(BLD_TOP)forbuild.h
beep.$O: $(SRC_TOP)prologue.h
beep.$O: $(SRC_DIR)/async.h
beep.$O: $(SRC_DIR)/async_wait.h
beep.$O: $(SRC_DIR)/beep.h

# Dependencies for beep_linux.$O:
beep_linux.$O: $(SRC_DIR)/beep_linux.c
beep_linux.$O: $(BLD_TOP)config.h
beep_linux.$O: $(BLD_TOP)forbuild.h
beep_linux.$O: $(SRC_TOP)prologue.h
beep_linux.$O: $(SRC_DIR)/log.h
beep_linux.$O: $(SRC_DIR)/device.h
beep_linux.$O: $(SRC_DIR)/beep.h
beep_linux.$O: $(SRC_DIR)/system_linux.h

# Dependencies for beep_msdos.$O:
beep_msdos.$O: $(SRC_DIR)/beep_msdos.c
beep_msdos.$O: $(BLD_TOP)config.h
beep_msdos.$O: $(BLD_TOP)forbuild.h
beep_msdos.$O: $(SRC_TOP)prologue.h
beep_msdos.$O: $(SRC_DIR)/beep.h

# Dependencies for beep_none.$O:
beep_none.$O: $(SRC_DIR)/beep_none.c
beep_none.$O: $(BLD_TOP)config.h
beep_none.$O: $(BLD_TOP)forbuild.h
beep_none.$O: $(SRC_TOP)prologue.h
beep_none.$O: $(SRC_DIR)/beep.h

# Dependencies for beep_solaris.$O:
beep_solaris.$O: $(SRC_DIR)/beep_solaris.c
beep_solaris.$O: $(BLD_TOP)config.h
beep_solaris.$O: $(BLD_TOP)forbuild.h
beep_solaris.$O: $(SRC_TOP)prologue.h
beep_solaris.$O: $(SRC_DIR)/beep.h

# Dependencies for beep_spkr.$O:
beep_spkr.$O: $(SRC_DIR)/beep_spkr.c
beep_spkr.$O: $(BLD_TOP)config.h
beep_spkr.$O: $(BLD_TOP)forbuild.h
beep_spkr.$O: $(SRC_TOP)prologue.h
beep_spkr.$O: $(SRC_DIR)/log.h
beep_spkr.$O: $(SRC_DIR)/beep.h

# Dependencies for beep_windows.$O:
beep_windows.$O: $(SRC_DIR)/beep_windows.c
beep_windows.$O: $(BLD_TOP)config.h
beep_windows.$O: $(BLD_TOP)forbuild.h
beep_windows.$O: $(SRC_TOP)prologue.h
beep_windows.$O: $(SRC_DIR)/beep.h

# Dependencies for beep_wskbd.$O:
beep_wskbd.$O: $(SRC_DIR)/beep_wskbd.c
beep_wskbd.$O: $(BLD_TOP)config.h
beep_wskbd.$O: $(BLD_TOP)forbuild.h
beep_wskbd.$O: $(SRC_TOP)prologue.h
beep_wskbd.$O: $(SRC_DIR)/log.h
beep_wskbd.$O: $(SRC_DIR)/device.h
beep_wskbd.$O: $(SRC_DIR)/beep.h

# Dependencies for blink.$O:
blink.$O: $(SRC_DIR)/blink.c
blink.$O: $(BLD_TOP)config.h
blink.$O: $(BLD_TOP)forbuild.h
blink.$O: $(SRC_TOP)prologue.h
blink.$O: $(SRC_DIR)/blink.h
blink.$O: $(SRC_DIR)/prefs.h
blink.$O: $(SRC_DIR)/async.h
blink.$O: $(SRC_DIR)/async_alarm.h
blink.$O: $(SRC_DIR)/timing.h
blink.$O: $(SRC_DIR)/update.h
blink.$O: $(SRC_DIR)/async_io.h
blink.$O: $(SRC_DIR)/brl.h
blink.$O: brlapi_constants.h
blink.$O: $(SRC_DIR)/brlapi_keycodes.h
blink.$O: $(SRC_DIR)/brldefs.h
blink.$O: $(SRC_DIR)/brltty.h
blink.$O: $(SRC_DIR)/cmd.h
blink.$O: $(SRC_DIR)/cmddefs.h
blink.$O: $(SRC_DIR)/ctb.h
blink.$O: $(SRC_DIR)/ctbdefs.h
blink.$O: $(SRC_DIR)/driver.h
blink.$O: $(SRC_DIR)/io_generic.h
blink.$O: $(SRC_DIR)/ktb.h
blink.$O: $(SRC_DIR)/ktbdefs.h
blink.$O: $(SRC_DIR)/menu.h
blink.$O: $(SRC_DIR)/pid.h
blink.$O: $(SRC_DIR)/program.h
blink.$O: $(SRC_DIR)/scrdefs.h
blink.$O: $(SRC_DIR)/serialdefs.h
blink.$O: $(SRC_DIR)/ses.h
blink.$O: $(SRC_DIR)/spk.h
blink.$O: $(SRC_DIR)/spkdefs.h
blink.$O: $(SRC_DIR)/tunedefs.h
blink.$O: $(SRC_DIR)/tunes.h
blink.$O: $(SRC_DIR)/usbdefs.h

# Dependencies for bluetooth.$O:
bluetooth.$O: $(SRC_DIR)/bluetooth.c
bluetooth.$O: $(BLD_TOP)config.h
bluetooth.$O: $(BLD_TOP)forbuild.h
bluetooth.$O: $(SRC_TOP)prologue.h
bluetooth.$O: $(SRC_DIR)/log.h
bluetooth.$O: $(SRC_DIR)/parameters.h
bluetooth.$O: $(SRC_DIR)/timing.h
bluetooth.$O: $(SRC_DIR)/async.h
bluetooth.$O: $(SRC_DIR)/async_wait.h
bluetooth.$O: $(SRC_DIR)/parse.h
bluetooth.$O: $(SRC_DIR)/device.h
bluetooth.$O: $(SRC_DIR)/queue.h
bluetooth.$O: $(SRC_DIR)/async_io.h
bluetooth.$O: $(SRC_DIR)/io_bluetooth.h
bluetooth.$O: $(SRC_DIR)/bluetooth_internal.h

# Dependencies for bluetooth_android.$O:
bluetooth_android.$O: $(SRC_DIR)/bluetooth_android.c
bluetooth_android.$O: $(BLD_TOP)config.h
bluetooth_android.$O: $(BLD_TOP)forbuild.h
bluetooth_android.$O: $(SRC_TOP)prologue.h
bluetooth_android.$O: $(SRC_DIR)/async.h
bluetooth_android.$O: $(SRC_DIR)/async_io.h
bluetooth_android.$O: $(SRC_DIR)/io_bluetooth.h
bluetooth_android.$O: $(SRC_DIR)/bluetooth_internal.h
bluetooth_android.$O: $(SRC_DIR)/log.h
bluetooth_android.$O: $(SRC_DIR)/io_misc.h
bluetooth_android.$O: $(SRC_DIR)/system_java.h

# Dependencies for bluetooth_darwin.$O:
bluetooth_darwin.$O: $(SRC_DIR)/bluetooth_darwin.c
bluetooth_darwin.$O: $(BLD_TOP)config.h
bluetooth_darwin.$O: $(BLD_TOP)forbuild.h
bluetooth_darwin.$O: $(SRC_TOP)prologue.h
bluetooth_darwin.$O: $(SRC_DIR)/log.h
bluetooth_darwin.$O: $(SRC_DIR)/io_misc.h
bluetooth_darwin.$O: $(SRC_DIR)/async.h
bluetooth_darwin.$O: $(SRC_DIR)/async_io.h
bluetooth_darwin.$O: $(SRC_DIR)/io_bluetooth.h
bluetooth_darwin.$O: $(SRC_DIR)/bluetooth_internal.h
bluetooth_darwin.$O: $(SRC_DIR)/system_darwin.h

# Dependencies for bluetooth_linux.$O:
bluetooth_linux.$O: $(SRC_DIR)/bluetooth_linux.c
bluetooth_linux.$O: $(BLD_TOP)config.h
bluetooth_linux.$O: $(BLD_TOP)forbuild.h
bluetooth_linux.$O: $(SRC_TOP)prologue.h
bluetooth_linux.$O: $(SRC_DIR)/log.h
bluetooth_linux.$O: $(SRC_DIR)/parameters.h
bluetooth_linux.$O: $(SRC_DIR)/async.h
bluetooth_linux.$O: $(SRC_DIR)/async_io.h
bluetooth_linux.$O: $(SRC_DIR)/io_bluetooth.h
bluetooth_linux.$O: $(SRC_DIR)/bluetooth_internal.h
bluetooth_linux.$O: $(SRC_DIR)/io_misc.h
bluetooth_linux.$O: $(SRC_DIR)/timing.h

# Dependencies for bluetooth_names.$O:
bluetooth_names.$O: $(SRC_DIR)/bluetooth_names.c
bluetooth_names.$O: $(BLD_TOP)config.h
bluetooth_names.$O: $(BLD_TOP)forbuild.h
bluetooth_names.$O: $(SRC_TOP)prologue.h
bluetooth_names.$O: $(SRC_DIR)/bluetooth_internal.h

# Dependencies for bluetooth_none.$O:
bluetooth_none.$O: $(SRC_DIR)/bluetooth_none.c
bluetooth_none.$O: $(BLD_TOP)config.h
bluetooth_none.$O: $(BLD_TOP)forbuild.h
bluetooth_none.$O: $(SRC_TOP)prologue.h
bluetooth_none.$O: $(SRC_DIR)/async.h
bluetooth_none.$O: $(SRC_DIR)/async_io.h
bluetooth_none.$O: $(SRC_DIR)/io_bluetooth.h
bluetooth_none.$O: $(SRC_DIR)/bluetooth_internal.h
bluetooth_none.$O: $(SRC_DIR)/log.h

# Dependencies for bluetooth_windows.$O:
bluetooth_windows.$O: $(SRC_DIR)/bluetooth_windows.c
bluetooth_windows.$O: $(BLD_TOP)config.h
bluetooth_windows.$O: $(BLD_TOP)forbuild.h
bluetooth_windows.$O: $(SRC_TOP)prologue.h
bluetooth_windows.$O: $(SRC_DIR)/log.h
bluetooth_windows.$O: $(SRC_DIR)/timing.h
bluetooth_windows.$O: $(SRC_DIR)/bitfield.h
bluetooth_windows.$O: $(SRC_DIR)/async.h
bluetooth_windows.$O: $(SRC_DIR)/async_io.h
bluetooth_windows.$O: $(SRC_DIR)/io_bluetooth.h
bluetooth_windows.$O: $(SRC_DIR)/bluetooth_internal.h

# Dependencies for brl.$O:
brl.$O: $(SRC_DIR)/brl.c
brl.$O: $(BLD_TOP)config.h
brl.$O: $(BLD_TOP)forbuild.h
brl.$O: $(SRC_TOP)prologue.h
brl.$O: $(SRC_DIR)/log.h
brl.$O: $(SRC_DIR)/timing.h
brl.$O: $(SRC_DIR)/async.h
brl.$O: $(SRC_DIR)/async_wait.h
brl.$O: $(SRC_DIR)/message.h
brl.$O: $(SRC_DIR)/charset.h
brl.$O: $(SRC_DIR)/lock.h
brl.$O: $(SRC_DIR)/unicode.h
brl.$O: $(SRC_DIR)/driver.h
brl.$O: $(SRC_DIR)/drivers.h
brl.$O: $(SRC_DIR)/async_io.h
brl.$O: $(SRC_DIR)/io_generic.h
brl.$O: $(SRC_DIR)/serialdefs.h
brl.$O: $(SRC_DIR)/usbdefs.h
brl.$O: $(SRC_DIR)/brl.h
brl.$O: $(SRC_DIR)/brldefs.h
brl.$O: $(SRC_DIR)/ktbdefs.h
brl.$O: $(SRC_DIR)/ttb.h
brl.$O: $(SRC_DIR)/ktb.h
brl.$O: brlapi_constants.h
brl.$O: $(SRC_DIR)/brlapi_keycodes.h
brl.$O: $(SRC_DIR)/cmd.h
brl.$O: $(SRC_DIR)/cmddefs.h
brl.$O: $(SRC_DIR)/prefs.h
brl.$O: $(SRC_DIR)/brltty.h
brl.$O: $(SRC_DIR)/ctb.h
brl.$O: $(SRC_DIR)/ctbdefs.h
brl.$O: $(SRC_DIR)/menu.h
brl.$O: $(SRC_DIR)/pid.h
brl.$O: $(SRC_DIR)/program.h
brl.$O: $(SRC_DIR)/scrdefs.h
brl.$O: $(SRC_DIR)/ses.h
brl.$O: $(SRC_DIR)/spk.h
brl.$O: $(SRC_DIR)/spkdefs.h
brl.$O: $(SRC_DIR)/tunedefs.h
brl.$O: $(SRC_DIR)/tunes.h

# Dependencies for brl_driver.$O:
brl_driver.$O: $(SRC_DIR)/brl_driver.c
brl_driver.$O: $(BLD_TOP)config.h
brl_driver.$O: $(BLD_TOP)forbuild.h
brl_driver.$O: $(SRC_TOP)prologue.h
brl_driver.$O: $(SRC_DIR)/log.h
brl_driver.$O: $(SRC_DIR)/prefs.h
brl_driver.$O: $(SRC_DIR)/ktb.h
brl_driver.$O: $(SRC_DIR)/ktbdefs.h
brl_driver.$O: $(SRC_DIR)/async.h
brl_driver.$O: $(SRC_DIR)/async_wait.h
brl_driver.$O: $(SRC_DIR)/api_control.h
brl_driver.$O: $(SRC_DIR)/async_io.h
brl_driver.$O: $(SRC_DIR)/brl.h
brl_driver.$O: $(SRC_DIR)/brldefs.h
brl_driver.$O: $(SRC_DIR)/driver.h
brl_driver.$O: $(SRC_DIR)/io_generic.h
brl_driver.$O: $(SRC_DIR)/serialdefs.h
brl_driver.$O: $(SRC_DIR)/usbdefs.h
brl_driver.$O: $(SRC_DIR)/drivers.h
brl_driver.$O: brl.auto.h
brl_driver.$O: $(SRC_DIR)/brl_driver.h
brl_driver.$O: $(SRC_DIR)/cmd_queue.h
brl_driver.$O: $(SRC_DIR)/statdefs.h

# Dependencies for brl_input.$O:
brl_input.$O: $(SRC_DIR)/brl_input.c
brl_input.$O: $(BLD_TOP)config.h
brl_input.$O: $(BLD_TOP)forbuild.h
brl_input.$O: $(SRC_TOP)prologue.h
brl_input.$O: $(SRC_DIR)/log.h
brl_input.$O: $(SRC_DIR)/parameters.h
brl_input.$O: $(SRC_DIR)/brl_input.h
brl_input.$O: $(SRC_DIR)/cmd_queue.h
brl_input.$O: $(SRC_DIR)/ktbdefs.h
brl_input.$O: $(SRC_DIR)/async.h
brl_input.$O: $(SRC_DIR)/async_alarm.h
brl_input.$O: $(SRC_DIR)/timing.h
brl_input.$O: $(SRC_DIR)/api_control.h
brl_input.$O: $(SRC_DIR)/async_io.h
brl_input.$O: $(SRC_DIR)/brl.h
brl_input.$O: $(SRC_DIR)/brldefs.h
brl_input.$O: $(SRC_DIR)/driver.h
brl_input.$O: $(SRC_DIR)/io_generic.h
brl_input.$O: $(SRC_DIR)/serialdefs.h
brl_input.$O: $(SRC_DIR)/usbdefs.h
brl_input.$O: brlapi_constants.h
brl_input.$O: $(SRC_DIR)/brlapi_keycodes.h
brl_input.$O: $(SRC_DIR)/brltty.h
brl_input.$O: $(SRC_DIR)/cmd.h
brl_input.$O: $(SRC_DIR)/cmddefs.h
brl_input.$O: $(SRC_DIR)/ctb.h
brl_input.$O: $(SRC_DIR)/ctbdefs.h
brl_input.$O: $(SRC_DIR)/ktb.h
brl_input.$O: $(SRC_DIR)/menu.h
brl_input.$O: $(SRC_DIR)/pid.h
brl_input.$O: $(SRC_DIR)/prefs.h
brl_input.$O: $(SRC_DIR)/program.h
brl_input.$O: $(SRC_DIR)/scrdefs.h
brl_input.$O: $(SRC_DIR)/ses.h
brl_input.$O: $(SRC_DIR)/spk.h
brl_input.$O: $(SRC_DIR)/spkdefs.h
brl_input.$O: $(SRC_DIR)/tunedefs.h
brl_input.$O: $(SRC_DIR)/tunes.h

# Dependencies for brlapi_client.$O:
brlapi_client.$O: $(SRC_DIR)/brlapi_client.c
brlapi_client.$O: $(BLD_TOP)config.h
brlapi_client.$O: $(BLD_TOP)forbuild.h
brlapi_client.$O: $(SRC_TOP)prologue.h
brlapi_client.$O: $(SRC_DIR)/timing.h
brlapi_client.$O: $(SRC_DIR)/win_pthread.h
brlapi_client.$O: $(SRC_DIR)/win_errno.h
brlapi_client.$O: brlapi.h
brlapi_client.$O: brlapi_constants.h
brlapi_client.$O: $(SRC_DIR)/brlapi_keycodes.h
brlapi_client.$O: $(SRC_DIR)/brlapi_protocol.h
brlapi_client.$O: $(SRC_DIR)/brlapi_common.h
brlapi_client.$O: brlapi_keytab.auto.h

# Dependencies for brlapi_keyranges.$O:
brlapi_keyranges.$O: $(SRC_DIR)/brlapi_keyranges.c
brlapi_keyranges.$O: $(BLD_TOP)config.h
brlapi_keyranges.$O: $(BLD_TOP)forbuild.h
brlapi_keyranges.$O: $(SRC_TOP)prologue.h
brlapi_keyranges.$O: $(SRC_DIR)/brlapi_keyranges.h
brlapi_keyranges.$O: $(SRC_DIR)/log.h

# Dependencies for brlapi_server.$O:
brlapi_server.$O: $(SRC_DIR)/brlapi_server.c
brlapi_server.$O: $(BLD_TOP)config.h
brlapi_server.$O: $(BLD_TOP)forbuild.h
brlapi_server.$O: $(SRC_TOP)prologue.h
brlapi_server.$O: $(SRC_DIR)/system_windows.h
brlapi_server.$O: $(SRC_DIR)/timing.h
brlapi_server.$O: $(SRC_DIR)/win_pthread.h
brlapi_server.$O: brlapi.h
brlapi_server.$O: brlapi_constants.h
brlapi_server.$O: $(SRC_DIR)/brlapi_keycodes.h
brlapi_server.$O: $(SRC_DIR)/brlapi_protocol.h
brlapi_server.$O: $(SRC_DIR)/brlapi_keyranges.h
brlapi_server.$O: $(SRC_DIR)/cmd.h
brlapi_server.$O: $(SRC_DIR)/cmddefs.h
brlapi_server.$O: $(SRC_DIR)/async.h
brlapi_server.$O: $(SRC_DIR)/async_io.h
brlapi_server.$O: $(SRC_DIR)/brl.h
brlapi_server.$O: $(SRC_DIR)/brldefs.h
brlapi_server.$O: $(SRC_DIR)/driver.h
brlapi_server.$O: $(SRC_DIR)/io_generic.h
brlapi_server.$O: $(SRC_DIR)/ktbdefs.h
brlapi_server.$O: $(SRC_DIR)/serialdefs.h
brlapi_server.$O: $(SRC_DIR)/usbdefs.h
brlapi_server.$O: $(SRC_DIR)/ttb.h
brlapi_server.$O: $(SRC_DIR)/brltty.h
brlapi_server.$O: $(SRC_DIR)/ctb.h
brlapi_server.$O: $(SRC_DIR)/ctbdefs.h
brlapi_server.$O: $(SRC_DIR)/ktb.h
brlapi_server.$O: $(SRC_DIR)/menu.h
brlapi_server.$O: $(SRC_DIR)/pid.h
brlapi_server.$O: $(SRC_DIR)/prefs.h
brlapi_server.$O: $(SRC_DIR)/program.h
brlapi_server.$O: $(SRC_DIR)/scrdefs.h
brlapi_server.$O: $(SRC_DIR)/ses.h
brlapi_server.$O: $(SRC_DIR)/spk.h
brlapi_server.$O: $(SRC_DIR)/spkdefs.h
brlapi_server.$O: $(SRC_DIR)/tunedefs.h
brlapi_server.$O: $(SRC_DIR)/tunes.h
brlapi_server.$O: $(SRC_DIR)/api_control.h
brlapi_server.$O: $(SRC_DIR)/log.h
brlapi_server.$O: $(SRC_DIR)/addresses.h
brlapi_server.$O: $(SRC_DIR)/file.h
brlapi_server.$O: $(SRC_DIR)/parse.h
brlapi_server.$O: $(SRC_DIR)/auth.h
brlapi_server.$O: $(SRC_DIR)/io_misc.h
brlapi_server.$O: $(SRC_DIR)/cmd_queue.h
brlapi_server.$O: $(SRC_DIR)/scr.h
brlapi_server.$O: $(SRC_DIR)/charset.h
brlapi_server.$O: $(SRC_DIR)/lock.h
brlapi_server.$O: $(SRC_DIR)/async_event.h
brlapi_server.$O: $(SRC_DIR)/async_signal.h
brlapi_server.$O: $(SRC_DIR)/async_thread.h
brlapi_server.$O: $(SRC_DIR)/brlapi_common.h

# Dependencies for brltest.$O:
brltest.$O: $(SRC_DIR)/brltest.c
brltest.$O: $(BLD_TOP)config.h
brltest.$O: $(BLD_TOP)forbuild.h
brltest.$O: $(SRC_TOP)prologue.h
brltest.$O: $(SRC_DIR)/pid.h
brltest.$O: $(SRC_DIR)/program.h
brltest.$O: $(SRC_DIR)/options.h
brltest.$O: $(SRC_DIR)/parameters.h
brltest.$O: $(SRC_DIR)/log.h
brltest.$O: $(SRC_DIR)/parse.h
brltest.$O: $(SRC_DIR)/async.h
brltest.$O: $(SRC_DIR)/async_io.h
brltest.$O: $(SRC_DIR)/brl.h
brltest.$O: $(SRC_DIR)/brldefs.h
brltest.$O: $(SRC_DIR)/driver.h
brltest.$O: $(SRC_DIR)/io_generic.h
brltest.$O: $(SRC_DIR)/ktbdefs.h
brltest.$O: $(SRC_DIR)/serialdefs.h
brltest.$O: $(SRC_DIR)/usbdefs.h
brltest.$O: $(SRC_DIR)/file.h
brltest.$O: $(SRC_DIR)/async_wait.h
brltest.$O: $(SRC_DIR)/cmd_learn.h
brltest.$O: $(SRC_DIR)/charset.h
brltest.$O: $(SRC_DIR)/lock.h
brltest.$O: $(SRC_DIR)/message.h
brltest.$O: $(SRC_DIR)/ctbdefs.h
brltest.$O: $(SRC_DIR)/defaults.h
brltest.$O: $(SRC_DIR)/spkdefs.h
brltest.$O: $(SRC_DIR)/tunedefs.h

# Dependencies for brltty-ctb.$O:
brltty-ctb.$O: $(SRC_DIR)/brltty-ctb.c
brltty-ctb.$O: $(BLD_TOP)config.h
brltty-ctb.$O: $(BLD_TOP)forbuild.h
brltty-ctb.$O: $(SRC_TOP)prologue.h
brltty-ctb.$O: $(SRC_DIR)/pid.h
brltty-ctb.$O: $(SRC_DIR)/program.h
brltty-ctb.$O: $(SRC_DIR)/options.h
brltty-ctb.$O: $(SRC_DIR)/prefs.h
brltty-ctb.$O: $(SRC_DIR)/log.h
brltty-ctb.$O: $(SRC_DIR)/file.h
brltty-ctb.$O: $(SRC_DIR)/datafile.h
brltty-ctb.$O: $(SRC_DIR)/queue.h
brltty-ctb.$O: $(SRC_DIR)/parse.h
brltty-ctb.$O: $(SRC_DIR)/charset.h
brltty-ctb.$O: $(SRC_DIR)/lock.h
brltty-ctb.$O: $(SRC_DIR)/unicode.h
brltty-ctb.$O: $(SRC_DIR)/ascii.h
brltty-ctb.$O: $(SRC_DIR)/brldots.h
brltty-ctb.$O: $(SRC_DIR)/ttb.h
brltty-ctb.$O: $(SRC_DIR)/ctb.h
brltty-ctb.$O: $(SRC_DIR)/ctbdefs.h

# Dependencies for brltty-trtxt.$O:
brltty-trtxt.$O: $(SRC_DIR)/brltty-trtxt.c
brltty-trtxt.$O: $(BLD_TOP)config.h
brltty-trtxt.$O: $(BLD_TOP)forbuild.h
brltty-trtxt.$O: $(SRC_TOP)prologue.h
brltty-trtxt.$O: $(SRC_DIR)/pid.h
brltty-trtxt.$O: $(SRC_DIR)/program.h
brltty-trtxt.$O: $(SRC_DIR)/options.h
brltty-trtxt.$O: $(SRC_DIR)/log.h
brltty-trtxt.$O: $(SRC_DIR)/file.h
brltty-trtxt.$O: $(SRC_DIR)/unicode.h
brltty-trtxt.$O: $(SRC_DIR)/charset.h
brltty-trtxt.$O: $(SRC_DIR)/lock.h
brltty-trtxt.$O: $(SRC_DIR)/brldots.h
brltty-trtxt.$O: $(SRC_DIR)/ttb.h

# Dependencies for brltty-ttb.$O:
brltty-ttb.$O: $(SRC_DIR)/brltty-ttb.c
brltty-ttb.$O: $(BLD_TOP)config.h
brltty-ttb.$O: $(BLD_TOP)forbuild.h
brltty-ttb.$O: $(SRC_TOP)prologue.h
brltty-ttb.$O: $(SRC_DIR)/pid.h
brltty-ttb.$O: $(SRC_DIR)/program.h
brltty-ttb.$O: $(SRC_DIR)/options.h
brltty-ttb.$O: $(SRC_DIR)/log.h
brltty-ttb.$O: $(SRC_DIR)/file.h
brltty-ttb.$O: $(SRC_DIR)/brldots.h
brltty-ttb.$O: $(SRC_DIR)/charset.h
brltty-ttb.$O: $(SRC_DIR)/lock.h
brltty-ttb.$O: $(SRC_DIR)/ttb.h
brltty-ttb.$O: $(SRC_DIR)/bitmask.h
brltty-ttb.$O: $(SRC_DIR)/ttb_internal.h
brltty-ttb.$O: $(SRC_DIR)/unicode.h
brltty-ttb.$O: $(SRC_DIR)/datafile.h
brltty-ttb.$O: $(SRC_DIR)/queue.h
brltty-ttb.$O: $(SRC_DIR)/ttb_compile.h
brltty-ttb.$O: brlapi.h
brltty-ttb.$O: brlapi_constants.h
brltty-ttb.$O: $(SRC_DIR)/brlapi_keycodes.h

# Dependencies for brltty.$O:
brltty.$O: $(SRC_DIR)/brltty.c
brltty.$O: $(BLD_TOP)config.h
brltty.$O: $(BLD_TOP)forbuild.h
brltty.$O: $(SRC_TOP)prologue.h
brltty.$O: $(SRC_DIR)/async.h
brltty.$O: $(SRC_DIR)/async_io.h
brltty.$O: $(SRC_DIR)/brl.h
brltty.$O: brlapi_constants.h
brltty.$O: $(SRC_DIR)/brlapi_keycodes.h
brltty.$O: $(SRC_DIR)/brldefs.h
brltty.$O: $(SRC_DIR)/brltty.h
brltty.$O: $(SRC_DIR)/cmd.h
brltty.$O: $(SRC_DIR)/cmddefs.h
brltty.$O: $(SRC_DIR)/ctb.h
brltty.$O: $(SRC_DIR)/ctbdefs.h
brltty.$O: $(SRC_DIR)/driver.h
brltty.$O: $(SRC_DIR)/embed.h
brltty.$O: $(SRC_DIR)/io_generic.h
brltty.$O: $(SRC_DIR)/ktb.h
brltty.$O: $(SRC_DIR)/ktbdefs.h
brltty.$O: $(SRC_DIR)/menu.h
brltty.$O: $(SRC_DIR)/pid.h
brltty.$O: $(SRC_DIR)/prefs.h
brltty.$O: $(SRC_DIR)/program.h
brltty.$O: $(SRC_DIR)/scrdefs.h
brltty.$O: $(SRC_DIR)/serialdefs.h
brltty.$O: $(SRC_DIR)/ses.h
brltty.$O: $(SRC_DIR)/spk.h
brltty.$O: $(SRC_DIR)/spkdefs.h
brltty.$O: $(SRC_DIR)/timing.h
brltty.$O: $(SRC_DIR)/tunedefs.h
brltty.$O: $(SRC_DIR)/tunes.h
brltty.$O: $(SRC_DIR)/usbdefs.h
brltty.$O: $(SRC_DIR)/log.h
brltty.$O: $(SRC_DIR)/parameters.h
brltty.$O: $(SRC_DIR)/cmd_queue.h
brltty.$O: $(SRC_DIR)/cmd_navigation.h
brltty.$O: $(SRC_DIR)/cmd_speech.h
brltty.$O: $(SRC_DIR)/async_wait.h
brltty.$O: $(SRC_DIR)/async_event.h
brltty.$O: $(SRC_DIR)/async_signal.h
brltty.$O: $(SRC_DIR)/routing.h
brltty.$O: $(SRC_DIR)/charset.h
brltty.$O: $(SRC_DIR)/lock.h
brltty.$O: $(SRC_DIR)/scr.h
brltty.$O: $(SRC_DIR)/update.h
brltty.$O: $(SRC_DIR)/scancodes.h
brltty.$O: $(SRC_DIR)/api_control.h

# Dependencies for brltty_jni.$O:
brltty_jni.$O: $(SRC_DIR)/brltty_jni.c
brltty_jni.$O: $(BLD_TOP)config.h
brltty_jni.$O: $(BLD_TOP)forbuild.h
brltty_jni.$O: $(SRC_TOP)prologue.h
brltty_jni.$O: $(SRC_DIR)/async.h
brltty_jni.$O: $(SRC_DIR)/async_io.h
brltty_jni.$O: $(SRC_DIR)/brl.h
brltty_jni.$O: brlapi_constants.h
brltty_jni.$O: $(SRC_DIR)/brlapi_keycodes.h
brltty_jni.$O: $(SRC_DIR)/brldefs.h
brltty_jni.$O: $(SRC_DIR)/brltty.h
brltty_jni.$O: $(SRC_DIR)/cmd.h
brltty_jni.$O: $(SRC_DIR)/cmddefs.h
brltty_jni.$O: $(SRC_DIR)/ctb.h
brltty_jni.$O: $(SRC_DIR)/ctbdefs.h
brltty_jni.$O: $(SRC_DIR)/driver.h
brltty_jni.$O: $(SRC_DIR)/embed.h
brltty_jni.$O: $(SRC_DIR)/io_generic.h
brltty_jni.$O: $(SRC_DIR)/ktb.h
brltty_jni.$O: $(SRC_DIR)/ktbdefs.h
brltty_jni.$O: $(SRC_DIR)/menu.h
brltty_jni.$O: $(SRC_DIR)/pid.h
brltty_jni.$O: $(SRC_DIR)/prefs.h
brltty_jni.$O: $(SRC_DIR)/program.h
brltty_jni.$O: $(SRC_DIR)/scrdefs.h
brltty_jni.$O: $(SRC_DIR)/serialdefs.h
brltty_jni.$O: $(SRC_DIR)/ses.h
brltty_jni.$O: $(SRC_DIR)/spk.h
brltty_jni.$O: $(SRC_DIR)/spkdefs.h
brltty_jni.$O: $(SRC_DIR)/timing.h
brltty_jni.$O: $(SRC_DIR)/tunedefs.h
brltty_jni.$O: $(SRC_DIR)/tunes.h
brltty_jni.$O: $(SRC_DIR)/usbdefs.h
brltty_jni.$O: $(SRC_DIR)/system_java.h

# Dependencies for charset.$O:
charset.$O: $(SRC_DIR)/charset.c
charset.$O: $(BLD_TOP)config.h
charset.$O: $(BLD_TOP)forbuild.h
charset.$O: $(SRC_TOP)prologue.h
charset.$O: $(SRC_DIR)/log.h
charset.$O: $(SRC_DIR)/charset.h
charset.$O: $(SRC_DIR)/charset_internal.h
charset.$O: $(SRC_DIR)/lock.h
charset.$O: $(SRC_DIR)/unicode.h
charset.$O: $(SRC_DIR)/pid.h
charset.$O: $(SRC_DIR)/program.h
charset.$O: $(SRC_DIR)/system_windows.h
charset.$O: $(SRC_DIR)/system_java.h

# Dependencies for charset_grub.$O:
charset_grub.$O: $(SRC_DIR)/charset_grub.c
charset_grub.$O: $(BLD_TOP)config.h
charset_grub.$O: $(BLD_TOP)forbuild.h
charset_grub.$O: $(SRC_TOP)prologue.h
charset_grub.$O: $(SRC_DIR)/charset.h
charset_grub.$O: $(SRC_DIR)/charset_internal.h
charset_grub.$O: $(SRC_DIR)/lock.h

# Dependencies for charset_iconv.$O:
charset_iconv.$O: $(SRC_DIR)/charset_iconv.c
charset_iconv.$O: $(BLD_TOP)config.h
charset_iconv.$O: $(BLD_TOP)forbuild.h
charset_iconv.$O: $(SRC_TOP)prologue.h
charset_iconv.$O: $(SRC_DIR)/log.h
charset_iconv.$O: $(SRC_DIR)/charset.h
charset_iconv.$O: $(SRC_DIR)/charset_internal.h
charset_iconv.$O: $(SRC_DIR)/lock.h
charset_iconv.$O: $(SRC_DIR)/pid.h
charset_iconv.$O: $(SRC_DIR)/program.h

# Dependencies for charset_msdos.$O:
charset_msdos.$O: $(SRC_DIR)/charset_msdos.c
charset_msdos.$O: $(BLD_TOP)config.h
charset_msdos.$O: $(BLD_TOP)forbuild.h
charset_msdos.$O: $(SRC_TOP)prologue.h
charset_msdos.$O: $(SRC_DIR)/charset.h
charset_msdos.$O: $(SRC_DIR)/charset_internal.h
charset_msdos.$O: $(SRC_DIR)/lock.h
charset_msdos.$O: $(SRC_DIR)/unicode.h
charset_msdos.$O: $(SRC_DIR)/system_msdos.h

# Dependencies for charset_none.$O:
charset_none.$O: $(SRC_DIR)/charset_none.c
charset_none.$O: $(BLD_TOP)config.h
charset_none.$O: $(BLD_TOP)forbuild.h
charset_none.$O: $(SRC_TOP)prologue.h
charset_none.$O: $(SRC_DIR)/charset.h
charset_none.$O: $(SRC_DIR)/charset_internal.h
charset_none.$O: $(SRC_DIR)/lock.h

# Dependencies for charset_windows.$O:
charset_windows.$O: $(SRC_DIR)/charset_windows.c
charset_windows.$O: $(BLD_TOP)config.h
charset_windows.$O: $(BLD_TOP)forbuild.h
charset_windows.$O: $(SRC_TOP)prologue.h
charset_windows.$O: $(SRC_DIR)/log.h
charset_windows.$O: $(SRC_DIR)/charset.h
charset_windows.$O: $(SRC_DIR)/charset_internal.h
charset_windows.$O: $(SRC_DIR)/lock.h

# Dependencies for clipboard.$O:
clipboard.$O: $(SRC_DIR)/clipboard.c
clipboard.$O: $(BLD_TOP)config.h
clipboard.$O: $(BLD_TOP)forbuild.h
clipboard.$O: $(SRC_TOP)prologue.h
clipboard.$O: $(SRC_DIR)/log.h
clipboard.$O: $(SRC_DIR)/cmd_queue.h
clipboard.$O: $(SRC_DIR)/driver.h
clipboard.$O: $(SRC_DIR)/ktbdefs.h
clipboard.$O: $(SRC_DIR)/scr.h
clipboard.$O: $(SRC_DIR)/scrdefs.h
clipboard.$O: $(SRC_DIR)/tunedefs.h
clipboard.$O: $(SRC_DIR)/tunes.h
clipboard.$O: $(SRC_DIR)/clipboard.h
clipboard.$O: $(SRC_DIR)/queue.h
clipboard.$O: $(SRC_DIR)/file.h
clipboard.$O: $(SRC_DIR)/charset.h
clipboard.$O: $(SRC_DIR)/lock.h

# Dependencies for cmd.$O:
cmd.$O: $(SRC_DIR)/cmd.c
cmd.$O: $(BLD_TOP)config.h
cmd.$O: $(BLD_TOP)forbuild.h
cmd.$O: $(SRC_TOP)prologue.h
cmd.$O: $(SRC_DIR)/log.h
cmd.$O: $(SRC_DIR)/brldefs.h
cmd.$O: brlapi_constants.h
cmd.$O: $(SRC_DIR)/brlapi_keycodes.h
cmd.$O: $(SRC_DIR)/cmd.h
cmd.$O: $(SRC_DIR)/cmddefs.h
cmd.$O: $(SRC_DIR)/ttb.h
cmd.$O: $(SRC_DIR)/pid.h
cmd.$O: $(SRC_DIR)/program.h
cmd.$O: cmds.auto.h

# Dependencies for cmd_learn.$O:
cmd_learn.$O: $(SRC_DIR)/cmd_learn.c
cmd_learn.$O: $(BLD_TOP)config.h
cmd_learn.$O: $(BLD_TOP)forbuild.h
cmd_learn.$O: $(SRC_TOP)prologue.h
cmd_learn.$O: $(SRC_DIR)/log.h
cmd_learn.$O: $(SRC_DIR)/message.h
cmd_learn.$O: $(SRC_DIR)/async.h
cmd_learn.$O: $(SRC_DIR)/async_wait.h
cmd_learn.$O: $(SRC_DIR)/async_event.h
cmd_learn.$O: $(SRC_DIR)/async_task.h
cmd_learn.$O: $(SRC_DIR)/ktbdefs.h
cmd_learn.$O: $(SRC_DIR)/update.h
cmd_learn.$O: $(SRC_DIR)/cmd_queue.h
cmd_learn.$O: $(SRC_DIR)/cmd_learn.h
cmd_learn.$O: brlapi_constants.h
cmd_learn.$O: $(SRC_DIR)/brlapi_keycodes.h
cmd_learn.$O: $(SRC_DIR)/cmd.h
cmd_learn.$O: $(SRC_DIR)/cmddefs.h
cmd_learn.$O: $(SRC_DIR)/async_io.h
cmd_learn.$O: $(SRC_DIR)/brl.h
cmd_learn.$O: $(SRC_DIR)/brldefs.h
cmd_learn.$O: $(SRC_DIR)/driver.h
cmd_learn.$O: $(SRC_DIR)/io_generic.h
cmd_learn.$O: $(SRC_DIR)/serialdefs.h
cmd_learn.$O: $(SRC_DIR)/usbdefs.h
cmd_learn.$O: $(SRC_DIR)/brltty.h
cmd_learn.$O: $(SRC_DIR)/ctb.h
cmd_learn.$O: $(SRC_DIR)/ctbdefs.h
cmd_learn.$O: $(SRC_DIR)/ktb.h
cmd_learn.$O: $(SRC_DIR)/menu.h
cmd_learn.$O: $(SRC_DIR)/pid.h
cmd_learn.$O: $(SRC_DIR)/prefs.h
cmd_learn.$O: $(SRC_DIR)/program.h
cmd_learn.$O: $(SRC_DIR)/scrdefs.h
cmd_learn.$O: $(SRC_DIR)/ses.h
cmd_learn.$O: $(SRC_DIR)/spk.h
cmd_learn.$O: $(SRC_DIR)/spkdefs.h
cmd_learn.$O: $(SRC_DIR)/timing.h
cmd_learn.$O: $(SRC_DIR)/tunedefs.h
cmd_learn.$O: $(SRC_DIR)/tunes.h

# Dependencies for cmd_navigation.$O:
cmd_navigation.$O: $(SRC_DIR)/cmd_navigation.c
cmd_navigation.$O: $(BLD_TOP)config.h
cmd_navigation.$O: $(BLD_TOP)forbuild.h
cmd_navigation.$O: $(SRC_TOP)prologue.h
cmd_navigation.$O: $(SRC_DIR)/log.h
cmd_navigation.$O: $(SRC_DIR)/parameters.h
cmd_navigation.$O: $(SRC_DIR)/cmd_navigation.h
cmd_navigation.$O: $(SRC_DIR)/cmd_queue.h
cmd_navigation.$O: $(SRC_DIR)/ktbdefs.h
cmd_navigation.$O: $(SRC_DIR)/cmd_learn.h
cmd_navigation.$O: $(SRC_DIR)/parse.h
cmd_navigation.$O: $(SRC_DIR)/prefs.h
cmd_navigation.$O: $(SRC_DIR)/tunedefs.h
cmd_navigation.$O: $(SRC_DIR)/tunes.h
cmd_navigation.$O: $(SRC_DIR)/routing.h
cmd_navigation.$O: $(SRC_DIR)/clipboard.h
cmd_navigation.$O: $(SRC_DIR)/message.h
cmd_navigation.$O: $(SRC_DIR)/brldefs.h
cmd_navigation.$O: $(SRC_DIR)/scancodes.h
cmd_navigation.$O: $(SRC_DIR)/ttb.h
cmd_navigation.$O: $(SRC_DIR)/driver.h
cmd_navigation.$O: $(SRC_DIR)/scr.h
cmd_navigation.$O: $(SRC_DIR)/scrdefs.h
cmd_navigation.$O: $(SRC_DIR)/charset.h
cmd_navigation.$O: $(SRC_DIR)/lock.h
cmd_navigation.$O: $(SRC_DIR)/async.h
cmd_navigation.$O: $(SRC_DIR)/async_io.h
cmd_navigation.$O: $(SRC_DIR)/brl.h
cmd_navigation.$O: brlapi_constants.h
cmd_navigation.$O: $(SRC_DIR)/brlapi_keycodes.h
cmd_navigation.$O: $(SRC_DIR)/brltty.h
cmd_navigation.$O: $(SRC_DIR)/cmd.h
cmd_navigation.$O: $(SRC_DIR)/cmddefs.h
cmd_navigation.$O: $(SRC_DIR)/ctb.h
cmd_navigation.$O: $(SRC_DIR)/ctbdefs.h
cmd_navigation.$O: $(SRC_DIR)/io_generic.h
cmd_navigation.$O: $(SRC_DIR)/ktb.h
cmd_navigation.$O: $(SRC_DIR)/menu.h
cmd_navigation.$O: $(SRC_DIR)/pid.h
cmd_navigation.$O: $(SRC_DIR)/program.h
cmd_navigation.$O: $(SRC_DIR)/serialdefs.h
cmd_navigation.$O: $(SRC_DIR)/ses.h
cmd_navigation.$O: $(SRC_DIR)/spk.h
cmd_navigation.$O: $(SRC_DIR)/spkdefs.h
cmd_navigation.$O: $(SRC_DIR)/timing.h
cmd_navigation.$O: $(SRC_DIR)/usbdefs.h

# Dependencies for cmd_queue.$O:
cmd_queue.$O: $(SRC_DIR)/cmd_queue.c
cmd_queue.$O: $(BLD_TOP)config.h
cmd_queue.$O: $(BLD_TOP)forbuild.h
cmd_queue.$O: $(SRC_TOP)prologue.h
cmd_queue.$O: $(SRC_DIR)/log.h
cmd_queue.$O: $(SRC_DIR)/cmd_queue.h
cmd_queue.$O: $(SRC_DIR)/ktbdefs.h
cmd_queue.$O: $(SRC_DIR)/queue.h
cmd_queue.$O: $(SRC_DIR)/async.h
cmd_queue.$O: $(SRC_DIR)/async_alarm.h
cmd_queue.$O: $(SRC_DIR)/timing.h
cmd_queue.$O: $(SRC_DIR)/prefs.h
cmd_queue.$O: $(SRC_DIR)/api_control.h
cmd_queue.$O: $(SRC_DIR)/async_io.h
cmd_queue.$O: $(SRC_DIR)/brl.h
cmd_queue.$O: $(SRC_DIR)/brldefs.h
cmd_queue.$O: $(SRC_DIR)/driver.h
cmd_queue.$O: $(SRC_DIR)/io_generic.h
cmd_queue.$O: $(SRC_DIR)/serialdefs.h
cmd_queue.$O: $(SRC_DIR)/usbdefs.h
cmd_queue.$O: $(SRC_DIR)/scr.h
cmd_queue.$O: $(SRC_DIR)/scrdefs.h
cmd_queue.$O: brlapi_constants.h
cmd_queue.$O: $(SRC_DIR)/brlapi_keycodes.h
cmd_queue.$O: $(SRC_DIR)/brltty.h
cmd_queue.$O: $(SRC_DIR)/cmd.h
cmd_queue.$O: $(SRC_DIR)/cmddefs.h
cmd_queue.$O: $(SRC_DIR)/ctb.h
cmd_queue.$O: $(SRC_DIR)/ctbdefs.h
cmd_queue.$O: $(SRC_DIR)/ktb.h
cmd_queue.$O: $(SRC_DIR)/menu.h
cmd_queue.$O: $(SRC_DIR)/pid.h
cmd_queue.$O: $(SRC_DIR)/program.h
cmd_queue.$O: $(SRC_DIR)/ses.h
cmd_queue.$O: $(SRC_DIR)/spk.h
cmd_queue.$O: $(SRC_DIR)/spkdefs.h
cmd_queue.$O: $(SRC_DIR)/tunedefs.h
cmd_queue.$O: $(SRC_DIR)/tunes.h

# Dependencies for cmd_speech.$O:
cmd_speech.$O: $(SRC_DIR)/cmd_speech.c
cmd_speech.$O: $(BLD_TOP)config.h
cmd_speech.$O: $(BLD_TOP)forbuild.h
cmd_speech.$O: $(SRC_TOP)prologue.h
cmd_speech.$O: $(SRC_DIR)/cmd_queue.h
cmd_speech.$O: $(SRC_DIR)/cmd_speech.h
cmd_speech.$O: $(SRC_DIR)/ktbdefs.h
cmd_speech.$O: $(SRC_DIR)/prefs.h
cmd_speech.$O: $(SRC_DIR)/tunedefs.h
cmd_speech.$O: $(SRC_DIR)/tunes.h
cmd_speech.$O: $(SRC_DIR)/brldefs.h
cmd_speech.$O: $(SRC_DIR)/driver.h
cmd_speech.$O: $(SRC_DIR)/spk.h
cmd_speech.$O: $(SRC_DIR)/spkdefs.h
cmd_speech.$O: $(SRC_DIR)/scr.h
cmd_speech.$O: $(SRC_DIR)/scrdefs.h
cmd_speech.$O: $(SRC_DIR)/async.h
cmd_speech.$O: $(SRC_DIR)/async_io.h
cmd_speech.$O: $(SRC_DIR)/brl.h
cmd_speech.$O: brlapi_constants.h
cmd_speech.$O: $(SRC_DIR)/brlapi_keycodes.h
cmd_speech.$O: $(SRC_DIR)/brltty.h
cmd_speech.$O: $(SRC_DIR)/cmd.h
cmd_speech.$O: $(SRC_DIR)/cmddefs.h
cmd_speech.$O: $(SRC_DIR)/ctb.h
cmd_speech.$O: $(SRC_DIR)/ctbdefs.h
cmd_speech.$O: $(SRC_DIR)/io_generic.h
cmd_speech.$O: $(SRC_DIR)/ktb.h
cmd_speech.$O: $(SRC_DIR)/menu.h
cmd_speech.$O: $(SRC_DIR)/pid.h
cmd_speech.$O: $(SRC_DIR)/program.h
cmd_speech.$O: $(SRC_DIR)/serialdefs.h
cmd_speech.$O: $(SRC_DIR)/ses.h
cmd_speech.$O: $(SRC_DIR)/timing.h
cmd_speech.$O: $(SRC_DIR)/usbdefs.h

# Dependencies for config.$O:
config.$O: $(SRC_DIR)/config.c
config.$O: $(BLD_TOP)config.h
config.$O: $(BLD_TOP)forbuild.h
config.$O: $(SRC_TOP)prologue.h
config.$O: $(SRC_DIR)/parameters.h
config.$O: $(SRC_DIR)/update.h
config.$O: brlapi_constants.h
config.$O: $(SRC_DIR)/brlapi_keycodes.h
config.$O: $(SRC_DIR)/cmd.h
config.$O: $(SRC_DIR)/cmddefs.h
config.$O: $(SRC_DIR)/async.h
config.$O: $(SRC_DIR)/async_io.h
config.$O: $(SRC_DIR)/brl.h
config.$O: $(SRC_DIR)/brldefs.h
config.$O: $(SRC_DIR)/driver.h
config.$O: $(SRC_DIR)/io_generic.h
config.$O: $(SRC_DIR)/ktbdefs.h
config.$O: $(SRC_DIR)/serialdefs.h
config.$O: $(SRC_DIR)/usbdefs.h
config.$O: $(SRC_DIR)/spk.h
config.$O: $(SRC_DIR)/spkdefs.h
config.$O: $(SRC_DIR)/spk_input.h
config.$O: $(SRC_DIR)/cmd_queue.h
config.$O: $(SRC_DIR)/scr.h
config.$O: $(SRC_DIR)/scrdefs.h
config.$O: $(SRC_DIR)/statdefs.h
config.$O: $(SRC_DIR)/status.h
config.$O: $(SRC_DIR)/blink.h
config.$O: $(SRC_DIR)/datafile.h
config.$O: $(SRC_DIR)/queue.h
config.$O: $(SRC_DIR)/ttb.h
config.$O: $(SRC_DIR)/atb.h
config.$O: $(SRC_DIR)/ctb.h
config.$O: $(SRC_DIR)/ctbdefs.h
config.$O: $(SRC_DIR)/ktb.h
config.$O: $(SRC_DIR)/ktb_keyboard.h
config.$O: $(SRC_DIR)/keyboard.h
config.$O: $(SRC_DIR)/tunedefs.h
config.$O: $(SRC_DIR)/tunes.h
config.$O: $(SRC_DIR)/notes.h
config.$O: $(SRC_DIR)/message.h
config.$O: $(SRC_DIR)/log.h
config.$O: $(SRC_DIR)/file.h
config.$O: $(SRC_DIR)/parse.h
config.$O: $(SRC_DIR)/dynld.h
config.$O: $(SRC_DIR)/async_alarm.h
config.$O: $(SRC_DIR)/timing.h
config.$O: $(SRC_DIR)/pid.h
config.$O: $(SRC_DIR)/program.h
config.$O: $(SRC_DIR)/service.h
config.$O: $(SRC_DIR)/options.h
config.$O: $(SRC_DIR)/brl_input.h
config.$O: $(SRC_DIR)/brltty.h
config.$O: $(SRC_DIR)/menu.h
config.$O: $(SRC_DIR)/prefs.h
config.$O: $(SRC_DIR)/ses.h
config.$O: $(SRC_DIR)/api_control.h
config.$O: $(SRC_DIR)/charset.h
config.$O: $(SRC_DIR)/lock.h
config.$O: $(SRC_DIR)/io_serial.h
config.$O: $(SRC_DIR)/io_usb.h
config.$O: $(SRC_DIR)/io_bluetooth.h
config.$O: $(SRC_DIR)/system_msdos.h

# Dependencies for ctb_compile.$O:
ctb_compile.$O: $(SRC_DIR)/ctb_compile.c
ctb_compile.$O: $(BLD_TOP)config.h
ctb_compile.$O: $(BLD_TOP)forbuild.h
ctb_compile.$O: $(SRC_TOP)prologue.h
ctb_compile.$O: $(SRC_DIR)/log.h
ctb_compile.$O: $(SRC_DIR)/file.h
ctb_compile.$O: $(SRC_DIR)/ctb.h
ctb_compile.$O: $(SRC_DIR)/ctbdefs.h
ctb_compile.$O: $(SRC_DIR)/ctb_internal.h
ctb_compile.$O: $(SRC_DIR)/datafile.h
ctb_compile.$O: $(SRC_DIR)/queue.h
ctb_compile.$O: $(SRC_DIR)/dataarea.h
ctb_compile.$O: $(SRC_DIR)/brldots.h
ctb_compile.$O: $(SRC_DIR)/hostcmd.h

# Dependencies for ctb_translate.$O:
ctb_translate.$O: $(SRC_DIR)/ctb_translate.c
ctb_translate.$O: $(BLD_TOP)config.h
ctb_translate.$O: $(BLD_TOP)forbuild.h
ctb_translate.$O: $(SRC_TOP)prologue.h
ctb_translate.$O: $(SRC_DIR)/ctb.h
ctb_translate.$O: $(SRC_DIR)/ctbdefs.h
ctb_translate.$O: $(SRC_DIR)/ctb_internal.h
ctb_translate.$O: $(SRC_DIR)/ttb.h
ctb_translate.$O: $(SRC_DIR)/prefs.h
ctb_translate.$O: $(SRC_DIR)/unicode.h
ctb_translate.$O: $(SRC_DIR)/charset.h
ctb_translate.$O: $(SRC_DIR)/lock.h
ctb_translate.$O: $(SRC_DIR)/ascii.h
ctb_translate.$O: $(SRC_DIR)/brldots.h
ctb_translate.$O: $(SRC_DIR)/log.h
ctb_translate.$O: $(SRC_DIR)/file.h
ctb_translate.$O: $(SRC_DIR)/parse.h

# Dependencies for dataarea.$O:
dataarea.$O: $(SRC_DIR)/dataarea.c
dataarea.$O: $(BLD_TOP)config.h
dataarea.$O: $(BLD_TOP)forbuild.h
dataarea.$O: $(SRC_TOP)prologue.h
dataarea.$O: $(SRC_DIR)/log.h
dataarea.$O: $(SRC_DIR)/dataarea.h

# Dependencies for datafile.$O:
datafile.$O: $(SRC_DIR)/datafile.c
datafile.$O: $(BLD_TOP)config.h
datafile.$O: $(BLD_TOP)forbuild.h
datafile.$O: $(SRC_TOP)prologue.h
datafile.$O: $(SRC_DIR)/log.h
datafile.$O: $(SRC_DIR)/file.h
datafile.$O: $(SRC_DIR)/queue.h
datafile.$O: $(SRC_DIR)/datafile.h
datafile.$O: $(SRC_DIR)/charset.h
datafile.$O: $(SRC_DIR)/lock.h
datafile.$O: $(SRC_DIR)/unicode.h
datafile.$O: $(SRC_DIR)/brldots.h

# Dependencies for device.$O:
device.$O: $(SRC_DIR)/device.c
device.$O: $(BLD_TOP)config.h
device.$O: $(BLD_TOP)forbuild.h
device.$O: $(SRC_TOP)prologue.h
device.$O: $(SRC_DIR)/log.h
device.$O: $(SRC_DIR)/device.h
device.$O: $(SRC_DIR)/file.h
device.$O: $(SRC_DIR)/parse.h

# Dependencies for driver.$O:
driver.$O: $(SRC_DIR)/driver.c
driver.$O: $(BLD_TOP)config.h
driver.$O: $(BLD_TOP)forbuild.h
driver.$O: $(SRC_TOP)prologue.h
driver.$O: $(SRC_DIR)/log.h
driver.$O: $(SRC_DIR)/driver.h

# Dependencies for drivers.$O:
drivers.$O: $(SRC_DIR)/drivers.c
drivers.$O: $(BLD_TOP)config.h
drivers.$O: $(BLD_TOP)forbuild.h
drivers.$O: $(SRC_TOP)prologue.h
drivers.$O: $(SRC_DIR)/log.h
drivers.$O: $(SRC_DIR)/file.h
drivers.$O: $(SRC_DIR)/dynld.h
drivers.$O: $(SRC_DIR)/driver.h
drivers.$O: $(SRC_DIR)/drivers.h

# Dependencies for dynld_dlfcn.$O:
dynld_dlfcn.$O: $(SRC_DIR)/dynld_dlfcn.c
dynld_dlfcn.$O: $(BLD_TOP)config.h
dynld_dlfcn.$O: $(BLD_TOP)forbuild.h
dynld_dlfcn.$O: $(SRC_TOP)prologue.h
dynld_dlfcn.$O: $(SRC_DIR)/log.h
dynld_dlfcn.$O: $(SRC_DIR)/dynld.h

# Dependencies for dynld_dyld.$O:
dynld_dyld.$O: $(SRC_DIR)/dynld_dyld.c
dynld_dyld.$O: $(BLD_TOP)config.h
dynld_dyld.$O: $(BLD_TOP)forbuild.h
dynld_dyld.$O: $(SRC_TOP)prologue.h
dynld_dyld.$O: $(SRC_DIR)/log.h
dynld_dyld.$O: $(SRC_DIR)/dynld.h

# Dependencies for dynld_grub.$O:
dynld_grub.$O: $(SRC_DIR)/dynld_grub.c
dynld_grub.$O: $(BLD_TOP)config.h
dynld_grub.$O: $(BLD_TOP)forbuild.h
dynld_grub.$O: $(SRC_TOP)prologue.h
dynld_grub.$O: $(SRC_DIR)/dynld.h

# Dependencies for dynld_none.$O:
dynld_none.$O: $(SRC_DIR)/dynld_none.c
dynld_none.$O: $(BLD_TOP)config.h
dynld_none.$O: $(BLD_TOP)forbuild.h
dynld_none.$O: $(SRC_TOP)prologue.h
dynld_none.$O: $(SRC_DIR)/dynld.h

# Dependencies for dynld_shl.$O:
dynld_shl.$O: $(SRC_DIR)/dynld_shl.c
dynld_shl.$O: $(BLD_TOP)config.h
dynld_shl.$O: $(BLD_TOP)forbuild.h
dynld_shl.$O: $(SRC_TOP)prologue.h
dynld_shl.$O: $(SRC_DIR)/log.h
dynld_shl.$O: $(SRC_DIR)/dynld.h

# Dependencies for dynld_windows.$O:
dynld_windows.$O: $(SRC_DIR)/dynld_windows.c
dynld_windows.$O: $(BLD_TOP)config.h
dynld_windows.$O: $(BLD_TOP)forbuild.h
dynld_windows.$O: $(SRC_TOP)prologue.h
dynld_windows.$O: $(SRC_DIR)/log.h
dynld_windows.$O: $(SRC_DIR)/dynld.h

# Dependencies for file.$O:
file.$O: $(SRC_DIR)/file.c
file.$O: $(BLD_TOP)config.h
file.$O: $(BLD_TOP)forbuild.h
file.$O: $(SRC_TOP)prologue.h
file.$O: $(SRC_DIR)/parameters.h
file.$O: $(SRC_DIR)/file.h
file.$O: $(SRC_DIR)/log.h
file.$O: $(SRC_DIR)/parse.h
file.$O: $(SRC_DIR)/async.h
file.$O: $(SRC_DIR)/async_wait.h
file.$O: $(SRC_DIR)/charset.h
file.$O: $(SRC_DIR)/lock.h
file.$O: $(SRC_DIR)/pid.h
file.$O: $(SRC_DIR)/program.h

# Dependencies for fm_adlib.$O:
fm_adlib.$O: $(SRC_DIR)/fm_adlib.c
fm_adlib.$O: $(BLD_TOP)config.h
fm_adlib.$O: $(BLD_TOP)forbuild.h
fm_adlib.$O: $(SRC_TOP)prologue.h
fm_adlib.$O: $(SRC_DIR)/log.h
fm_adlib.$O: $(SRC_DIR)/timing.h
fm_adlib.$O: $(SRC_DIR)/ports.h
fm_adlib.$O: $(SRC_DIR)/fm.h
fm_adlib.$O: $(SRC_DIR)/fm_adlib.h

# Dependencies for fm_none.$O:
fm_none.$O: $(SRC_DIR)/fm_none.c
fm_none.$O: $(BLD_TOP)config.h
fm_none.$O: $(BLD_TOP)forbuild.h
fm_none.$O: $(SRC_TOP)prologue.h
fm_none.$O: $(SRC_DIR)/fm.h

# Dependencies for gio.$O:
gio.$O: $(SRC_DIR)/gio.c
gio.$O: $(BLD_TOP)config.h
gio.$O: $(BLD_TOP)forbuild.h
gio.$O: $(SRC_TOP)prologue.h
gio.$O: $(SRC_DIR)/log.h
gio.$O: $(SRC_DIR)/async.h
gio.$O: $(SRC_DIR)/async_wait.h
gio.$O: $(SRC_DIR)/async_io.h
gio.$O: $(SRC_DIR)/io_generic.h
gio.$O: $(SRC_DIR)/serialdefs.h
gio.$O: $(SRC_DIR)/usbdefs.h
gio.$O: $(SRC_DIR)/gio_internal.h
gio.$O: $(SRC_DIR)/io_serial.h

# Dependencies for gio_bluetooth.$O:
gio_bluetooth.$O: $(SRC_DIR)/gio_bluetooth.c
gio_bluetooth.$O: $(BLD_TOP)config.h
gio_bluetooth.$O: $(BLD_TOP)forbuild.h
gio_bluetooth.$O: $(SRC_TOP)prologue.h
gio_bluetooth.$O: $(SRC_DIR)/log.h
gio_bluetooth.$O: $(SRC_DIR)/async.h
gio_bluetooth.$O: $(SRC_DIR)/async_io.h
gio_bluetooth.$O: $(SRC_DIR)/io_generic.h
gio_bluetooth.$O: $(SRC_DIR)/serialdefs.h
gio_bluetooth.$O: $(SRC_DIR)/usbdefs.h
gio_bluetooth.$O: $(SRC_DIR)/gio_internal.h
gio_bluetooth.$O: $(SRC_DIR)/io_bluetooth.h

# Dependencies for gio_serial.$O:
gio_serial.$O: $(SRC_DIR)/gio_serial.c
gio_serial.$O: $(BLD_TOP)config.h
gio_serial.$O: $(BLD_TOP)forbuild.h
gio_serial.$O: $(SRC_TOP)prologue.h
gio_serial.$O: $(SRC_DIR)/log.h
gio_serial.$O: $(SRC_DIR)/async.h
gio_serial.$O: $(SRC_DIR)/async_io.h
gio_serial.$O: $(SRC_DIR)/io_generic.h
gio_serial.$O: $(SRC_DIR)/serialdefs.h
gio_serial.$O: $(SRC_DIR)/usbdefs.h
gio_serial.$O: $(SRC_DIR)/gio_internal.h
gio_serial.$O: $(SRC_DIR)/io_serial.h

# Dependencies for gio_usb.$O:
gio_usb.$O: $(SRC_DIR)/gio_usb.c
gio_usb.$O: $(BLD_TOP)config.h
gio_usb.$O: $(BLD_TOP)forbuild.h
gio_usb.$O: $(SRC_TOP)prologue.h
gio_usb.$O: $(SRC_DIR)/timing.h
gio_usb.$O: $(SRC_DIR)/win_pthread.h
gio_usb.$O: $(SRC_DIR)/log.h
gio_usb.$O: $(SRC_DIR)/parameters.h
gio_usb.$O: $(SRC_DIR)/async.h
gio_usb.$O: $(SRC_DIR)/async_io.h
gio_usb.$O: $(SRC_DIR)/io_generic.h
gio_usb.$O: $(SRC_DIR)/serialdefs.h
gio_usb.$O: $(SRC_DIR)/usbdefs.h
gio_usb.$O: $(SRC_DIR)/gio_internal.h
gio_usb.$O: $(SRC_DIR)/io_usb.h

# Dependencies for hidkeys.$O:
hidkeys.$O: $(SRC_DIR)/hidkeys.c
hidkeys.$O: $(BLD_TOP)config.h
hidkeys.$O: $(BLD_TOP)forbuild.h
hidkeys.$O: $(SRC_TOP)prologue.h
hidkeys.$O: $(SRC_DIR)/hidkeys.h
hidkeys.$O: $(SRC_DIR)/bitmask.h
hidkeys.$O: $(SRC_DIR)/brldefs.h
hidkeys.$O: $(SRC_DIR)/cmd_queue.h
hidkeys.$O: $(SRC_DIR)/ktbdefs.h

# Dependencies for hostcmd.$O:
hostcmd.$O: $(SRC_DIR)/hostcmd.c
hostcmd.$O: $(BLD_TOP)config.h
hostcmd.$O: $(BLD_TOP)forbuild.h
hostcmd.$O: $(SRC_TOP)prologue.h
hostcmd.$O: $(SRC_DIR)/log.h
hostcmd.$O: $(SRC_DIR)/hostcmd.h
hostcmd.$O: $(SRC_DIR)/hostcmd_none.h
hostcmd.$O: $(SRC_DIR)/hostcmd_unix.h
hostcmd.$O: $(SRC_DIR)/hostcmd_windows.h
hostcmd.$O: $(SRC_DIR)/hostcmd_internal.h

# Dependencies for hostcmd_none.$O:
hostcmd_none.$O: $(SRC_DIR)/hostcmd_none.c
hostcmd_none.$O: $(BLD_TOP)config.h
hostcmd_none.$O: $(BLD_TOP)forbuild.h
hostcmd_none.$O: $(SRC_TOP)prologue.h
hostcmd_none.$O: $(SRC_DIR)/hostcmd_none.h
hostcmd_none.$O: $(SRC_DIR)/hostcmd_internal.h

# Dependencies for hostcmd_unix.$O:
hostcmd_unix.$O: $(SRC_DIR)/hostcmd_unix.c
hostcmd_unix.$O: $(BLD_TOP)config.h
hostcmd_unix.$O: $(BLD_TOP)forbuild.h
hostcmd_unix.$O: $(SRC_TOP)prologue.h
hostcmd_unix.$O: $(SRC_DIR)/log.h
hostcmd_unix.$O: $(SRC_DIR)/hostcmd_unix.h
hostcmd_unix.$O: $(SRC_DIR)/hostcmd_internal.h

# Dependencies for hostcmd_windows.$O:
hostcmd_windows.$O: $(SRC_DIR)/hostcmd_windows.c
hostcmd_windows.$O: $(BLD_TOP)config.h
hostcmd_windows.$O: $(BLD_TOP)forbuild.h
hostcmd_windows.$O: $(SRC_TOP)prologue.h
hostcmd_windows.$O: $(SRC_DIR)/log.h
hostcmd_windows.$O: $(SRC_DIR)/system_windows.h
hostcmd_windows.$O: $(SRC_DIR)/hostcmd_windows.h
hostcmd_windows.$O: $(SRC_DIR)/hostcmd_internal.h

# Dependencies for io_misc.$O:
io_misc.$O: $(SRC_DIR)/io_misc.c
io_misc.$O: $(BLD_TOP)config.h
io_misc.$O: $(BLD_TOP)forbuild.h
io_misc.$O: $(SRC_TOP)prologue.h
io_misc.$O: $(SRC_DIR)/io_misc.h
io_misc.$O: $(SRC_DIR)/log.h
io_misc.$O: $(SRC_DIR)/file.h
io_misc.$O: $(SRC_DIR)/async.h
io_misc.$O: $(SRC_DIR)/async_wait.h
io_misc.$O: $(SRC_DIR)/async_io.h

# Dependencies for keyboard.$O:
keyboard.$O: $(SRC_DIR)/keyboard.c
keyboard.$O: $(BLD_TOP)config.h
keyboard.$O: $(BLD_TOP)forbuild.h
keyboard.$O: $(SRC_TOP)prologue.h
keyboard.$O: $(SRC_DIR)/log.h
keyboard.$O: $(SRC_DIR)/parse.h
keyboard.$O: $(SRC_DIR)/bitmask.h
keyboard.$O: $(SRC_DIR)/keyboard.h
keyboard.$O: $(SRC_DIR)/ktbdefs.h
keyboard.$O: $(SRC_DIR)/keyboard_internal.h
keyboard.$O: $(SRC_DIR)/ktb_keyboard.h

# Dependencies for keyboard_android.$O:
keyboard_android.$O: $(SRC_DIR)/keyboard_android.c
keyboard_android.$O: $(BLD_TOP)config.h
keyboard_android.$O: $(BLD_TOP)forbuild.h
keyboard_android.$O: $(SRC_TOP)prologue.h
keyboard_android.$O: $(SRC_DIR)/log.h
keyboard_android.$O: $(SRC_DIR)/system_java.h
keyboard_android.$O: $(SRC_DIR)/keyboard.h
keyboard_android.$O: $(SRC_DIR)/ktbdefs.h
keyboard_android.$O: $(SRC_DIR)/keyboard_internal.h
keyboard_android.$O: $(SRC_DIR)/ktb_keyboard.h
keyboard_android.$O: $(SRC_DIR)/keyboard_android.h

# Dependencies for keyboard_linux.$O:
keyboard_linux.$O: $(SRC_DIR)/keyboard_linux.c
keyboard_linux.$O: $(BLD_TOP)config.h
keyboard_linux.$O: $(BLD_TOP)forbuild.h
keyboard_linux.$O: $(SRC_TOP)prologue.h
keyboard_linux.$O: $(SRC_DIR)/log.h
keyboard_linux.$O: $(SRC_DIR)/parameters.h
keyboard_linux.$O: $(SRC_DIR)/system_linux.h
keyboard_linux.$O: $(SRC_DIR)/keyboard.h
keyboard_linux.$O: $(SRC_DIR)/ktbdefs.h
keyboard_linux.$O: $(SRC_DIR)/keyboard_internal.h
keyboard_linux.$O: $(SRC_DIR)/ktb_keyboard.h
keyboard_linux.$O: $(SRC_DIR)/async.h
keyboard_linux.$O: $(SRC_DIR)/async_alarm.h
keyboard_linux.$O: $(SRC_DIR)/timing.h
keyboard_linux.$O: $(SRC_DIR)/async_io.h

# Dependencies for keyboard_none.$O:
keyboard_none.$O: $(SRC_DIR)/keyboard_none.c
keyboard_none.$O: $(BLD_TOP)config.h
keyboard_none.$O: $(BLD_TOP)forbuild.h
keyboard_none.$O: $(SRC_TOP)prologue.h
keyboard_none.$O: $(SRC_DIR)/keyboard.h
keyboard_none.$O: $(SRC_DIR)/ktbdefs.h
keyboard_none.$O: $(SRC_DIR)/keyboard_internal.h
keyboard_none.$O: $(SRC_DIR)/ktb_keyboard.h

# Dependencies for ktb_compile.$O:
ktb_compile.$O: $(SRC_DIR)/ktb_compile.c
ktb_compile.$O: $(BLD_TOP)config.h
ktb_compile.$O: $(BLD_TOP)forbuild.h
ktb_compile.$O: $(SRC_TOP)prologue.h
ktb_compile.$O: $(SRC_DIR)/log.h
ktb_compile.$O: $(SRC_DIR)/file.h
ktb_compile.$O: $(SRC_DIR)/datafile.h
ktb_compile.$O: $(SRC_DIR)/queue.h
ktb_compile.$O: brlapi_constants.h
ktb_compile.$O: $(SRC_DIR)/brlapi_keycodes.h
ktb_compile.$O: $(SRC_DIR)/cmd.h
ktb_compile.$O: $(SRC_DIR)/cmddefs.h
ktb_compile.$O: $(SRC_DIR)/brldefs.h
ktb_compile.$O: $(SRC_DIR)/ktb.h
ktb_compile.$O: $(SRC_DIR)/ktbdefs.h
ktb_compile.$O: $(SRC_DIR)/async.h
ktb_compile.$O: $(SRC_DIR)/ktb_internal.h
ktb_compile.$O: $(SRC_DIR)/pid.h
ktb_compile.$O: $(SRC_DIR)/program.h

# Dependencies for ktb_keyboard.$O:
ktb_keyboard.$O: $(SRC_DIR)/ktb_keyboard.c
ktb_keyboard.$O: $(BLD_TOP)config.h
ktb_keyboard.$O: $(BLD_TOP)forbuild.h
ktb_keyboard.$O: $(SRC_TOP)prologue.h
ktb_keyboard.$O: $(SRC_DIR)/ktb_keyboard.h
ktb_keyboard.$O: $(SRC_DIR)/ktbdefs.h

# Dependencies for ktb_list.$O:
ktb_list.$O: $(SRC_DIR)/ktb_list.c
ktb_list.$O: $(BLD_TOP)config.h
ktb_list.$O: $(BLD_TOP)forbuild.h
ktb_list.$O: $(SRC_TOP)prologue.h
ktb_list.$O: $(SRC_DIR)/log.h
ktb_list.$O: $(SRC_DIR)/charset.h
ktb_list.$O: $(SRC_DIR)/lock.h
ktb_list.$O: brlapi_constants.h
ktb_list.$O: $(SRC_DIR)/brlapi_keycodes.h
ktb_list.$O: $(SRC_DIR)/cmd.h
ktb_list.$O: $(SRC_DIR)/cmddefs.h
ktb_list.$O: $(SRC_DIR)/ktb.h
ktb_list.$O: $(SRC_DIR)/ktbdefs.h
ktb_list.$O: $(SRC_DIR)/async.h
ktb_list.$O: $(SRC_DIR)/ktb_internal.h
ktb_list.$O: $(SRC_DIR)/brldefs.h
ktb_list.$O: $(SRC_DIR)/ktb_inspect.h

# Dependencies for ktb_translate.$O:
ktb_translate.$O: $(SRC_DIR)/ktb_translate.c
ktb_translate.$O: $(BLD_TOP)config.h
ktb_translate.$O: $(BLD_TOP)forbuild.h
ktb_translate.$O: $(SRC_TOP)prologue.h
ktb_translate.$O: $(SRC_DIR)/log.h
ktb_translate.$O: $(SRC_DIR)/prefs.h
ktb_translate.$O: $(SRC_DIR)/ktb.h
ktb_translate.$O: $(SRC_DIR)/ktbdefs.h
ktb_translate.$O: $(SRC_DIR)/async.h
ktb_translate.$O: $(SRC_DIR)/cmddefs.h
ktb_translate.$O: $(SRC_DIR)/ktb_internal.h
ktb_translate.$O: $(SRC_DIR)/brldefs.h
ktb_translate.$O: $(SRC_DIR)/ktb_inspect.h
ktb_translate.$O: brlapi_constants.h
ktb_translate.$O: $(SRC_DIR)/brlapi_keycodes.h
ktb_translate.$O: $(SRC_DIR)/cmd.h
ktb_translate.$O: $(SRC_DIR)/cmd_queue.h
ktb_translate.$O: $(SRC_DIR)/async_alarm.h
ktb_translate.$O: $(SRC_DIR)/timing.h

# Dependencies for ktbtest.$O:
ktbtest.$O: $(SRC_DIR)/ktbtest.c
ktbtest.$O: $(BLD_TOP)config.h
ktbtest.$O: $(BLD_TOP)forbuild.h
ktbtest.$O: $(SRC_TOP)prologue.h
ktbtest.$O: $(SRC_DIR)/pid.h
ktbtest.$O: $(SRC_DIR)/program.h
ktbtest.$O: $(SRC_DIR)/options.h
ktbtest.$O: $(SRC_DIR)/log.h
ktbtest.$O: $(SRC_DIR)/file.h
ktbtest.$O: $(SRC_DIR)/parse.h
ktbtest.$O: $(SRC_DIR)/dynld.h
ktbtest.$O: $(SRC_DIR)/ktb.h
ktbtest.$O: $(SRC_DIR)/ktbdefs.h
ktbtest.$O: $(SRC_DIR)/ktb_keyboard.h
ktbtest.$O: $(SRC_DIR)/async.h
ktbtest.$O: $(SRC_DIR)/async_io.h
ktbtest.$O: $(SRC_DIR)/brl.h
ktbtest.$O: $(SRC_DIR)/brldefs.h
ktbtest.$O: $(SRC_DIR)/driver.h
ktbtest.$O: $(SRC_DIR)/io_generic.h
ktbtest.$O: $(SRC_DIR)/serialdefs.h
ktbtest.$O: $(SRC_DIR)/usbdefs.h
ktbtest.$O: brlapi_constants.h
ktbtest.$O: $(SRC_DIR)/brlapi_keycodes.h
ktbtest.$O: $(SRC_DIR)/brltty.h
ktbtest.$O: $(SRC_DIR)/cmd.h
ktbtest.$O: $(SRC_DIR)/cmddefs.h
ktbtest.$O: $(SRC_DIR)/ctb.h
ktbtest.$O: $(SRC_DIR)/ctbdefs.h
ktbtest.$O: $(SRC_DIR)/menu.h
ktbtest.$O: $(SRC_DIR)/prefs.h
ktbtest.$O: $(SRC_DIR)/scrdefs.h
ktbtest.$O: $(SRC_DIR)/ses.h
ktbtest.$O: $(SRC_DIR)/spk.h
ktbtest.$O: $(SRC_DIR)/spkdefs.h
ktbtest.$O: $(SRC_DIR)/timing.h
ktbtest.$O: $(SRC_DIR)/tunedefs.h
ktbtest.$O: $(SRC_DIR)/tunes.h
ktbtest.$O: $(SRC_DIR)/message.h

# Dependencies for lock.$O:
lock.$O: $(SRC_DIR)/lock.c
lock.$O: $(BLD_TOP)config.h
lock.$O: $(BLD_TOP)forbuild.h
lock.$O: $(SRC_TOP)prologue.h
lock.$O: $(SRC_DIR)/timing.h
lock.$O: $(SRC_DIR)/win_pthread.h
lock.$O: $(SRC_DIR)/lock.h
lock.$O: $(SRC_DIR)/log.h

# Dependencies for log.$O:
log.$O: $(SRC_DIR)/log.c
log.$O: $(BLD_TOP)config.h
log.$O: $(BLD_TOP)forbuild.h
log.$O: $(SRC_TOP)prologue.h
log.$O: $(SRC_DIR)/log.h
log.$O: $(SRC_DIR)/timing.h
log.$O: $(SRC_DIR)/addresses.h

# Dependencies for main.$O:
main.$O: $(SRC_DIR)/main.c
main.$O: $(BLD_TOP)config.h
main.$O: $(BLD_TOP)forbuild.h
main.$O: $(SRC_TOP)prologue.h
main.$O: $(SRC_DIR)/async.h
main.$O: $(SRC_DIR)/async_io.h
main.$O: $(SRC_DIR)/brl.h
main.$O: brlapi_constants.h
main.$O: $(SRC_DIR)/brlapi_keycodes.h
main.$O: $(SRC_DIR)/brldefs.h
main.$O: $(SRC_DIR)/brltty.h
main.$O: $(SRC_DIR)/cmd.h
main.$O: $(SRC_DIR)/cmddefs.h
main.$O: $(SRC_DIR)/ctb.h
main.$O: $(SRC_DIR)/ctbdefs.h
main.$O: $(SRC_DIR)/driver.h
main.$O: $(SRC_DIR)/embed.h
main.$O: $(SRC_DIR)/io_generic.h
main.$O: $(SRC_DIR)/ktb.h
main.$O: $(SRC_DIR)/ktbdefs.h
main.$O: $(SRC_DIR)/menu.h
main.$O: $(SRC_DIR)/pid.h
main.$O: $(SRC_DIR)/prefs.h
main.$O: $(SRC_DIR)/program.h
main.$O: $(SRC_DIR)/scrdefs.h
main.$O: $(SRC_DIR)/serialdefs.h
main.$O: $(SRC_DIR)/ses.h
main.$O: $(SRC_DIR)/spk.h
main.$O: $(SRC_DIR)/spkdefs.h
main.$O: $(SRC_DIR)/timing.h
main.$O: $(SRC_DIR)/tunedefs.h
main.$O: $(SRC_DIR)/tunes.h
main.$O: $(SRC_DIR)/usbdefs.h
main.$O: $(SRC_DIR)/log.h

# Dependencies for menu.$O:
menu.$O: $(SRC_DIR)/menu.c
menu.$O: $(BLD_TOP)config.h
menu.$O: $(BLD_TOP)forbuild.h
menu.$O: $(SRC_TOP)prologue.h
menu.$O: $(SRC_DIR)/log.h
menu.$O: $(SRC_DIR)/file.h
menu.$O: $(SRC_DIR)/menu.h
menu.$O: $(SRC_DIR)/prefs.h
menu.$O: $(SRC_DIR)/parse.h

# Dependencies for menu_prefs.$O:
menu_prefs.$O: $(SRC_DIR)/menu_prefs.c
menu_prefs.$O: $(BLD_TOP)config.h
menu_prefs.$O: $(BLD_TOP)forbuild.h
menu_prefs.$O: $(SRC_TOP)prologue.h
menu_prefs.$O: $(SRC_DIR)/log.h
menu_prefs.$O: $(SRC_DIR)/menu.h
menu_prefs.$O: $(SRC_DIR)/prefs.h
menu_prefs.$O: $(SRC_DIR)/statdefs.h
menu_prefs.$O: $(SRC_DIR)/async.h
menu_prefs.$O: $(SRC_DIR)/async_io.h
menu_prefs.$O: $(SRC_DIR)/brl.h
menu_prefs.$O: brlapi_constants.h
menu_prefs.$O: $(SRC_DIR)/brlapi_keycodes.h
menu_prefs.$O: $(SRC_DIR)/brldefs.h
menu_prefs.$O: $(SRC_DIR)/brltty.h
menu_prefs.$O: $(SRC_DIR)/cmd.h
menu_prefs.$O: $(SRC_DIR)/cmddefs.h
menu_prefs.$O: $(SRC_DIR)/ctb.h
menu_prefs.$O: $(SRC_DIR)/ctbdefs.h
menu_prefs.$O: $(SRC_DIR)/driver.h
menu_prefs.$O: $(SRC_DIR)/io_generic.h
menu_prefs.$O: $(SRC_DIR)/ktb.h
menu_prefs.$O: $(SRC_DIR)/ktbdefs.h
menu_prefs.$O: $(SRC_DIR)/pid.h
menu_prefs.$O: $(SRC_DIR)/program.h
menu_prefs.$O: $(SRC_DIR)/scrdefs.h
menu_prefs.$O: $(SRC_DIR)/serialdefs.h
menu_prefs.$O: $(SRC_DIR)/ses.h
menu_prefs.$O: $(SRC_DIR)/spk.h
menu_prefs.$O: $(SRC_DIR)/spkdefs.h
menu_prefs.$O: $(SRC_DIR)/timing.h
menu_prefs.$O: $(SRC_DIR)/tunedefs.h
menu_prefs.$O: $(SRC_DIR)/tunes.h
menu_prefs.$O: $(SRC_DIR)/usbdefs.h
menu_prefs.$O: $(SRC_DIR)/ttb.h
menu_prefs.$O: $(SRC_DIR)/atb.h
menu_prefs.$O: $(SRC_DIR)/midi.h

# Dependencies for message.$O:
message.$O: $(SRC_DIR)/message.c
message.$O: $(BLD_TOP)config.h
message.$O: $(BLD_TOP)forbuild.h
message.$O: $(SRC_TOP)prologue.h
message.$O: $(SRC_DIR)/message.h
message.$O: $(SRC_DIR)/brldefs.h
message.$O: $(SRC_DIR)/ctbdefs.h
message.$O: $(SRC_DIR)/defaults.h
message.$O: $(SRC_DIR)/parameters.h
message.$O: $(SRC_DIR)/spkdefs.h
message.$O: $(SRC_DIR)/tunedefs.h
message.$O: $(SRC_DIR)/async.h
message.$O: $(SRC_DIR)/async_wait.h
message.$O: $(SRC_DIR)/async_event.h
message.$O: $(SRC_DIR)/async_task.h
message.$O: $(SRC_DIR)/charset.h
message.$O: $(SRC_DIR)/lock.h
message.$O: $(SRC_DIR)/driver.h
message.$O: $(SRC_DIR)/spk.h
message.$O: $(SRC_DIR)/ktbdefs.h
message.$O: $(SRC_DIR)/update.h
message.$O: $(SRC_DIR)/cmd_queue.h
message.$O: $(SRC_DIR)/api_control.h
message.$O: $(SRC_DIR)/async_io.h
message.$O: $(SRC_DIR)/brl.h
message.$O: $(SRC_DIR)/io_generic.h
message.$O: $(SRC_DIR)/serialdefs.h
message.$O: $(SRC_DIR)/usbdefs.h
message.$O: brlapi_constants.h
message.$O: $(SRC_DIR)/brlapi_keycodes.h
message.$O: $(SRC_DIR)/brltty.h
message.$O: $(SRC_DIR)/cmd.h
message.$O: $(SRC_DIR)/cmddefs.h
message.$O: $(SRC_DIR)/ctb.h
message.$O: $(SRC_DIR)/ktb.h
message.$O: $(SRC_DIR)/menu.h
message.$O: $(SRC_DIR)/pid.h
message.$O: $(SRC_DIR)/prefs.h
message.$O: $(SRC_DIR)/program.h
message.$O: $(SRC_DIR)/scrdefs.h
message.$O: $(SRC_DIR)/ses.h
message.$O: $(SRC_DIR)/timing.h
message.$O: $(SRC_DIR)/tunes.h

# Dependencies for midi.$O:
midi.$O: $(SRC_DIR)/midi.c
midi.$O: $(BLD_TOP)config.h
midi.$O: $(BLD_TOP)forbuild.h
midi.$O: $(SRC_TOP)prologue.h
midi.$O: $(SRC_DIR)/midi.h

# Dependencies for midi_alsa.$O:
midi_alsa.$O: $(SRC_DIR)/midi_alsa.c
midi_alsa.$O: $(BLD_TOP)config.h
midi_alsa.$O: $(BLD_TOP)forbuild.h
midi_alsa.$O: $(SRC_TOP)prologue.h
midi_alsa.$O: $(SRC_DIR)/log.h
midi_alsa.$O: $(SRC_DIR)/parse.h
midi_alsa.$O: $(SRC_DIR)/timing.h
midi_alsa.$O: $(SRC_DIR)/dynld.h
midi_alsa.$O: $(SRC_DIR)/midi.h

# Dependencies for midi_darwin.$O:
midi_darwin.$O: $(SRC_DIR)/midi_darwin.c
midi_darwin.$O: $(BLD_TOP)config.h
midi_darwin.$O: $(BLD_TOP)forbuild.h
midi_darwin.$O: $(SRC_TOP)prologue.h
midi_darwin.$O: $(SRC_DIR)/log.h
midi_darwin.$O: $(SRC_DIR)/midi.h

# Dependencies for midi_none.$O:
midi_none.$O: $(SRC_DIR)/midi_none.c
midi_none.$O: $(BLD_TOP)config.h
midi_none.$O: $(BLD_TOP)forbuild.h
midi_none.$O: $(SRC_TOP)prologue.h
midi_none.$O: $(SRC_DIR)/log.h
midi_none.$O: $(SRC_DIR)/midi.h

# Dependencies for midi_oss.$O:
midi_oss.$O: $(SRC_DIR)/midi_oss.c
midi_oss.$O: $(BLD_TOP)config.h
midi_oss.$O: $(BLD_TOP)forbuild.h
midi_oss.$O: $(SRC_TOP)prologue.h
midi_oss.$O: $(SRC_DIR)/log.h
midi_oss.$O: $(SRC_DIR)/io_misc.h
midi_oss.$O: $(SRC_DIR)/midi.h

# Dependencies for midi_windows.$O:
midi_windows.$O: $(SRC_DIR)/midi_windows.c
midi_windows.$O: $(BLD_TOP)config.h
midi_windows.$O: $(BLD_TOP)forbuild.h
midi_windows.$O: $(SRC_TOP)prologue.h
midi_windows.$O: $(SRC_DIR)/log.h
midi_windows.$O: $(SRC_DIR)/parse.h
midi_windows.$O: $(SRC_DIR)/timing.h
midi_windows.$O: $(SRC_DIR)/midi.h

# Dependencies for mntfs_linux.$O:
mntfs_linux.$O: $(SRC_DIR)/mntfs_linux.c
mntfs_linux.$O: $(BLD_TOP)config.h
mntfs_linux.$O: $(BLD_TOP)forbuild.h
mntfs_linux.$O: $(SRC_TOP)prologue.h
mntfs_linux.$O: $(SRC_DIR)/mntfs.h

# Dependencies for mntfs_none.$O:
mntfs_none.$O: $(SRC_DIR)/mntfs_none.c
mntfs_none.$O: $(BLD_TOP)config.h
mntfs_none.$O: $(BLD_TOP)forbuild.h
mntfs_none.$O: $(SRC_TOP)prologue.h
mntfs_none.$O: $(SRC_DIR)/mntfs.h

# Dependencies for mntpt.$O:
mntpt.$O: $(SRC_DIR)/mntpt.c
mntpt.$O: $(BLD_TOP)config.h
mntpt.$O: $(BLD_TOP)forbuild.h
mntpt.$O: $(SRC_TOP)prologue.h
mntpt.$O: $(SRC_DIR)/log.h
mntpt.$O: $(SRC_DIR)/parameters.h
mntpt.$O: $(SRC_DIR)/mntfs.h
mntpt.$O: $(SRC_DIR)/async.h
mntpt.$O: $(SRC_DIR)/async_alarm.h
mntpt.$O: $(SRC_DIR)/timing.h
mntpt.$O: $(SRC_DIR)/mntpt.h
mntpt.$O: $(SRC_DIR)/mntpt_none.h
mntpt.$O: $(SRC_DIR)/mntpt_mntent.h
mntpt.$O: $(SRC_DIR)/mntpt_mnttab.h
mntpt.$O: $(SRC_DIR)/mntpt_internal.h

# Dependencies for mntpt_mntent.$O:
mntpt_mntent.$O: $(SRC_DIR)/mntpt_mntent.c
mntpt_mntent.$O: $(BLD_TOP)config.h
mntpt_mntent.$O: $(BLD_TOP)forbuild.h
mntpt_mntent.$O: $(SRC_TOP)prologue.h
mntpt_mntent.$O: $(SRC_DIR)/log.h
mntpt_mntent.$O: $(SRC_DIR)/mntpt_mntent.h
mntpt_mntent.$O: $(SRC_DIR)/mntpt_internal.h

# Dependencies for mntpt_mnttab.$O:
mntpt_mnttab.$O: $(SRC_DIR)/mntpt_mnttab.c
mntpt_mnttab.$O: $(BLD_TOP)config.h
mntpt_mnttab.$O: $(BLD_TOP)forbuild.h
mntpt_mnttab.$O: $(SRC_TOP)prologue.h
mntpt_mnttab.$O: $(SRC_DIR)/log.h
mntpt_mnttab.$O: $(SRC_DIR)/mntpt_mnttab.h
mntpt_mnttab.$O: $(SRC_DIR)/mntpt_internal.h

# Dependencies for mntpt_none.$O:
mntpt_none.$O: $(SRC_DIR)/mntpt_none.c
mntpt_none.$O: $(BLD_TOP)config.h
mntpt_none.$O: $(BLD_TOP)forbuild.h
mntpt_none.$O: $(SRC_TOP)prologue.h
mntpt_none.$O: $(SRC_DIR)/log.h
mntpt_none.$O: $(SRC_DIR)/mntpt_none.h
mntpt_none.$O: $(SRC_DIR)/mntpt_internal.h

# Dependencies for notes.$O:
notes.$O: $(SRC_DIR)/notes.c
notes.$O: $(BLD_TOP)config.h
notes.$O: $(BLD_TOP)forbuild.h
notes.$O: $(SRC_TOP)prologue.h
notes.$O: $(SRC_DIR)/notes.h

# Dependencies for notes_beep.$O:
notes_beep.$O: $(SRC_DIR)/notes_beep.c
notes_beep.$O: $(BLD_TOP)config.h
notes_beep.$O: $(BLD_TOP)forbuild.h
notes_beep.$O: $(SRC_TOP)prologue.h
notes_beep.$O: $(SRC_DIR)/log.h
notes_beep.$O: $(SRC_DIR)/async.h
notes_beep.$O: $(SRC_DIR)/async_wait.h
notes_beep.$O: $(SRC_DIR)/beep.h
notes_beep.$O: $(SRC_DIR)/notes.h

# Dependencies for notes_fm.$O:
notes_fm.$O: $(SRC_DIR)/notes_fm.c
notes_fm.$O: $(BLD_TOP)config.h
notes_fm.$O: $(BLD_TOP)forbuild.h
notes_fm.$O: $(SRC_TOP)prologue.h
notes_fm.$O: $(SRC_DIR)/prefs.h
notes_fm.$O: $(SRC_DIR)/log.h
notes_fm.$O: $(SRC_DIR)/timing.h
notes_fm.$O: $(SRC_DIR)/notes.h
notes_fm.$O: $(SRC_DIR)/fm.h

# Dependencies for notes_midi.$O:
notes_midi.$O: $(SRC_DIR)/notes_midi.c
notes_midi.$O: $(BLD_TOP)config.h
notes_midi.$O: $(BLD_TOP)forbuild.h
notes_midi.$O: $(SRC_TOP)prologue.h
notes_midi.$O: $(SRC_DIR)/prefs.h
notes_midi.$O: $(SRC_DIR)/log.h
notes_midi.$O: $(SRC_DIR)/midi.h
notes_midi.$O: $(SRC_DIR)/notes.h

# Dependencies for notes_pcm.$O:
notes_pcm.$O: $(SRC_DIR)/notes_pcm.c
notes_pcm.$O: $(BLD_TOP)config.h
notes_pcm.$O: $(BLD_TOP)forbuild.h
notes_pcm.$O: $(SRC_TOP)prologue.h
notes_pcm.$O: $(SRC_DIR)/prefs.h
notes_pcm.$O: $(SRC_DIR)/log.h
notes_pcm.$O: $(SRC_DIR)/pcm.h
notes_pcm.$O: $(SRC_DIR)/notes.h

# Dependencies for options.$O:
options.$O: $(SRC_DIR)/options.c
options.$O: $(BLD_TOP)config.h
options.$O: $(BLD_TOP)forbuild.h
options.$O: $(SRC_TOP)prologue.h
options.$O: $(SRC_DIR)/pid.h
options.$O: $(SRC_DIR)/program.h
options.$O: $(SRC_DIR)/options.h
options.$O: $(SRC_DIR)/params.h
options.$O: $(SRC_DIR)/log.h
options.$O: $(SRC_DIR)/file.h
options.$O: $(SRC_DIR)/parse.h

# Dependencies for params_linux.$O:
params_linux.$O: $(SRC_DIR)/params_linux.c
params_linux.$O: $(BLD_TOP)config.h
params_linux.$O: $(BLD_TOP)forbuild.h
params_linux.$O: $(SRC_TOP)prologue.h
params_linux.$O: $(SRC_DIR)/log.h
params_linux.$O: $(SRC_DIR)/params.h

# Dependencies for params_none.$O:
params_none.$O: $(SRC_DIR)/params_none.c
params_none.$O: $(BLD_TOP)config.h
params_none.$O: $(BLD_TOP)forbuild.h
params_none.$O: $(SRC_TOP)prologue.h
params_none.$O: $(SRC_DIR)/params.h

# Dependencies for parse.$O:
parse.$O: $(SRC_DIR)/parse.c
parse.$O: $(BLD_TOP)config.h
parse.$O: $(BLD_TOP)forbuild.h
parse.$O: $(SRC_TOP)prologue.h
parse.$O: $(SRC_DIR)/parse.h
parse.$O: $(SRC_DIR)/log.h

# Dependencies for pcm.$O:
pcm.$O: $(SRC_DIR)/pcm.c
pcm.$O: $(BLD_TOP)config.h
pcm.$O: $(BLD_TOP)forbuild.h
pcm.$O: $(SRC_TOP)prologue.h
pcm.$O: $(SRC_DIR)/pcm.h

# Dependencies for pcm_alsa.$O:
pcm_alsa.$O: $(SRC_DIR)/pcm_alsa.c
pcm_alsa.$O: $(BLD_TOP)config.h
pcm_alsa.$O: $(BLD_TOP)forbuild.h
pcm_alsa.$O: $(SRC_TOP)prologue.h
pcm_alsa.$O: $(SRC_DIR)/log.h
pcm_alsa.$O: $(SRC_DIR)/timing.h
pcm_alsa.$O: $(SRC_DIR)/dynld.h
pcm_alsa.$O: $(SRC_DIR)/pcm.h

# Dependencies for pcm_android.$O:
pcm_android.$O: $(SRC_DIR)/pcm_android.c
pcm_android.$O: $(BLD_TOP)config.h
pcm_android.$O: $(BLD_TOP)forbuild.h
pcm_android.$O: $(SRC_TOP)prologue.h
pcm_android.$O: $(SRC_DIR)/log.h
pcm_android.$O: $(SRC_DIR)/pcm.h
pcm_android.$O: $(SRC_DIR)/system_java.h

# Dependencies for pcm_audio.$O:
pcm_audio.$O: $(SRC_DIR)/pcm_audio.c
pcm_audio.$O: $(BLD_TOP)config.h
pcm_audio.$O: $(BLD_TOP)forbuild.h
pcm_audio.$O: $(SRC_TOP)prologue.h
pcm_audio.$O: $(SRC_DIR)/log.h
pcm_audio.$O: $(SRC_DIR)/io_misc.h
pcm_audio.$O: $(SRC_DIR)/pcm.h

# Dependencies for pcm_hpux.$O:
pcm_hpux.$O: $(SRC_DIR)/pcm_hpux.c
pcm_hpux.$O: $(BLD_TOP)config.h
pcm_hpux.$O: $(BLD_TOP)forbuild.h
pcm_hpux.$O: $(SRC_TOP)prologue.h
pcm_hpux.$O: $(SRC_DIR)/log.h
pcm_hpux.$O: $(SRC_DIR)/pcm.h

# Dependencies for pcm_none.$O:
pcm_none.$O: $(SRC_DIR)/pcm_none.c
pcm_none.$O: $(BLD_TOP)config.h
pcm_none.$O: $(BLD_TOP)forbuild.h
pcm_none.$O: $(SRC_TOP)prologue.h
pcm_none.$O: $(SRC_DIR)/log.h
pcm_none.$O: $(SRC_DIR)/pcm.h

# Dependencies for pcm_oss.$O:
pcm_oss.$O: $(SRC_DIR)/pcm_oss.c
pcm_oss.$O: $(BLD_TOP)config.h
pcm_oss.$O: $(BLD_TOP)forbuild.h
pcm_oss.$O: $(SRC_TOP)prologue.h
pcm_oss.$O: $(SRC_DIR)/log.h
pcm_oss.$O: $(SRC_DIR)/io_misc.h
pcm_oss.$O: $(SRC_DIR)/pcm.h

# Dependencies for pcm_qsa.$O:
pcm_qsa.$O: $(SRC_DIR)/pcm_qsa.c
pcm_qsa.$O: $(BLD_TOP)config.h
pcm_qsa.$O: $(BLD_TOP)forbuild.h
pcm_qsa.$O: $(SRC_TOP)prologue.h
pcm_qsa.$O: $(SRC_DIR)/log.h
pcm_qsa.$O: $(SRC_DIR)/io_misc.h
pcm_qsa.$O: $(SRC_DIR)/pcm.h

# Dependencies for pcm_windows.$O:
pcm_windows.$O: $(SRC_DIR)/pcm_windows.c
pcm_windows.$O: $(BLD_TOP)config.h
pcm_windows.$O: $(BLD_TOP)forbuild.h
pcm_windows.$O: $(SRC_TOP)prologue.h
pcm_windows.$O: $(SRC_DIR)/log.h
pcm_windows.$O: $(SRC_DIR)/parse.h
pcm_windows.$O: $(SRC_DIR)/pcm.h

# Dependencies for pgmpath_linux.$O:
pgmpath_linux.$O: $(SRC_DIR)/pgmpath_linux.c
pgmpath_linux.$O: $(BLD_TOP)config.h
pgmpath_linux.$O: $(BLD_TOP)forbuild.h
pgmpath_linux.$O: $(SRC_TOP)prologue.h
pgmpath_linux.$O: $(SRC_DIR)/log.h
pgmpath_linux.$O: $(SRC_DIR)/pgmpath.h

# Dependencies for pgmpath_none.$O:
pgmpath_none.$O: $(SRC_DIR)/pgmpath_none.c
pgmpath_none.$O: $(BLD_TOP)config.h
pgmpath_none.$O: $(BLD_TOP)forbuild.h
pgmpath_none.$O: $(SRC_TOP)prologue.h
pgmpath_none.$O: $(SRC_DIR)/pgmpath.h

# Dependencies for pgmpath_solaris.$O:
pgmpath_solaris.$O: $(SRC_DIR)/pgmpath_solaris.c
pgmpath_solaris.$O: $(BLD_TOP)config.h
pgmpath_solaris.$O: $(BLD_TOP)forbuild.h
pgmpath_solaris.$O: $(SRC_TOP)prologue.h
pgmpath_solaris.$O: $(SRC_DIR)/log.h
pgmpath_solaris.$O: $(SRC_DIR)/pgmpath.h

# Dependencies for pgmpath_windows.$O:
pgmpath_windows.$O: $(SRC_DIR)/pgmpath_windows.c
pgmpath_windows.$O: $(BLD_TOP)config.h
pgmpath_windows.$O: $(BLD_TOP)forbuild.h
pgmpath_windows.$O: $(SRC_TOP)prologue.h
pgmpath_windows.$O: $(SRC_DIR)/log.h
pgmpath_windows.$O: $(SRC_DIR)/pgmpath.h
pgmpath_windows.$O: $(SRC_DIR)/system_windows.h

# Dependencies for pid.$O:
pid.$O: $(SRC_DIR)/pid.c
pid.$O: $(BLD_TOP)config.h
pid.$O: $(BLD_TOP)forbuild.h
pid.$O: $(SRC_TOP)prologue.h
pid.$O: $(SRC_DIR)/pid.h

# Dependencies for ports_glibc.$O:
ports_glibc.$O: $(SRC_DIR)/ports_glibc.c
ports_glibc.$O: $(BLD_TOP)config.h
ports_glibc.$O: $(BLD_TOP)forbuild.h
ports_glibc.$O: $(SRC_TOP)prologue.h
ports_glibc.$O: $(SRC_DIR)/log.h
ports_glibc.$O: $(SRC_DIR)/ports.h

# Dependencies for ports_grub.$O:
ports_grub.$O: $(SRC_DIR)/ports_grub.c
ports_grub.$O: $(BLD_TOP)config.h
ports_grub.$O: $(BLD_TOP)forbuild.h
ports_grub.$O: $(SRC_TOP)prologue.h
ports_grub.$O: $(SRC_DIR)/ports.h

# Dependencies for ports_kfreebsd.$O:
ports_kfreebsd.$O: $(SRC_DIR)/ports_kfreebsd.c
ports_kfreebsd.$O: $(BLD_TOP)config.h
ports_kfreebsd.$O: $(BLD_TOP)forbuild.h
ports_kfreebsd.$O: $(SRC_TOP)prologue.h
ports_kfreebsd.$O: $(SRC_DIR)/log.h
ports_kfreebsd.$O: $(SRC_DIR)/ports.h

# Dependencies for ports_msdos.$O:
ports_msdos.$O: $(SRC_DIR)/ports_msdos.c
ports_msdos.$O: $(BLD_TOP)config.h
ports_msdos.$O: $(BLD_TOP)forbuild.h
ports_msdos.$O: $(SRC_TOP)prologue.h
ports_msdos.$O: $(SRC_DIR)/ports.h
ports_msdos.$O: $(SRC_DIR)/ports_x86.h

# Dependencies for ports_none.$O:
ports_none.$O: $(SRC_DIR)/ports_none.c
ports_none.$O: $(BLD_TOP)config.h
ports_none.$O: $(BLD_TOP)forbuild.h
ports_none.$O: $(SRC_TOP)prologue.h
ports_none.$O: $(SRC_DIR)/log.h
ports_none.$O: $(SRC_DIR)/ports.h

# Dependencies for ports_windows.$O:
ports_windows.$O: $(SRC_DIR)/ports_windows.c
ports_windows.$O: $(BLD_TOP)config.h
ports_windows.$O: $(BLD_TOP)forbuild.h
ports_windows.$O: $(SRC_TOP)prologue.h
ports_windows.$O: $(SRC_DIR)/ports.h
ports_windows.$O: $(SRC_DIR)/system_windows.h
ports_windows.$O: $(SRC_DIR)/ports_x86.h

# Dependencies for prefs.$O:
prefs.$O: $(SRC_DIR)/prefs.c
prefs.$O: $(BLD_TOP)config.h
prefs.$O: $(BLD_TOP)forbuild.h
prefs.$O: $(SRC_TOP)prologue.h
prefs.$O: $(SRC_DIR)/prefs.h
prefs.$O: $(SRC_DIR)/prefs_internal.h
prefs.$O: $(SRC_DIR)/statdefs.h
prefs.$O: $(SRC_DIR)/brldefs.h
prefs.$O: $(SRC_DIR)/ctbdefs.h
prefs.$O: $(SRC_DIR)/defaults.h
prefs.$O: $(SRC_DIR)/parameters.h
prefs.$O: $(SRC_DIR)/spkdefs.h
prefs.$O: $(SRC_DIR)/tunedefs.h
prefs.$O: $(SRC_DIR)/log.h
prefs.$O: $(SRC_DIR)/file.h
prefs.$O: $(SRC_DIR)/parse.h

# Dependencies for prefs_table.$O:
prefs_table.$O: $(SRC_DIR)/prefs_table.c
prefs_table.$O: $(BLD_TOP)config.h
prefs_table.$O: $(BLD_TOP)forbuild.h
prefs_table.$O: $(SRC_TOP)prologue.h
prefs_table.$O: $(SRC_DIR)/prefs.h
prefs_table.$O: $(SRC_DIR)/prefs_internal.h
prefs_table.$O: $(SRC_DIR)/statdefs.h
prefs_table.$O: $(SRC_DIR)/brldefs.h
prefs_table.$O: $(SRC_DIR)/ctbdefs.h
prefs_table.$O: $(SRC_DIR)/defaults.h
prefs_table.$O: $(SRC_DIR)/parameters.h
prefs_table.$O: $(SRC_DIR)/spkdefs.h
prefs_table.$O: $(SRC_DIR)/tunedefs.h

# Dependencies for program.$O:
program.$O: $(SRC_DIR)/program.c
program.$O: $(BLD_TOP)config.h
program.$O: $(BLD_TOP)forbuild.h
program.$O: $(SRC_TOP)prologue.h
program.$O: $(SRC_DIR)/pid.h
program.$O: $(SRC_DIR)/program.h
program.$O: $(SRC_DIR)/pgmpath.h
program.$O: $(SRC_DIR)/log.h
program.$O: $(SRC_DIR)/file.h
program.$O: $(SRC_DIR)/parse.h
program.$O: $(SRC_DIR)/system.h

# Dependencies for queue.$O:
queue.$O: $(SRC_DIR)/queue.c
queue.$O: $(BLD_TOP)config.h
queue.$O: $(BLD_TOP)forbuild.h
queue.$O: $(SRC_TOP)prologue.h
queue.$O: $(SRC_DIR)/log.h
queue.$O: $(SRC_DIR)/queue.h
queue.$O: $(SRC_DIR)/pid.h
queue.$O: $(SRC_DIR)/program.h

# Dependencies for routing.$O:
routing.$O: $(SRC_DIR)/routing.c
routing.$O: $(BLD_TOP)config.h
routing.$O: $(BLD_TOP)forbuild.h
routing.$O: $(SRC_TOP)prologue.h
routing.$O: $(SRC_DIR)/log.h
routing.$O: $(SRC_DIR)/pid.h
routing.$O: $(SRC_DIR)/program.h
routing.$O: $(SRC_DIR)/timing.h
routing.$O: $(SRC_DIR)/cmd_queue.h
routing.$O: $(SRC_DIR)/driver.h
routing.$O: $(SRC_DIR)/ktbdefs.h
routing.$O: $(SRC_DIR)/scr.h
routing.$O: $(SRC_DIR)/scrdefs.h
routing.$O: $(SRC_DIR)/routing.h

# Dependencies for scancodes.$O:
scancodes.$O: $(SRC_DIR)/scancodes.c
scancodes.$O: $(BLD_TOP)config.h
scancodes.$O: $(BLD_TOP)forbuild.h
scancodes.$O: $(SRC_TOP)prologue.h
scancodes.$O: $(SRC_DIR)/scancodes.h
scancodes.$O: $(SRC_DIR)/brldefs.h

# Dependencies for scr.$O:
scr.$O: $(SRC_DIR)/scr.c
scr.$O: $(BLD_TOP)config.h
scr.$O: $(BLD_TOP)forbuild.h
scr.$O: $(SRC_TOP)prologue.h
scr.$O: $(SRC_DIR)/log.h
scr.$O: $(SRC_DIR)/update.h
scr.$O: $(SRC_DIR)/message.h
scr.$O: $(SRC_DIR)/menu.h
scr.$O: $(SRC_DIR)/menu_prefs.h
scr.$O: $(SRC_DIR)/cmd_queue.h
scr.$O: $(SRC_DIR)/driver.h
scr.$O: $(SRC_DIR)/ktbdefs.h
scr.$O: $(SRC_DIR)/scr.h
scr.$O: $(SRC_DIR)/scrdefs.h
scr.$O: $(SRC_DIR)/scr_base.h
scr.$O: $(SRC_DIR)/scr_help.h
scr.$O: $(SRC_DIR)/scr_menu.h
scr.$O: $(SRC_DIR)/scr_frozen.h
scr.$O: $(SRC_DIR)/scr_main.h
scr.$O: $(SRC_DIR)/scr_real.h

# Dependencies for scr_base.$O:
scr_base.$O: $(SRC_DIR)/scr_base.c
scr_base.$O: $(BLD_TOP)config.h
scr_base.$O: $(BLD_TOP)forbuild.h
scr_base.$O: $(SRC_TOP)prologue.h
scr_base.$O: $(SRC_DIR)/log.h
scr_base.$O: $(SRC_DIR)/cmd_queue.h
scr_base.$O: $(SRC_DIR)/driver.h
scr_base.$O: $(SRC_DIR)/ktbdefs.h
scr_base.$O: $(SRC_DIR)/scr.h
scr_base.$O: $(SRC_DIR)/scrdefs.h
scr_base.$O: $(SRC_DIR)/scr_base.h

# Dependencies for scr_driver.$O:
scr_driver.$O: $(SRC_DIR)/scr_driver.c
scr_driver.$O: $(BLD_TOP)config.h
scr_driver.$O: $(BLD_TOP)forbuild.h
scr_driver.$O: $(SRC_TOP)prologue.h
scr_driver.$O: $(SRC_DIR)/driver.h
scr_driver.$O: $(SRC_DIR)/drivers.h
scr_driver.$O: $(SRC_DIR)/cmd_queue.h
scr_driver.$O: $(SRC_DIR)/ktbdefs.h
scr_driver.$O: $(SRC_DIR)/scr.h
scr_driver.$O: $(SRC_DIR)/scrdefs.h
scr_driver.$O: $(SRC_DIR)/scr_base.h
scr_driver.$O: $(SRC_DIR)/scr_main.h
scr_driver.$O: scr.auto.h
scr_driver.$O: $(SRC_DIR)/scr_driver.h
scr_driver.$O: $(SRC_DIR)/scr_real.h

# Dependencies for scr_frozen.$O:
scr_frozen.$O: $(SRC_DIR)/scr_frozen.c
scr_frozen.$O: $(BLD_TOP)config.h
scr_frozen.$O: $(BLD_TOP)forbuild.h
scr_frozen.$O: $(SRC_TOP)prologue.h
scr_frozen.$O: $(SRC_DIR)/log.h
scr_frozen.$O: $(SRC_DIR)/cmd_queue.h
scr_frozen.$O: $(SRC_DIR)/driver.h
scr_frozen.$O: $(SRC_DIR)/ktbdefs.h
scr_frozen.$O: $(SRC_DIR)/scr.h
scr_frozen.$O: $(SRC_DIR)/scrdefs.h
scr_frozen.$O: $(SRC_DIR)/scr_base.h
scr_frozen.$O: $(SRC_DIR)/scr_frozen.h

# Dependencies for scr_help.$O:
scr_help.$O: $(SRC_DIR)/scr_help.c
scr_help.$O: $(BLD_TOP)config.h
scr_help.$O: $(BLD_TOP)forbuild.h
scr_help.$O: $(SRC_TOP)prologue.h
scr_help.$O: $(SRC_DIR)/log.h
scr_help.$O: $(SRC_DIR)/cmd_queue.h
scr_help.$O: $(SRC_DIR)/driver.h
scr_help.$O: $(SRC_DIR)/ktbdefs.h
scr_help.$O: $(SRC_DIR)/scr.h
scr_help.$O: $(SRC_DIR)/scrdefs.h
scr_help.$O: $(SRC_DIR)/scr_base.h
scr_help.$O: $(SRC_DIR)/scr_help.h

# Dependencies for scr_main.$O:
scr_main.$O: $(SRC_DIR)/scr_main.c
scr_main.$O: $(BLD_TOP)config.h
scr_main.$O: $(BLD_TOP)forbuild.h
scr_main.$O: $(SRC_TOP)prologue.h
scr_main.$O: $(SRC_DIR)/update.h
scr_main.$O: $(SRC_DIR)/cmd_queue.h
scr_main.$O: $(SRC_DIR)/driver.h
scr_main.$O: $(SRC_DIR)/ktbdefs.h
scr_main.$O: $(SRC_DIR)/scr.h
scr_main.$O: $(SRC_DIR)/scrdefs.h
scr_main.$O: $(SRC_DIR)/scr_base.h
scr_main.$O: $(SRC_DIR)/scr_main.h

# Dependencies for scr_menu.$O:
scr_menu.$O: $(SRC_DIR)/scr_menu.c
scr_menu.$O: $(BLD_TOP)config.h
scr_menu.$O: $(BLD_TOP)forbuild.h
scr_menu.$O: $(SRC_TOP)prologue.h
scr_menu.$O: $(SRC_DIR)/async.h
scr_menu.$O: $(SRC_DIR)/async_io.h
scr_menu.$O: $(SRC_DIR)/brl.h
scr_menu.$O: brlapi_constants.h
scr_menu.$O: $(SRC_DIR)/brlapi_keycodes.h
scr_menu.$O: $(SRC_DIR)/brldefs.h
scr_menu.$O: $(SRC_DIR)/brltty.h
scr_menu.$O: $(SRC_DIR)/cmd.h
scr_menu.$O: $(SRC_DIR)/cmddefs.h
scr_menu.$O: $(SRC_DIR)/ctb.h
scr_menu.$O: $(SRC_DIR)/ctbdefs.h
scr_menu.$O: $(SRC_DIR)/driver.h
scr_menu.$O: $(SRC_DIR)/io_generic.h
scr_menu.$O: $(SRC_DIR)/ktb.h
scr_menu.$O: $(SRC_DIR)/ktbdefs.h
scr_menu.$O: $(SRC_DIR)/menu.h
scr_menu.$O: $(SRC_DIR)/pid.h
scr_menu.$O: $(SRC_DIR)/prefs.h
scr_menu.$O: $(SRC_DIR)/program.h
scr_menu.$O: $(SRC_DIR)/scrdefs.h
scr_menu.$O: $(SRC_DIR)/serialdefs.h
scr_menu.$O: $(SRC_DIR)/ses.h
scr_menu.$O: $(SRC_DIR)/spk.h
scr_menu.$O: $(SRC_DIR)/spkdefs.h
scr_menu.$O: $(SRC_DIR)/timing.h
scr_menu.$O: $(SRC_DIR)/tunedefs.h
scr_menu.$O: $(SRC_DIR)/tunes.h
scr_menu.$O: $(SRC_DIR)/usbdefs.h
scr_menu.$O: $(SRC_DIR)/charset.h
scr_menu.$O: $(SRC_DIR)/lock.h
scr_menu.$O: $(SRC_DIR)/cmd_queue.h
scr_menu.$O: $(SRC_DIR)/scr.h
scr_menu.$O: $(SRC_DIR)/scr_base.h
scr_menu.$O: $(SRC_DIR)/scr_menu.h

# Dependencies for scr_real.$O:
scr_real.$O: $(SRC_DIR)/scr_real.c
scr_real.$O: $(BLD_TOP)config.h
scr_real.$O: $(BLD_TOP)forbuild.h
scr_real.$O: $(SRC_TOP)prologue.h
scr_real.$O: $(SRC_DIR)/log.h
scr_real.$O: $(SRC_DIR)/parameters.h
scr_real.$O: $(SRC_DIR)/device.h
scr_real.$O: $(SRC_DIR)/async.h
scr_real.$O: $(SRC_DIR)/async_alarm.h
scr_real.$O: $(SRC_DIR)/timing.h
scr_real.$O: $(SRC_DIR)/cmd_queue.h
scr_real.$O: $(SRC_DIR)/driver.h
scr_real.$O: $(SRC_DIR)/ktbdefs.h
scr_real.$O: $(SRC_DIR)/scr.h
scr_real.$O: $(SRC_DIR)/scrdefs.h
scr_real.$O: $(SRC_DIR)/scr_base.h
scr_real.$O: $(SRC_DIR)/scr_main.h
scr_real.$O: $(SRC_DIR)/scr_real.h
scr_real.$O: $(SRC_DIR)/routing.h

# Dependencies for scrtest.$O:
scrtest.$O: $(SRC_DIR)/scrtest.c
scrtest.$O: $(BLD_TOP)config.h
scrtest.$O: $(BLD_TOP)forbuild.h
scrtest.$O: $(SRC_TOP)prologue.h
scrtest.$O: $(SRC_DIR)/pid.h
scrtest.$O: $(SRC_DIR)/program.h
scrtest.$O: $(SRC_DIR)/options.h
scrtest.$O: $(SRC_DIR)/log.h
scrtest.$O: $(SRC_DIR)/parse.h
scrtest.$O: $(SRC_DIR)/cmd_queue.h
scrtest.$O: $(SRC_DIR)/driver.h
scrtest.$O: $(SRC_DIR)/ktbdefs.h
scrtest.$O: $(SRC_DIR)/scr.h
scrtest.$O: $(SRC_DIR)/scrdefs.h

# Dependencies for serial.$O:
serial.$O: $(SRC_DIR)/serial.c
serial.$O: $(BLD_TOP)config.h
serial.$O: $(BLD_TOP)forbuild.h
serial.$O: $(SRC_TOP)prologue.h
serial.$O: $(SRC_DIR)/log.h
serial.$O: $(SRC_DIR)/parameters.h
serial.$O: $(SRC_DIR)/parse.h
serial.$O: $(SRC_DIR)/device.h
serial.$O: $(SRC_DIR)/async.h
serial.$O: $(SRC_DIR)/async_wait.h
serial.$O: $(SRC_DIR)/serial_none.h
serial.$O: $(SRC_DIR)/serial_grub.h
serial.$O: $(SRC_DIR)/serial_uart.h
serial.$O: $(SRC_DIR)/serial_msdos.h
serial.$O: $(SRC_DIR)/serial_termios.h
serial.$O: $(SRC_DIR)/serial_windows.h
serial.$O: $(SRC_DIR)/async_io.h
serial.$O: $(SRC_DIR)/async_thread.h
serial.$O: $(SRC_DIR)/io_serial.h
serial.$O: $(SRC_DIR)/serial_internal.h
serial.$O: $(SRC_DIR)/serialdefs.h
serial.$O: $(SRC_DIR)/timing.h
serial.$O: $(SRC_DIR)/win_pthread.h

# Dependencies for serial_grub.$O:
serial_grub.$O: $(SRC_DIR)/serial_grub.c
serial_grub.$O: $(BLD_TOP)config.h
serial_grub.$O: $(BLD_TOP)forbuild.h
serial_grub.$O: $(SRC_TOP)prologue.h
serial_grub.$O: $(SRC_DIR)/log.h
serial_grub.$O: $(SRC_DIR)/timing.h
serial_grub.$O: $(SRC_DIR)/serial_grub.h
serial_grub.$O: $(SRC_DIR)/serial_uart.h
serial_grub.$O: $(SRC_DIR)/async.h
serial_grub.$O: $(SRC_DIR)/async_io.h
serial_grub.$O: $(SRC_DIR)/async_thread.h
serial_grub.$O: $(SRC_DIR)/io_serial.h
serial_grub.$O: $(SRC_DIR)/serial_internal.h
serial_grub.$O: $(SRC_DIR)/serialdefs.h
serial_grub.$O: $(SRC_DIR)/win_pthread.h

# Dependencies for serial_msdos.$O:
serial_msdos.$O: $(SRC_DIR)/serial_msdos.c
serial_msdos.$O: $(BLD_TOP)config.h
serial_msdos.$O: $(BLD_TOP)forbuild.h
serial_msdos.$O: $(SRC_TOP)prologue.h
serial_msdos.$O: $(SRC_DIR)/log.h
serial_msdos.$O: $(SRC_DIR)/io_misc.h
serial_msdos.$O: $(SRC_DIR)/ports.h
serial_msdos.$O: $(SRC_DIR)/serial_msdos.h
serial_msdos.$O: $(SRC_DIR)/serial_uart.h
serial_msdos.$O: $(SRC_DIR)/async.h
serial_msdos.$O: $(SRC_DIR)/async_io.h
serial_msdos.$O: $(SRC_DIR)/async_thread.h
serial_msdos.$O: $(SRC_DIR)/io_serial.h
serial_msdos.$O: $(SRC_DIR)/serial_internal.h
serial_msdos.$O: $(SRC_DIR)/serialdefs.h
serial_msdos.$O: $(SRC_DIR)/timing.h
serial_msdos.$O: $(SRC_DIR)/win_pthread.h

# Dependencies for serial_none.$O:
serial_none.$O: $(SRC_DIR)/serial_none.c
serial_none.$O: $(BLD_TOP)config.h
serial_none.$O: $(BLD_TOP)forbuild.h
serial_none.$O: $(SRC_TOP)prologue.h
serial_none.$O: $(SRC_DIR)/serial_none.h
serial_none.$O: $(SRC_DIR)/async.h
serial_none.$O: $(SRC_DIR)/async_io.h
serial_none.$O: $(SRC_DIR)/async_thread.h
serial_none.$O: $(SRC_DIR)/io_serial.h
serial_none.$O: $(SRC_DIR)/serial_internal.h
serial_none.$O: $(SRC_DIR)/serialdefs.h
serial_none.$O: $(SRC_DIR)/timing.h
serial_none.$O: $(SRC_DIR)/win_pthread.h

# Dependencies for serial_termios.$O:
serial_termios.$O: $(SRC_DIR)/serial_termios.c
serial_termios.$O: $(BLD_TOP)config.h
serial_termios.$O: $(BLD_TOP)forbuild.h
serial_termios.$O: $(SRC_TOP)prologue.h
serial_termios.$O: $(SRC_DIR)/log.h
serial_termios.$O: $(SRC_DIR)/io_misc.h
serial_termios.$O: $(SRC_DIR)/async.h
serial_termios.$O: $(SRC_DIR)/serial_termios.h
serial_termios.$O: $(SRC_DIR)/async_io.h
serial_termios.$O: $(SRC_DIR)/async_thread.h
serial_termios.$O: $(SRC_DIR)/io_serial.h
serial_termios.$O: $(SRC_DIR)/serial_internal.h
serial_termios.$O: $(SRC_DIR)/serialdefs.h
serial_termios.$O: $(SRC_DIR)/timing.h
serial_termios.$O: $(SRC_DIR)/win_pthread.h

# Dependencies for serial_windows.$O:
serial_windows.$O: $(SRC_DIR)/serial_windows.c
serial_windows.$O: $(BLD_TOP)config.h
serial_windows.$O: $(BLD_TOP)forbuild.h
serial_windows.$O: $(SRC_TOP)prologue.h
serial_windows.$O: $(SRC_DIR)/log.h
serial_windows.$O: $(SRC_DIR)/ascii.h
serial_windows.$O: $(SRC_DIR)/serial_windows.h
serial_windows.$O: $(SRC_DIR)/async.h
serial_windows.$O: $(SRC_DIR)/async_io.h
serial_windows.$O: $(SRC_DIR)/async_thread.h
serial_windows.$O: $(SRC_DIR)/io_serial.h
serial_windows.$O: $(SRC_DIR)/serial_internal.h
serial_windows.$O: $(SRC_DIR)/serialdefs.h
serial_windows.$O: $(SRC_DIR)/timing.h
serial_windows.$O: $(SRC_DIR)/win_pthread.h

# Dependencies for service_none.$O:
service_none.$O: $(SRC_DIR)/service_none.c
service_none.$O: $(BLD_TOP)config.h
service_none.$O: $(BLD_TOP)forbuild.h
service_none.$O: $(SRC_TOP)prologue.h
service_none.$O: $(SRC_DIR)/log.h
service_none.$O: $(SRC_DIR)/service.h

# Dependencies for service_windows.$O:
service_windows.$O: $(SRC_DIR)/service_windows.c
service_windows.$O: $(BLD_TOP)config.h
service_windows.$O: $(BLD_TOP)forbuild.h
service_windows.$O: $(SRC_TOP)prologue.h
service_windows.$O: $(SRC_DIR)/log.h
service_windows.$O: $(SRC_DIR)/pgmpath.h
service_windows.$O: $(SRC_DIR)/service.h
service_windows.$O: $(SRC_DIR)/system_windows.h

# Dependencies for ses.$O:
ses.$O: $(SRC_DIR)/ses.c
ses.$O: $(BLD_TOP)config.h
ses.$O: $(BLD_TOP)forbuild.h
ses.$O: $(SRC_TOP)prologue.h
ses.$O: $(SRC_DIR)/log.h
ses.$O: $(SRC_DIR)/ses.h
ses.$O: $(SRC_DIR)/brldefs.h
ses.$O: $(SRC_DIR)/ctbdefs.h
ses.$O: $(SRC_DIR)/defaults.h
ses.$O: $(SRC_DIR)/parameters.h
ses.$O: $(SRC_DIR)/spkdefs.h
ses.$O: $(SRC_DIR)/tunedefs.h

# Dependencies for spk.$O:
spk.$O: $(SRC_DIR)/spk.c
spk.$O: $(BLD_TOP)config.h
spk.$O: $(BLD_TOP)forbuild.h
spk.$O: $(SRC_TOP)prologue.h
spk.$O: $(SRC_DIR)/log.h
spk.$O: $(SRC_DIR)/parameters.h
spk.$O: $(SRC_DIR)/pid.h
spk.$O: $(SRC_DIR)/program.h
spk.$O: $(SRC_DIR)/file.h
spk.$O: $(SRC_DIR)/parse.h
spk.$O: $(SRC_DIR)/prefs.h
spk.$O: $(SRC_DIR)/charset.h
spk.$O: $(SRC_DIR)/lock.h
spk.$O: $(SRC_DIR)/driver.h
spk.$O: $(SRC_DIR)/spk.h
spk.$O: $(SRC_DIR)/spkdefs.h
spk.$O: $(SRC_DIR)/spk_thread.h
spk.$O: $(SRC_DIR)/async.h
spk.$O: $(SRC_DIR)/async_io.h
spk.$O: $(SRC_DIR)/brl.h
spk.$O: brlapi_constants.h
spk.$O: $(SRC_DIR)/brlapi_keycodes.h
spk.$O: $(SRC_DIR)/brldefs.h
spk.$O: $(SRC_DIR)/brltty.h
spk.$O: $(SRC_DIR)/cmd.h
spk.$O: $(SRC_DIR)/cmddefs.h
spk.$O: $(SRC_DIR)/ctb.h
spk.$O: $(SRC_DIR)/ctbdefs.h
spk.$O: $(SRC_DIR)/io_generic.h
spk.$O: $(SRC_DIR)/ktb.h
spk.$O: $(SRC_DIR)/ktbdefs.h
spk.$O: $(SRC_DIR)/menu.h
spk.$O: $(SRC_DIR)/scrdefs.h
spk.$O: $(SRC_DIR)/serialdefs.h
spk.$O: $(SRC_DIR)/ses.h
spk.$O: $(SRC_DIR)/timing.h
spk.$O: $(SRC_DIR)/tunedefs.h
spk.$O: $(SRC_DIR)/tunes.h
spk.$O: $(SRC_DIR)/usbdefs.h

# Dependencies for spk_driver.$O:
spk_driver.$O: $(SRC_DIR)/spk_driver.c
spk_driver.$O: $(BLD_TOP)config.h
spk_driver.$O: $(BLD_TOP)forbuild.h
spk_driver.$O: $(SRC_TOP)prologue.h
spk_driver.$O: $(SRC_DIR)/driver.h
spk_driver.$O: $(SRC_DIR)/drivers.h
spk_driver.$O: $(SRC_DIR)/spk.h
spk_driver.$O: $(SRC_DIR)/spkdefs.h
spk_driver.$O: spk.auto.h
spk_driver.$O: $(SRC_DIR)/spk_driver.h

# Dependencies for spk_input.$O:
spk_input.$O: $(SRC_DIR)/spk_input.c
spk_input.$O: $(BLD_TOP)config.h
spk_input.$O: $(BLD_TOP)forbuild.h
spk_input.$O: $(SRC_TOP)prologue.h
spk_input.$O: $(SRC_DIR)/log.h
spk_input.$O: $(SRC_DIR)/driver.h
spk_input.$O: $(SRC_DIR)/spk.h
spk_input.$O: $(SRC_DIR)/spkdefs.h
spk_input.$O: $(SRC_DIR)/spk_input.h
spk_input.$O: $(SRC_DIR)/async.h
spk_input.$O: $(SRC_DIR)/async_io.h
spk_input.$O: $(SRC_DIR)/file.h
spk_input.$O: $(SRC_DIR)/brl.h
spk_input.$O: brlapi_constants.h
spk_input.$O: $(SRC_DIR)/brlapi_keycodes.h
spk_input.$O: $(SRC_DIR)/brldefs.h
spk_input.$O: $(SRC_DIR)/brltty.h
spk_input.$O: $(SRC_DIR)/cmd.h
spk_input.$O: $(SRC_DIR)/cmddefs.h
spk_input.$O: $(SRC_DIR)/ctb.h
spk_input.$O: $(SRC_DIR)/ctbdefs.h
spk_input.$O: $(SRC_DIR)/io_generic.h
spk_input.$O: $(SRC_DIR)/ktb.h
spk_input.$O: $(SRC_DIR)/ktbdefs.h
spk_input.$O: $(SRC_DIR)/menu.h
spk_input.$O: $(SRC_DIR)/pid.h
spk_input.$O: $(SRC_DIR)/prefs.h
spk_input.$O: $(SRC_DIR)/program.h
spk_input.$O: $(SRC_DIR)/scrdefs.h
spk_input.$O: $(SRC_DIR)/serialdefs.h
spk_input.$O: $(SRC_DIR)/ses.h
spk_input.$O: $(SRC_DIR)/timing.h
spk_input.$O: $(SRC_DIR)/tunedefs.h
spk_input.$O: $(SRC_DIR)/tunes.h
spk_input.$O: $(SRC_DIR)/usbdefs.h

# Dependencies for spk_thread.$O:
spk_thread.$O: $(SRC_DIR)/spk_thread.c
spk_thread.$O: $(BLD_TOP)config.h
spk_thread.$O: $(BLD_TOP)forbuild.h
spk_thread.$O: $(SRC_TOP)prologue.h
spk_thread.$O: $(SRC_DIR)/log.h
spk_thread.$O: $(SRC_DIR)/parameters.h
spk_thread.$O: $(SRC_DIR)/driver.h
spk_thread.$O: $(SRC_DIR)/spk.h
spk_thread.$O: $(SRC_DIR)/spk_thread.h
spk_thread.$O: $(SRC_DIR)/spkdefs.h
spk_thread.$O: $(SRC_DIR)/async.h
spk_thread.$O: $(SRC_DIR)/async_wait.h
spk_thread.$O: $(SRC_DIR)/async_event.h
spk_thread.$O: $(SRC_DIR)/async_thread.h
spk_thread.$O: $(SRC_DIR)/timing.h
spk_thread.$O: $(SRC_DIR)/win_pthread.h

# Dependencies for spktest.$O:
spktest.$O: $(SRC_DIR)/spktest.c
spktest.$O: $(BLD_TOP)config.h
spktest.$O: $(BLD_TOP)forbuild.h
spktest.$O: $(SRC_TOP)prologue.h
spktest.$O: $(SRC_DIR)/pid.h
spktest.$O: $(SRC_DIR)/program.h
spktest.$O: $(SRC_DIR)/options.h
spktest.$O: $(SRC_DIR)/driver.h
spktest.$O: $(SRC_DIR)/spk.h
spktest.$O: $(SRC_DIR)/spkdefs.h
spktest.$O: $(SRC_DIR)/log.h
spktest.$O: $(SRC_DIR)/file.h
spktest.$O: $(SRC_DIR)/parse.h

# Dependencies for status.$O:
status.$O: $(SRC_DIR)/status.c
status.$O: $(BLD_TOP)config.h
status.$O: $(BLD_TOP)forbuild.h
status.$O: $(SRC_TOP)prologue.h
status.$O: $(SRC_DIR)/statdefs.h
status.$O: $(SRC_DIR)/status.h
status.$O: $(SRC_DIR)/timing.h
status.$O: $(SRC_DIR)/update.h
status.$O: $(SRC_DIR)/brldefs.h
status.$O: $(SRC_DIR)/cmd_queue.h
status.$O: $(SRC_DIR)/driver.h
status.$O: $(SRC_DIR)/ktbdefs.h
status.$O: $(SRC_DIR)/scr.h
status.$O: $(SRC_DIR)/scrdefs.h
status.$O: $(SRC_DIR)/async.h
status.$O: $(SRC_DIR)/async_io.h
status.$O: $(SRC_DIR)/brl.h
status.$O: brlapi_constants.h
status.$O: $(SRC_DIR)/brlapi_keycodes.h
status.$O: $(SRC_DIR)/brltty.h
status.$O: $(SRC_DIR)/cmd.h
status.$O: $(SRC_DIR)/cmddefs.h
status.$O: $(SRC_DIR)/ctb.h
status.$O: $(SRC_DIR)/ctbdefs.h
status.$O: $(SRC_DIR)/io_generic.h
status.$O: $(SRC_DIR)/ktb.h
status.$O: $(SRC_DIR)/menu.h
status.$O: $(SRC_DIR)/pid.h
status.$O: $(SRC_DIR)/prefs.h
status.$O: $(SRC_DIR)/program.h
status.$O: $(SRC_DIR)/serialdefs.h
status.$O: $(SRC_DIR)/ses.h
status.$O: $(SRC_DIR)/spk.h
status.$O: $(SRC_DIR)/spkdefs.h
status.$O: $(SRC_DIR)/tunedefs.h
status.$O: $(SRC_DIR)/tunes.h
status.$O: $(SRC_DIR)/usbdefs.h
status.$O: $(SRC_DIR)/ttb.h

# Dependencies for sys_darwin.$O:
sys_darwin.$O: $(SRC_DIR)/sys_darwin.c
sys_darwin.$O: $(BLD_TOP)config.h
sys_darwin.$O: $(BLD_TOP)forbuild.h
sys_darwin.$O: $(SRC_TOP)prologue.h
sys_darwin.$O: $(SRC_DIR)/system.h

# Dependencies for sys_freebsd.$O:
sys_freebsd.$O: $(SRC_DIR)/sys_freebsd.c
sys_freebsd.$O: $(BLD_TOP)config.h
sys_freebsd.$O: $(BLD_TOP)forbuild.h
sys_freebsd.$O: $(SRC_TOP)prologue.h
sys_freebsd.$O: $(SRC_DIR)/system.h

# Dependencies for sys_kfreebsd.$O:
sys_kfreebsd.$O: $(SRC_DIR)/sys_kfreebsd.c
sys_kfreebsd.$O: $(BLD_TOP)config.h
sys_kfreebsd.$O: $(BLD_TOP)forbuild.h
sys_kfreebsd.$O: $(SRC_TOP)prologue.h
sys_kfreebsd.$O: $(SRC_DIR)/system.h

# Dependencies for sys_netbsd.$O:
sys_netbsd.$O: $(SRC_DIR)/sys_netbsd.c
sys_netbsd.$O: $(BLD_TOP)config.h
sys_netbsd.$O: $(BLD_TOP)forbuild.h
sys_netbsd.$O: $(SRC_TOP)prologue.h
sys_netbsd.$O: $(SRC_DIR)/system.h

# Dependencies for sys_openbsd.$O:
sys_openbsd.$O: $(SRC_DIR)/sys_openbsd.c
sys_openbsd.$O: $(BLD_TOP)config.h
sys_openbsd.$O: $(BLD_TOP)forbuild.h
sys_openbsd.$O: $(SRC_TOP)prologue.h
sys_openbsd.$O: $(SRC_DIR)/system.h

# Dependencies for sys_solaris.$O:
sys_solaris.$O: $(SRC_DIR)/sys_solaris.c
sys_solaris.$O: $(BLD_TOP)config.h
sys_solaris.$O: $(BLD_TOP)forbuild.h
sys_solaris.$O: $(SRC_TOP)prologue.h
sys_solaris.$O: $(SRC_DIR)/log.h
sys_solaris.$O: $(SRC_DIR)/system.h

# Dependencies for system_darwin.$O:
system_darwin.$O: $(SRC_DIR)/system_darwin.c
system_darwin.$O: $(BLD_TOP)config.h
system_darwin.$O: $(BLD_TOP)forbuild.h
system_darwin.$O: $(SRC_TOP)prologue.h
system_darwin.$O: $(SRC_DIR)/log.h
system_darwin.$O: $(SRC_DIR)/system.h
system_darwin.$O: $(SRC_DIR)/system_darwin.h

# Dependencies for system_java.$O:
system_java.$O: $(SRC_DIR)/system_java.c
system_java.$O: $(BLD_TOP)config.h
system_java.$O: $(BLD_TOP)forbuild.h
system_java.$O: $(SRC_TOP)prologue.h
system_java.$O: $(SRC_DIR)/log.h
system_java.$O: $(SRC_DIR)/system.h
system_java.$O: $(SRC_DIR)/system_java.h

# Dependencies for system_linux.$O:
system_linux.$O: $(SRC_DIR)/system_linux.c
system_linux.$O: $(BLD_TOP)config.h
system_linux.$O: $(BLD_TOP)forbuild.h
system_linux.$O: $(SRC_TOP)prologue.h
system_linux.$O: $(SRC_DIR)/log.h
system_linux.$O: $(SRC_DIR)/file.h
system_linux.$O: $(SRC_DIR)/device.h
system_linux.$O: $(SRC_DIR)/async.h
system_linux.$O: $(SRC_DIR)/async_wait.h
system_linux.$O: $(SRC_DIR)/hostcmd.h
system_linux.$O: $(SRC_DIR)/bitmask.h
system_linux.$O: $(SRC_DIR)/system.h
system_linux.$O: $(SRC_DIR)/system_linux.h

# Dependencies for system_msdos.$O:
system_msdos.$O: $(SRC_DIR)/system_msdos.c
system_msdos.$O: $(BLD_TOP)config.h
system_msdos.$O: $(BLD_TOP)forbuild.h
system_msdos.$O: $(SRC_TOP)prologue.h
system_msdos.$O: $(SRC_DIR)/log.h
system_msdos.$O: $(SRC_DIR)/system.h
system_msdos.$O: $(SRC_DIR)/system_msdos.h

# Dependencies for system_none.$O:
system_none.$O: $(SRC_DIR)/system_none.c
system_none.$O: $(BLD_TOP)config.h
system_none.$O: $(BLD_TOP)forbuild.h
system_none.$O: $(SRC_TOP)prologue.h
system_none.$O: $(SRC_DIR)/system.h

# Dependencies for system_windows.$O:
system_windows.$O: $(SRC_DIR)/system_windows.c
system_windows.$O: $(BLD_TOP)config.h
system_windows.$O: $(BLD_TOP)forbuild.h
system_windows.$O: $(SRC_TOP)prologue.h
system_windows.$O: $(SRC_DIR)/log.h
system_windows.$O: $(SRC_DIR)/timing.h
system_windows.$O: $(SRC_DIR)/system.h
system_windows.$O: $(SRC_DIR)/system_windows.h
system_windows.$O: $(SRC_DIR)/win_errno.h

# Dependencies for tbl2hex.$O:
tbl2hex.$O: $(SRC_DIR)/tbl2hex.c
tbl2hex.$O: $(BLD_TOP)config.h
tbl2hex.$O: $(BLD_TOP)forbuild.h
tbl2hex.$O: $(SRC_TOP)prologue.h
tbl2hex.$O: $(SRC_DIR)/options.h
tbl2hex.$O: $(SRC_DIR)/pid.h
tbl2hex.$O: $(SRC_DIR)/program.h
tbl2hex.$O: $(SRC_DIR)/log.h
tbl2hex.$O: $(SRC_DIR)/file.h
tbl2hex.$O: $(SRC_DIR)/ttb.h
tbl2hex.$O: $(SRC_DIR)/bitmask.h
tbl2hex.$O: $(SRC_DIR)/ttb_internal.h
tbl2hex.$O: $(SRC_DIR)/unicode.h
tbl2hex.$O: $(SRC_DIR)/atb.h
tbl2hex.$O: $(SRC_DIR)/atb_internal.h
tbl2hex.$O: $(SRC_DIR)/ctb.h
tbl2hex.$O: $(SRC_DIR)/ctbdefs.h
tbl2hex.$O: $(SRC_DIR)/ctb_internal.h

# Dependencies for timing.$O:
timing.$O: $(SRC_DIR)/timing.c
timing.$O: $(BLD_TOP)config.h
timing.$O: $(BLD_TOP)forbuild.h
timing.$O: $(SRC_TOP)prologue.h
timing.$O: $(SRC_DIR)/log.h
timing.$O: $(SRC_DIR)/timing.h
timing.$O: $(SRC_DIR)/system_msdos.h

# Dependencies for touch.$O:
touch.$O: $(SRC_DIR)/touch.c
touch.$O: $(BLD_TOP)config.h
touch.$O: $(BLD_TOP)forbuild.h
touch.$O: $(SRC_TOP)prologue.h
touch.$O: $(SRC_DIR)/log.h
touch.$O: $(SRC_DIR)/async.h
touch.$O: $(SRC_DIR)/async_io.h
touch.$O: $(SRC_DIR)/brl.h
touch.$O: $(SRC_DIR)/brldefs.h
touch.$O: $(SRC_DIR)/driver.h
touch.$O: $(SRC_DIR)/io_generic.h
touch.$O: $(SRC_DIR)/ktbdefs.h
touch.$O: $(SRC_DIR)/serialdefs.h
touch.$O: $(SRC_DIR)/touch.h
touch.$O: $(SRC_DIR)/usbdefs.h
touch.$O: brlapi_constants.h
touch.$O: $(SRC_DIR)/brlapi_keycodes.h
touch.$O: $(SRC_DIR)/brltty.h
touch.$O: $(SRC_DIR)/cmd.h
touch.$O: $(SRC_DIR)/cmddefs.h
touch.$O: $(SRC_DIR)/ctb.h
touch.$O: $(SRC_DIR)/ctbdefs.h
touch.$O: $(SRC_DIR)/ktb.h
touch.$O: $(SRC_DIR)/menu.h
touch.$O: $(SRC_DIR)/pid.h
touch.$O: $(SRC_DIR)/prefs.h
touch.$O: $(SRC_DIR)/program.h
touch.$O: $(SRC_DIR)/scrdefs.h
touch.$O: $(SRC_DIR)/ses.h
touch.$O: $(SRC_DIR)/spk.h
touch.$O: $(SRC_DIR)/spkdefs.h
touch.$O: $(SRC_DIR)/timing.h
touch.$O: $(SRC_DIR)/tunedefs.h
touch.$O: $(SRC_DIR)/tunes.h

# Dependencies for ttb_compile.$O:
ttb_compile.$O: $(SRC_DIR)/ttb_compile.c
ttb_compile.$O: $(BLD_TOP)config.h
ttb_compile.$O: $(BLD_TOP)forbuild.h
ttb_compile.$O: $(SRC_TOP)prologue.h
ttb_compile.$O: $(SRC_DIR)/log.h
ttb_compile.$O: $(SRC_DIR)/file.h
ttb_compile.$O: $(SRC_DIR)/datafile.h
ttb_compile.$O: $(SRC_DIR)/queue.h
ttb_compile.$O: $(SRC_DIR)/dataarea.h
ttb_compile.$O: $(SRC_DIR)/charset.h
ttb_compile.$O: $(SRC_DIR)/lock.h
ttb_compile.$O: $(SRC_DIR)/ttb.h
ttb_compile.$O: $(SRC_DIR)/bitmask.h
ttb_compile.$O: $(SRC_DIR)/ttb_internal.h
ttb_compile.$O: $(SRC_DIR)/unicode.h
ttb_compile.$O: $(SRC_DIR)/ttb_compile.h

# Dependencies for ttb_gnome.$O:
ttb_gnome.$O: $(SRC_DIR)/ttb_gnome.c
ttb_gnome.$O: $(BLD_TOP)config.h
ttb_gnome.$O: $(BLD_TOP)forbuild.h
ttb_gnome.$O: $(SRC_TOP)prologue.h
ttb_gnome.$O: $(SRC_DIR)/ttb.h
ttb_gnome.$O: $(SRC_DIR)/bitmask.h
ttb_gnome.$O: $(SRC_DIR)/ttb_internal.h
ttb_gnome.$O: $(SRC_DIR)/unicode.h
ttb_gnome.$O: $(SRC_DIR)/datafile.h
ttb_gnome.$O: $(SRC_DIR)/queue.h
ttb_gnome.$O: $(SRC_DIR)/ttb_compile.h

# Dependencies for ttb_louis.$O:
ttb_louis.$O: $(SRC_DIR)/ttb_louis.c
ttb_louis.$O: $(BLD_TOP)config.h
ttb_louis.$O: $(BLD_TOP)forbuild.h
ttb_louis.$O: $(SRC_TOP)prologue.h
ttb_louis.$O: $(SRC_DIR)/ttb.h
ttb_louis.$O: $(SRC_DIR)/bitmask.h
ttb_louis.$O: $(SRC_DIR)/ttb_internal.h
ttb_louis.$O: $(SRC_DIR)/unicode.h
ttb_louis.$O: $(SRC_DIR)/datafile.h
ttb_louis.$O: $(SRC_DIR)/queue.h
ttb_louis.$O: $(SRC_DIR)/ttb_compile.h

# Dependencies for ttb_native.$O:
ttb_native.$O: $(SRC_DIR)/ttb_native.c
ttb_native.$O: $(BLD_TOP)config.h
ttb_native.$O: $(BLD_TOP)forbuild.h
ttb_native.$O: $(SRC_TOP)prologue.h
ttb_native.$O: $(SRC_DIR)/file.h
ttb_native.$O: $(SRC_DIR)/ttb.h
ttb_native.$O: $(SRC_DIR)/bitmask.h
ttb_native.$O: $(SRC_DIR)/ttb_internal.h
ttb_native.$O: $(SRC_DIR)/unicode.h
ttb_native.$O: $(SRC_DIR)/datafile.h
ttb_native.$O: $(SRC_DIR)/queue.h
ttb_native.$O: $(SRC_DIR)/ttb_compile.h

# Dependencies for ttb_translate.$O:
ttb_translate.$O: $(SRC_DIR)/ttb_translate.c
ttb_translate.$O: $(BLD_TOP)config.h
ttb_translate.$O: $(BLD_TOP)forbuild.h
ttb_translate.$O: $(SRC_TOP)prologue.h
ttb_translate.$O: $(SRC_DIR)/log.h
ttb_translate.$O: $(SRC_DIR)/file.h
ttb_translate.$O: $(SRC_DIR)/charset.h
ttb_translate.$O: $(SRC_DIR)/lock.h
ttb_translate.$O: $(SRC_DIR)/ttb.h
ttb_translate.$O: $(SRC_DIR)/bitmask.h
ttb_translate.$O: $(SRC_DIR)/ttb_internal.h
ttb_translate.$O: $(SRC_DIR)/unicode.h
ttb_translate.$O: $(SRC_DIR)/brldots.h
ttb_translate.$O: text.auto.h

# Dependencies for tunes.$O:
tunes.$O: $(SRC_DIR)/tunes.c
tunes.$O: $(BLD_TOP)config.h
tunes.$O: $(BLD_TOP)forbuild.h
tunes.$O: $(SRC_TOP)prologue.h
tunes.$O: $(SRC_DIR)/log.h
tunes.$O: $(SRC_DIR)/parameters.h
tunes.$O: $(SRC_DIR)/async.h
tunes.$O: $(SRC_DIR)/async_alarm.h
tunes.$O: $(SRC_DIR)/timing.h
tunes.$O: $(SRC_DIR)/pid.h
tunes.$O: $(SRC_DIR)/program.h
tunes.$O: $(SRC_DIR)/tunedefs.h
tunes.$O: $(SRC_DIR)/tunes.h
tunes.$O: $(SRC_DIR)/prefs.h
tunes.$O: $(SRC_DIR)/notes.h
tunes.$O: $(SRC_DIR)/message.h
tunes.$O: $(SRC_DIR)/async_io.h
tunes.$O: $(SRC_DIR)/brl.h
tunes.$O: $(SRC_DIR)/brldefs.h
tunes.$O: $(SRC_DIR)/driver.h
tunes.$O: $(SRC_DIR)/io_generic.h
tunes.$O: $(SRC_DIR)/ktbdefs.h
tunes.$O: $(SRC_DIR)/serialdefs.h
tunes.$O: $(SRC_DIR)/usbdefs.h

# Dependencies for tunetest.$O:
tunetest.$O: $(SRC_DIR)/tunetest.c
tunetest.$O: $(BLD_TOP)config.h
tunetest.$O: $(BLD_TOP)forbuild.h
tunetest.$O: $(SRC_TOP)prologue.h
tunetest.$O: $(SRC_DIR)/options.h
tunetest.$O: $(SRC_DIR)/pid.h
tunetest.$O: $(SRC_DIR)/program.h
tunetest.$O: $(SRC_DIR)/tunedefs.h
tunetest.$O: $(SRC_DIR)/tunes.h
tunetest.$O: $(SRC_DIR)/notes.h
tunetest.$O: $(SRC_DIR)/midi.h
tunetest.$O: $(SRC_DIR)/log.h
tunetest.$O: $(SRC_DIR)/parse.h
tunetest.$O: $(SRC_DIR)/brldefs.h
tunetest.$O: $(SRC_DIR)/ctbdefs.h
tunetest.$O: $(SRC_DIR)/defaults.h
tunetest.$O: $(SRC_DIR)/parameters.h
tunetest.$O: $(SRC_DIR)/spkdefs.h
tunetest.$O: $(SRC_DIR)/prefs.h
tunetest.$O: $(SRC_DIR)/message.h
tunetest.$O: $(SRC_DIR)/async.h
tunetest.$O: $(SRC_DIR)/async_io.h
tunetest.$O: $(SRC_DIR)/brl.h
tunetest.$O: $(SRC_DIR)/driver.h
tunetest.$O: $(SRC_DIR)/io_generic.h
tunetest.$O: $(SRC_DIR)/ktbdefs.h
tunetest.$O: $(SRC_DIR)/serialdefs.h
tunetest.$O: $(SRC_DIR)/usbdefs.h

# Dependencies for unicode.$O:
unicode.$O: $(SRC_DIR)/unicode.c
unicode.$O: $(BLD_TOP)config.h
unicode.$O: $(BLD_TOP)forbuild.h
unicode.$O: $(SRC_TOP)prologue.h
unicode.$O: $(SRC_DIR)/unicode.h
unicode.$O: $(SRC_DIR)/ascii.h

# Dependencies for update.$O:
update.$O: $(SRC_DIR)/update.c
update.$O: $(BLD_TOP)config.h
update.$O: $(BLD_TOP)forbuild.h
update.$O: $(SRC_TOP)prologue.h
update.$O: $(SRC_DIR)/log.h
update.$O: $(SRC_DIR)/parameters.h
update.$O: $(SRC_DIR)/update.h
update.$O: $(SRC_DIR)/async.h
update.$O: $(SRC_DIR)/async_alarm.h
update.$O: $(SRC_DIR)/timing.h
update.$O: $(SRC_DIR)/unicode.h
update.$O: $(SRC_DIR)/charset.h
update.$O: $(SRC_DIR)/lock.h
update.$O: $(SRC_DIR)/ttb.h
update.$O: $(SRC_DIR)/atb.h
update.$O: $(SRC_DIR)/async_io.h
update.$O: $(SRC_DIR)/brl.h
update.$O: $(SRC_DIR)/brldefs.h
update.$O: $(SRC_DIR)/driver.h
update.$O: $(SRC_DIR)/io_generic.h
update.$O: $(SRC_DIR)/ktbdefs.h
update.$O: $(SRC_DIR)/serialdefs.h
update.$O: $(SRC_DIR)/usbdefs.h
update.$O: $(SRC_DIR)/spk.h
update.$O: $(SRC_DIR)/spkdefs.h
update.$O: $(SRC_DIR)/cmd_queue.h
update.$O: $(SRC_DIR)/scr.h
update.$O: $(SRC_DIR)/scrdefs.h
update.$O: $(SRC_DIR)/prefs.h
update.$O: $(SRC_DIR)/statdefs.h
update.$O: $(SRC_DIR)/status.h
update.$O: $(SRC_DIR)/blink.h
update.$O: $(SRC_DIR)/touch.h
update.$O: $(SRC_DIR)/routing.h
update.$O: $(SRC_DIR)/api_control.h
update.$O: brlapi_constants.h
update.$O: $(SRC_DIR)/brlapi_keycodes.h
update.$O: $(SRC_DIR)/brltty.h
update.$O: $(SRC_DIR)/cmd.h
update.$O: $(SRC_DIR)/cmddefs.h
update.$O: $(SRC_DIR)/ctb.h
update.$O: $(SRC_DIR)/ctbdefs.h
update.$O: $(SRC_DIR)/ktb.h
update.$O: $(SRC_DIR)/menu.h
update.$O: $(SRC_DIR)/pid.h
update.$O: $(SRC_DIR)/program.h
update.$O: $(SRC_DIR)/ses.h
update.$O: $(SRC_DIR)/tunedefs.h
update.$O: $(SRC_DIR)/tunes.h

# Dependencies for usb.$O:
usb.$O: $(SRC_DIR)/usb.c
usb.$O: $(BLD_TOP)config.h
usb.$O: $(BLD_TOP)forbuild.h
usb.$O: $(SRC_TOP)prologue.h
usb.$O: $(SRC_DIR)/log.h
usb.$O: $(SRC_DIR)/parameters.h
usb.$O: $(SRC_DIR)/parse.h
usb.$O: $(SRC_DIR)/file.h
usb.$O: $(SRC_DIR)/device.h
usb.$O: $(SRC_DIR)/timing.h
usb.$O: $(SRC_DIR)/async.h
usb.$O: $(SRC_DIR)/async_wait.h
usb.$O: $(SRC_DIR)/io_misc.h
usb.$O: $(SRC_DIR)/async_io.h
usb.$O: $(SRC_DIR)/io_usb.h
usb.$O: $(SRC_DIR)/serialdefs.h
usb.$O: $(SRC_DIR)/usbdefs.h
usb.$O: $(SRC_DIR)/bitfield.h
usb.$O: $(SRC_DIR)/queue.h
usb.$O: $(SRC_DIR)/usb_internal.h

# Dependencies for usb_android.$O:
usb_android.$O: $(SRC_DIR)/usb_android.c
usb_android.$O: $(BLD_TOP)config.h
usb_android.$O: $(BLD_TOP)forbuild.h
usb_android.$O: $(SRC_TOP)prologue.h
usb_android.$O: $(SRC_DIR)/log.h
usb_android.$O: $(SRC_DIR)/queue.h
usb_android.$O: $(SRC_DIR)/async.h
usb_android.$O: $(SRC_DIR)/async_io.h
usb_android.$O: $(SRC_DIR)/io_usb.h
usb_android.$O: $(SRC_DIR)/serialdefs.h
usb_android.$O: $(SRC_DIR)/usbdefs.h
usb_android.$O: $(SRC_DIR)/bitfield.h
usb_android.$O: $(SRC_DIR)/usb_internal.h
usb_android.$O: $(SRC_DIR)/system_java.h

# Dependencies for usb_belkin.$O:
usb_belkin.$O: $(SRC_DIR)/usb_belkin.c
usb_belkin.$O: $(BLD_TOP)config.h
usb_belkin.$O: $(BLD_TOP)forbuild.h
usb_belkin.$O: $(SRC_TOP)prologue.h
usb_belkin.$O: $(SRC_DIR)/log.h
usb_belkin.$O: $(SRC_DIR)/async.h
usb_belkin.$O: $(SRC_DIR)/async_io.h
usb_belkin.$O: $(SRC_DIR)/io_usb.h
usb_belkin.$O: $(SRC_DIR)/serialdefs.h
usb_belkin.$O: $(SRC_DIR)/usb_serial.h
usb_belkin.$O: $(SRC_DIR)/usbdefs.h
usb_belkin.$O: $(SRC_DIR)/usb_belkin.h

# Dependencies for usb_cdc_acm.$O:
usb_cdc_acm.$O: $(SRC_DIR)/usb_cdc_acm.c
usb_cdc_acm.$O: $(BLD_TOP)config.h
usb_cdc_acm.$O: $(BLD_TOP)forbuild.h
usb_cdc_acm.$O: $(SRC_TOP)prologue.h
usb_cdc_acm.$O: $(SRC_DIR)/log.h
usb_cdc_acm.$O: $(SRC_DIR)/async.h
usb_cdc_acm.$O: $(SRC_DIR)/async_io.h
usb_cdc_acm.$O: $(SRC_DIR)/io_usb.h
usb_cdc_acm.$O: $(SRC_DIR)/serialdefs.h
usb_cdc_acm.$O: $(SRC_DIR)/usb_serial.h
usb_cdc_acm.$O: $(SRC_DIR)/usbdefs.h
usb_cdc_acm.$O: $(SRC_DIR)/usb_cdc_acm.h
usb_cdc_acm.$O: $(SRC_DIR)/bitfield.h
usb_cdc_acm.$O: $(SRC_DIR)/queue.h
usb_cdc_acm.$O: $(SRC_DIR)/usb_internal.h

# Dependencies for usb_cp2101.$O:
usb_cp2101.$O: $(SRC_DIR)/usb_cp2101.c
usb_cp2101.$O: $(BLD_TOP)config.h
usb_cp2101.$O: $(BLD_TOP)forbuild.h
usb_cp2101.$O: $(SRC_TOP)prologue.h
usb_cp2101.$O: $(SRC_DIR)/log.h
usb_cp2101.$O: $(SRC_DIR)/async.h
usb_cp2101.$O: $(SRC_DIR)/async_io.h
usb_cp2101.$O: $(SRC_DIR)/io_usb.h
usb_cp2101.$O: $(SRC_DIR)/serialdefs.h
usb_cp2101.$O: $(SRC_DIR)/usb_serial.h
usb_cp2101.$O: $(SRC_DIR)/usbdefs.h
usb_cp2101.$O: $(SRC_DIR)/usb_cp2101.h
usb_cp2101.$O: $(SRC_DIR)/bitfield.h

# Dependencies for usb_cp2110.$O:
usb_cp2110.$O: $(SRC_DIR)/usb_cp2110.c
usb_cp2110.$O: $(BLD_TOP)config.h
usb_cp2110.$O: $(BLD_TOP)forbuild.h
usb_cp2110.$O: $(SRC_TOP)prologue.h
usb_cp2110.$O: $(SRC_DIR)/log.h
usb_cp2110.$O: $(SRC_DIR)/async.h
usb_cp2110.$O: $(SRC_DIR)/async_io.h
usb_cp2110.$O: $(SRC_DIR)/io_usb.h
usb_cp2110.$O: $(SRC_DIR)/serialdefs.h
usb_cp2110.$O: $(SRC_DIR)/usb_serial.h
usb_cp2110.$O: $(SRC_DIR)/usbdefs.h
usb_cp2110.$O: $(SRC_DIR)/usb_cp2110.h
usb_cp2110.$O: $(SRC_DIR)/bitfield.h

# Dependencies for usb_darwin.$O:
usb_darwin.$O: $(SRC_DIR)/usb_darwin.c
usb_darwin.$O: $(BLD_TOP)config.h
usb_darwin.$O: $(BLD_TOP)forbuild.h
usb_darwin.$O: $(SRC_TOP)prologue.h
usb_darwin.$O: $(SRC_DIR)/log.h
usb_darwin.$O: $(SRC_DIR)/async.h
usb_darwin.$O: $(SRC_DIR)/async_io.h
usb_darwin.$O: $(SRC_DIR)/io_usb.h
usb_darwin.$O: $(SRC_DIR)/serialdefs.h
usb_darwin.$O: $(SRC_DIR)/usbdefs.h
usb_darwin.$O: $(SRC_DIR)/bitfield.h
usb_darwin.$O: $(SRC_DIR)/queue.h
usb_darwin.$O: $(SRC_DIR)/usb_internal.h
usb_darwin.$O: $(SRC_DIR)/system_darwin.h

# Dependencies for usb_freebsd.$O:
usb_freebsd.$O: $(SRC_DIR)/usb_freebsd.c
usb_freebsd.$O: $(BLD_TOP)config.h
usb_freebsd.$O: $(BLD_TOP)forbuild.h
usb_freebsd.$O: $(SRC_TOP)prologue.h
usb_freebsd.$O: $(SRC_DIR)/async.h
usb_freebsd.$O: $(SRC_DIR)/async_io.h
usb_freebsd.$O: $(SRC_DIR)/io_usb.h
usb_freebsd.$O: $(SRC_DIR)/serialdefs.h
usb_freebsd.$O: $(SRC_DIR)/usbdefs.h
usb_freebsd.$O: $(SRC_DIR)/bitfield.h
usb_freebsd.$O: $(SRC_DIR)/queue.h
usb_freebsd.$O: $(SRC_DIR)/usb_internal.h
usb_freebsd.$O: $(SRC_DIR)/log.h
usb_freebsd.$O: $(SRC_DIR)/usb_bsd.h

# Dependencies for usb_ftdi.$O:
usb_ftdi.$O: $(SRC_DIR)/usb_ftdi.c
usb_ftdi.$O: $(BLD_TOP)config.h
usb_ftdi.$O: $(BLD_TOP)forbuild.h
usb_ftdi.$O: $(SRC_TOP)prologue.h
usb_ftdi.$O: $(SRC_DIR)/log.h
usb_ftdi.$O: $(SRC_DIR)/async.h
usb_ftdi.$O: $(SRC_DIR)/async_io.h
usb_ftdi.$O: $(SRC_DIR)/io_usb.h
usb_ftdi.$O: $(SRC_DIR)/serialdefs.h
usb_ftdi.$O: $(SRC_DIR)/usb_serial.h
usb_ftdi.$O: $(SRC_DIR)/usbdefs.h
usb_ftdi.$O: $(SRC_DIR)/usb_ftdi.h

# Dependencies for usb_grub.$O:
usb_grub.$O: $(SRC_DIR)/usb_grub.c
usb_grub.$O: $(BLD_TOP)config.h
usb_grub.$O: $(BLD_TOP)forbuild.h
usb_grub.$O: $(SRC_TOP)prologue.h
usb_grub.$O: $(SRC_DIR)/log.h
usb_grub.$O: $(SRC_DIR)/async.h
usb_grub.$O: $(SRC_DIR)/async_io.h
usb_grub.$O: $(SRC_DIR)/io_usb.h
usb_grub.$O: $(SRC_DIR)/serialdefs.h
usb_grub.$O: $(SRC_DIR)/usbdefs.h
usb_grub.$O: $(SRC_DIR)/bitfield.h
usb_grub.$O: $(SRC_DIR)/queue.h
usb_grub.$O: $(SRC_DIR)/usb_internal.h

# Dependencies for usb_hid.$O:
usb_hid.$O: $(SRC_DIR)/usb_hid.c
usb_hid.$O: $(BLD_TOP)config.h
usb_hid.$O: $(BLD_TOP)forbuild.h
usb_hid.$O: $(SRC_TOP)prologue.h
usb_hid.$O: $(SRC_DIR)/log.h
usb_hid.$O: $(SRC_DIR)/bitfield.h
usb_hid.$O: $(SRC_DIR)/async.h
usb_hid.$O: $(SRC_DIR)/async_io.h
usb_hid.$O: $(SRC_DIR)/io_usb.h
usb_hid.$O: $(SRC_DIR)/serialdefs.h
usb_hid.$O: $(SRC_DIR)/usbdefs.h

# Dependencies for usb_kfreebsd.$O:
usb_kfreebsd.$O: $(SRC_DIR)/usb_kfreebsd.c
usb_kfreebsd.$O: $(BLD_TOP)config.h
usb_kfreebsd.$O: $(BLD_TOP)forbuild.h
usb_kfreebsd.$O: $(SRC_TOP)prologue.h
usb_kfreebsd.$O: $(SRC_DIR)/async.h
usb_kfreebsd.$O: $(SRC_DIR)/async_io.h
usb_kfreebsd.$O: $(SRC_DIR)/io_usb.h
usb_kfreebsd.$O: $(SRC_DIR)/serialdefs.h
usb_kfreebsd.$O: $(SRC_DIR)/usbdefs.h
usb_kfreebsd.$O: $(SRC_DIR)/bitfield.h
usb_kfreebsd.$O: $(SRC_DIR)/queue.h
usb_kfreebsd.$O: $(SRC_DIR)/usb_internal.h
usb_kfreebsd.$O: $(SRC_DIR)/log.h
usb_kfreebsd.$O: $(SRC_DIR)/usb_bsd.h

# Dependencies for usb_libusb-1.0.$O:
usb_libusb-1.0.$O: $(SRC_DIR)/usb_libusb-1.0.c
usb_libusb-1.0.$O: $(BLD_TOP)config.h
usb_libusb-1.0.$O: $(BLD_TOP)forbuild.h
usb_libusb-1.0.$O: $(SRC_TOP)prologue.h
usb_libusb-1.0.$O: $(SRC_DIR)/log.h
usb_libusb-1.0.$O: $(SRC_DIR)/async.h
usb_libusb-1.0.$O: $(SRC_DIR)/async_io.h
usb_libusb-1.0.$O: $(SRC_DIR)/io_usb.h
usb_libusb-1.0.$O: $(SRC_DIR)/serialdefs.h
usb_libusb-1.0.$O: $(SRC_DIR)/usbdefs.h
usb_libusb-1.0.$O: $(SRC_DIR)/bitfield.h
usb_libusb-1.0.$O: $(SRC_DIR)/queue.h
usb_libusb-1.0.$O: $(SRC_DIR)/usb_internal.h

# Dependencies for usb_libusb.$O:
usb_libusb.$O: $(SRC_DIR)/usb_libusb.c
usb_libusb.$O: $(BLD_TOP)config.h
usb_libusb.$O: $(BLD_TOP)forbuild.h
usb_libusb.$O: $(SRC_TOP)prologue.h
usb_libusb.$O: $(SRC_DIR)/log.h
usb_libusb.$O: $(SRC_DIR)/async.h
usb_libusb.$O: $(SRC_DIR)/async_io.h
usb_libusb.$O: $(SRC_DIR)/io_usb.h
usb_libusb.$O: $(SRC_DIR)/serialdefs.h
usb_libusb.$O: $(SRC_DIR)/usbdefs.h
usb_libusb.$O: $(SRC_DIR)/bitfield.h
usb_libusb.$O: $(SRC_DIR)/queue.h
usb_libusb.$O: $(SRC_DIR)/usb_internal.h

# Dependencies for usb_linux.$O:
usb_linux.$O: $(SRC_DIR)/usb_linux.c
usb_linux.$O: $(BLD_TOP)config.h
usb_linux.$O: $(BLD_TOP)forbuild.h
usb_linux.$O: $(SRC_TOP)prologue.h
usb_linux.$O: $(SRC_DIR)/log.h
usb_linux.$O: $(SRC_DIR)/parameters.h
usb_linux.$O: $(SRC_DIR)/file.h
usb_linux.$O: $(SRC_DIR)/parse.h
usb_linux.$O: $(SRC_DIR)/timing.h
usb_linux.$O: $(SRC_DIR)/async.h
usb_linux.$O: $(SRC_DIR)/async_wait.h
usb_linux.$O: $(SRC_DIR)/async_alarm.h
usb_linux.$O: $(SRC_DIR)/async_io.h
usb_linux.$O: $(SRC_DIR)/async_signal.h
usb_linux.$O: $(SRC_DIR)/mntpt.h
usb_linux.$O: $(SRC_DIR)/io_usb.h
usb_linux.$O: $(SRC_DIR)/serialdefs.h
usb_linux.$O: $(SRC_DIR)/usbdefs.h
usb_linux.$O: $(SRC_DIR)/bitfield.h
usb_linux.$O: $(SRC_DIR)/queue.h
usb_linux.$O: $(SRC_DIR)/usb_internal.h

# Dependencies for usb_netbsd.$O:
usb_netbsd.$O: $(SRC_DIR)/usb_netbsd.c
usb_netbsd.$O: $(BLD_TOP)config.h
usb_netbsd.$O: $(BLD_TOP)forbuild.h
usb_netbsd.$O: $(SRC_TOP)prologue.h
usb_netbsd.$O: $(SRC_DIR)/async.h
usb_netbsd.$O: $(SRC_DIR)/async_io.h
usb_netbsd.$O: $(SRC_DIR)/io_usb.h
usb_netbsd.$O: $(SRC_DIR)/serialdefs.h
usb_netbsd.$O: $(SRC_DIR)/usbdefs.h
usb_netbsd.$O: $(SRC_DIR)/bitfield.h
usb_netbsd.$O: $(SRC_DIR)/queue.h
usb_netbsd.$O: $(SRC_DIR)/usb_internal.h
usb_netbsd.$O: $(SRC_DIR)/log.h
usb_netbsd.$O: $(SRC_DIR)/usb_bsd.h

# Dependencies for usb_none.$O:
usb_none.$O: $(SRC_DIR)/usb_none.c
usb_none.$O: $(BLD_TOP)config.h
usb_none.$O: $(BLD_TOP)forbuild.h
usb_none.$O: $(SRC_TOP)prologue.h
usb_none.$O: $(SRC_DIR)/log.h
usb_none.$O: $(SRC_DIR)/async.h
usb_none.$O: $(SRC_DIR)/async_io.h
usb_none.$O: $(SRC_DIR)/io_usb.h
usb_none.$O: $(SRC_DIR)/serialdefs.h
usb_none.$O: $(SRC_DIR)/usbdefs.h
usb_none.$O: $(SRC_DIR)/bitfield.h
usb_none.$O: $(SRC_DIR)/queue.h
usb_none.$O: $(SRC_DIR)/usb_internal.h

# Dependencies for usb_openbsd.$O:
usb_openbsd.$O: $(SRC_DIR)/usb_openbsd.c
usb_openbsd.$O: $(BLD_TOP)config.h
usb_openbsd.$O: $(BLD_TOP)forbuild.h
usb_openbsd.$O: $(SRC_TOP)prologue.h
usb_openbsd.$O: $(SRC_DIR)/async.h
usb_openbsd.$O: $(SRC_DIR)/async_io.h
usb_openbsd.$O: $(SRC_DIR)/io_usb.h
usb_openbsd.$O: $(SRC_DIR)/serialdefs.h
usb_openbsd.$O: $(SRC_DIR)/usbdefs.h
usb_openbsd.$O: $(SRC_DIR)/bitfield.h
usb_openbsd.$O: $(SRC_DIR)/queue.h
usb_openbsd.$O: $(SRC_DIR)/usb_internal.h
usb_openbsd.$O: $(SRC_DIR)/log.h
usb_openbsd.$O: $(SRC_DIR)/usb_bsd.h

# Dependencies for usb_serial.$O:
usb_serial.$O: $(SRC_DIR)/usb_serial.c
usb_serial.$O: $(BLD_TOP)config.h
usb_serial.$O: $(BLD_TOP)forbuild.h
usb_serial.$O: $(SRC_TOP)prologue.h
usb_serial.$O: $(SRC_DIR)/log.h
usb_serial.$O: $(SRC_DIR)/async.h
usb_serial.$O: $(SRC_DIR)/async_io.h
usb_serial.$O: $(SRC_DIR)/io_usb.h
usb_serial.$O: $(SRC_DIR)/serialdefs.h
usb_serial.$O: $(SRC_DIR)/usbdefs.h
usb_serial.$O: $(SRC_DIR)/bitfield.h
usb_serial.$O: $(SRC_DIR)/queue.h
usb_serial.$O: $(SRC_DIR)/usb_internal.h
usb_serial.$O: $(SRC_DIR)/usb_serial.h

# Dependencies for usb_solaris.$O:
usb_solaris.$O: $(SRC_DIR)/usb_solaris.c
usb_solaris.$O: $(BLD_TOP)config.h
usb_solaris.$O: $(BLD_TOP)forbuild.h
usb_solaris.$O: $(SRC_TOP)prologue.h
usb_solaris.$O: $(SRC_DIR)/log.h
usb_solaris.$O: $(SRC_DIR)/async.h
usb_solaris.$O: $(SRC_DIR)/async_io.h
usb_solaris.$O: $(SRC_DIR)/io_usb.h
usb_solaris.$O: $(SRC_DIR)/serialdefs.h
usb_solaris.$O: $(SRC_DIR)/usbdefs.h
usb_solaris.$O: $(SRC_DIR)/bitfield.h
usb_solaris.$O: $(SRC_DIR)/queue.h
usb_solaris.$O: $(SRC_DIR)/usb_internal.h

# Dependencies for xbrlapi.$O:
xbrlapi.$O: $(SRC_DIR)/xbrlapi.c
xbrlapi.$O: $(BLD_TOP)config.h
xbrlapi.$O: $(BLD_TOP)forbuild.h
xbrlapi.$O: $(SRC_TOP)prologue.h
xbrlapi.$O: brlapi.h
xbrlapi.$O: brlapi_constants.h
xbrlapi.$O: $(SRC_DIR)/brlapi_keycodes.h
xbrlapi.$O: $(SRC_DIR)/options.h
xbrlapi.$O: $(SRC_DIR)/pid.h
xbrlapi.$O: $(SRC_DIR)/program.h

