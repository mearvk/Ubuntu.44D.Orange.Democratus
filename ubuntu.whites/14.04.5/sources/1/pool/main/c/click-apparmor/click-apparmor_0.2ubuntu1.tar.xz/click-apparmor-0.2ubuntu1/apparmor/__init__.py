# http://legacy.python.org/dev/peps/pep-0420/
__import__('pkg_resources').declare_namespace(__name__)
