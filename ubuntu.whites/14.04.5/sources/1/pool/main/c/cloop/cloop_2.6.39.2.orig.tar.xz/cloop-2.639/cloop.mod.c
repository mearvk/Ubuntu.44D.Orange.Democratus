#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x2d8a3ad2, "module_layout" },
	{ 0xacc1ebd1, "param_ops_charp" },
	{ 0x13095525, "param_ops_uint" },
	{ 0xb5a459dc, "unregister_blkdev" },
	{ 0xfc9e6734, "filp_open" },
	{ 0xd0d8621b, "strlen" },
	{ 0x4f44a1a4, "add_disk" },
	{ 0x3c2c5af5, "sprintf" },
	{ 0x652fcada, "alloc_disk" },
	{ 0xc2cb9a20, "blk_init_queue" },
	{ 0xe8cab308, "__mutex_init" },
	{ 0xe174aa7, "__init_waitqueue_head" },
	{ 0x71a50dbc, "register_blkdev" },
	{ 0xc7df9c09, "set_device_ro" },
	{ 0x45e9a79, "fget" },
	{ 0x834e02c3, "mutex_unlock" },
	{ 0xdcc4d3, "mutex_lock" },
	{ 0xc6265ac8, "wake_up_process" },
	{ 0x920059bf, "kthread_create_on_node" },
	{ 0xa9630bdb, "blk_queue_merge_bvec" },
	{ 0xf374ba0c, "blk_queue_segment_boundary" },
	{ 0x9df0faa, "blk_queue_max_segment_size" },
	{ 0xbba977a5, "blk_queue_max_segments" },
	{ 0x49244a3c, "blk_queue_max_hw_sectors" },
	{ 0xb00ccc33, "finish_wait" },
	{ 0xe75663a, "prepare_to_wait" },
	{ 0x4292364c, "schedule" },
	{ 0xc8b57c27, "autoremove_wake_function" },
	{ 0x88941a06, "_raw_spin_unlock_irqrestore" },
	{ 0x587c70d8, "_raw_spin_lock_irqsave" },
	{ 0xc37aad4a, "kunmap" },
	{ 0x2e60bace, "memcpy" },
	{ 0x2945edfe, "kmap" },
	{ 0x6f5427, "_raw_spin_unlock_irq" },
	{ 0xf333a2fb, "_raw_spin_lock_irq" },
	{ 0xd2965f6f, "kthread_should_stop" },
	{ 0xae1ffdd4, "set_user_nice" },
	{ 0x3d91e0b3, "current_task" },
	{ 0x4211c3c1, "zlib_inflateInit2" },
	{ 0x881039d0, "zlib_inflate" },
	{ 0x3ed63055, "zlib_inflateReset" },
	{ 0x2bc95bd4, "memset" },
	{ 0xeccf092, "vfs_read" },
	{ 0x12da5bb2, "__kmalloc" },
	{ 0xd6ee688f, "vmalloc" },
	{ 0x50eedeb8, "printk" },
	{ 0x272dbc4f, "__blk_end_request_all" },
	{ 0xb2ba701, "blk_fetch_request" },
	{ 0xf09c7f68, "__wake_up" },
	{ 0x2da418b5, "copy_to_user" },
	{ 0xc00559f3, "vfs_getattr" },
	{ 0x33d169c9, "_copy_from_user" },
	{ 0xf744654c, "put_disk" },
	{ 0xa67c7a0c, "blk_cleanup_queue" },
	{ 0x78a9f01a, "del_gendisk" },
	{ 0x9cf53a18, "filp_close" },
	{ 0x637a9b32, "invalidate_bdev" },
	{ 0xce5ac24f, "zlib_inflate_workspacesize" },
	{ 0x77ecac9f, "zlib_inflateEnd" },
	{ 0x2ebdc1d9, "fput" },
	{ 0xb928dcba, "kthread_stop" },
	{ 0x37a0cba, "kfree" },
	{ 0x999e8297, "vfree" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

