#!/bin/sh

set -e

cd UnifiedDataExtractor

# backup copy 
if [ -e scan.data ]; then
    cp scan.data scan.data-old
fi

# archive data is extracted here
scp pepo.canonical.com:~mvo/archive-crawler/mvo/data/scan.data .

# cleanup
rm -f scan.1 scan.2

if [ -e scan.data-old ]; then
    ./diff-scan-data scan.data-old scan.data|less
fi
