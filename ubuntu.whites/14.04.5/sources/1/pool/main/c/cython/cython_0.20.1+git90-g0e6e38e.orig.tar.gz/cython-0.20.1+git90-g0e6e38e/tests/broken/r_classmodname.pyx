class Spam:
    pass
