def foo():
    raise Exception
