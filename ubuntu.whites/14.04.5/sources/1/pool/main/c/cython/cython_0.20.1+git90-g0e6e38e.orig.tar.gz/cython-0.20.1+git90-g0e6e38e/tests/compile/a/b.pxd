cdef int **foo(void*)
