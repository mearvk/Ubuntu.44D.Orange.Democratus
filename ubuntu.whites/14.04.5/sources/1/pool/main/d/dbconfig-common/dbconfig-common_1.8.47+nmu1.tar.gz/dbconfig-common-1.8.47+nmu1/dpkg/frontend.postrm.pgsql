dbc_frontend="true"
. /usr/share/dbconfig-common/dpkg/postrm.pgsql
