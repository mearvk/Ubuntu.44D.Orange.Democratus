#!/bin/sh
set -e

# start X
(Xvfb :5 >/dev/null 2>&1 &)
XVFB_PID=$!
export DISPLAY=:5

# start local session D-BUS
eval `dbus-launch`
trap "kill $DBUS_SESSION_BUS_PID $XVFB_PID" 0 TERM QUIT INT
export DBUS_SESSION_BUS_ADDRESS
export XAUTHORITY=/dev/null

# change to the directory where your autopilot tests live, and run them
HAS_CCPANEL=0 LANG=C DEJA_DUP_TESTING=1 PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. ../../tests/shell autopilot run deja_dup_autopilot.test_overwrite.OverwriteTests.test_overwrite_one
