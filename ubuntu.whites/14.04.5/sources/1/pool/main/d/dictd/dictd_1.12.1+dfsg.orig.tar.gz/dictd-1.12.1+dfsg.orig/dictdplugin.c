#include "dictdplugin.h"
