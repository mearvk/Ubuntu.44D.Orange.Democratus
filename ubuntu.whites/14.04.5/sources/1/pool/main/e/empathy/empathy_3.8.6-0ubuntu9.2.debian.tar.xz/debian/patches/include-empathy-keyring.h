Description: Fix implicit reclaration of empathy_keyring_set_account_password_finish and friends
Author: Iain Lane <iain.lane@canonical.com>
Bug-Upstream: https://bugzilla.gnome.org/show_bug.cgi?id=701281

--- empathy-3.8.3.orig/src/empathy-sanity-cleaning.c
+++ empathy-3.8.3/src/empathy-sanity-cleaning.c
@@ -30,6 +30,7 @@
 #include <libempathy-gtk/empathy-theme-manager.h>
 
 #ifdef HAVE_UOA
+#include <libempathy/empathy-keyring.h>
 #include <libempathy/empathy-pkg-kit.h>
 #include <libempathy/empathy-uoa-utils.h>
 
