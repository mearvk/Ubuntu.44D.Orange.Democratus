
/* Generated data (by glib-mkenums) */

#include "e-source-enumtypes.h"
/* enumerations from "./e-source-enums.h" */
#include "./e-source-enums.h"

GType
e_mdn_response_policy_get_type (void)
{
	static volatile gsize the_type__volatile = 0;

	if (g_once_init_enter (&the_type__volatile)) {
		static const GEnumValue values[] = {
			{ E_MDN_RESPONSE_POLICY_NEVER,
			  "E_MDN_RESPONSE_POLICY_NEVER",
			  "never" },
			{ E_MDN_RESPONSE_POLICY_ALWAYS,
			  "E_MDN_RESPONSE_POLICY_ALWAYS",
			  "always" },
			{ E_MDN_RESPONSE_POLICY_ASK,
			  "E_MDN_RESPONSE_POLICY_ASK",
			  "ask" },
			{ 0, NULL, NULL }
		};
		GType the_type = g_enum_register_static (
			g_intern_static_string ("EMdnResponsePolicy"),
			values);
		g_once_init_leave (&the_type__volatile, the_type);
	}
	return the_type__volatile;
}

GType
e_source_authentication_result_get_type (void)
{
	static volatile gsize the_type__volatile = 0;

	if (g_once_init_enter (&the_type__volatile)) {
		static const GEnumValue values[] = {
			{ E_SOURCE_AUTHENTICATION_ERROR,
			  "E_SOURCE_AUTHENTICATION_ERROR",
			  "error" },
			{ E_SOURCE_AUTHENTICATION_ACCEPTED,
			  "E_SOURCE_AUTHENTICATION_ACCEPTED",
			  "accepted" },
			{ E_SOURCE_AUTHENTICATION_REJECTED,
			  "E_SOURCE_AUTHENTICATION_REJECTED",
			  "rejected" },
			{ 0, NULL, NULL }
		};
		GType the_type = g_enum_register_static (
			g_intern_static_string ("ESourceAuthenticationResult"),
			values);
		g_once_init_leave (&the_type__volatile, the_type);
	}
	return the_type__volatile;
}

GType
e_trust_prompt_response_get_type (void)
{
	static volatile gsize the_type__volatile = 0;

	if (g_once_init_enter (&the_type__volatile)) {
		static const GEnumValue values[] = {
			{ E_TRUST_PROMPT_RESPONSE_UNKNOWN,
			  "E_TRUST_PROMPT_RESPONSE_UNKNOWN",
			  "unknown" },
			{ E_TRUST_PROMPT_RESPONSE_REJECT,
			  "E_TRUST_PROMPT_RESPONSE_REJECT",
			  "reject" },
			{ E_TRUST_PROMPT_RESPONSE_ACCEPT,
			  "E_TRUST_PROMPT_RESPONSE_ACCEPT",
			  "accept" },
			{ E_TRUST_PROMPT_RESPONSE_ACCEPT_TEMPORARILY,
			  "E_TRUST_PROMPT_RESPONSE_ACCEPT_TEMPORARILY",
			  "accept-temporarily" },
			{ E_TRUST_PROMPT_RESPONSE_REJECT_TEMPORARILY,
			  "E_TRUST_PROMPT_RESPONSE_REJECT_TEMPORARILY",
			  "reject-temporarily" },
			{ 0, NULL, NULL }
		};
		GType the_type = g_enum_register_static (
			g_intern_static_string ("ETrustPromptResponse"),
			values);
		g_once_init_leave (&the_type__volatile, the_type);
	}
	return the_type__volatile;
}


/* Generated data ends here */

