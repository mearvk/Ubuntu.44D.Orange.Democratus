int foo ();
