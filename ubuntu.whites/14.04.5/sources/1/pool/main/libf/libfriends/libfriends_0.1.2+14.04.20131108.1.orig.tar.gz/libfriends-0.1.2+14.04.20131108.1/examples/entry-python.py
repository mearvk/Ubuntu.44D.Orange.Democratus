#!/usr/bin/python3
#
# Copyright (C) 2012 Canonical Ltd.
#
# This library is free software; you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License
# version 3.0 as published by the Free Software Foundation.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License version 3.0 for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library. If not, see
# <http://www.gnu.org/licenses/>.
#
# Authored by Ken VanDine <ken.vandine@canonical.com>
#

from gi.repository import Gtk
from gi.repository import FriendsGtk

class FriendsEntry:
    def __init__(self):
        window = Gtk.Window()
        window.set_title("Friends Poster")
        window.set_icon_name("gwibber")
        window.resize(400,150)
        entry = FriendsGtk.Entry()
        window.add(entry)
        window.show_all()
        window.present()
        window.connect("destroy", self.on_close)

    def on_close(self, w):
        Gtk.main_quit()

entry = FriendsEntry()
Gtk.main()
