/*
 * Copyright (C) 2010 Neil Jagdish Patel
 * Copyright (C) 2010 Canonical Ltd.
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License
 * version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3.0 for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library. If not, see
 * <http://www.gnu.org/licenses/>.
 *
 * Authored by Neil Jagdish Patel <neil.patel@canonical.com>
 * Authored by Ken VanDine <ken.vandine@canonical.com>
 */

public class Entry : Gtk.Window
{
  public Entry ()
  {
  }

  construct
  {
    set_name("Friends");
    set_title("Friends Poster (Vala)");
    set_default_size (400, 150);
    set_icon_name ("gwibber");

    var entry = new FriendsGtk.Entry ();
    this.add (entry);
    this.show_all ();
  }
}

static void on_close () 
{
  Gtk.main_quit();
}

public static void main (string[] args)
{
  Gtk.init (ref args);

  var w = new Entry ();

  w.show ();
  w.set_position (Gtk.WindowPosition.CENTER);
  w.destroy.connect(on_close);
  Gtk.main ();
}
