/*
 * Copyright (C) 2012 Canonical Ltd
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License
 * version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License version 3.0 for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library. If not, see
 * <http://www.gnu.org/licenses/>.
 *
 * Authored by Ken VanDine <ken@vandine.org>
 */

static int main (string[] args)
{
    Test.init (ref args);

    /* Friends.Dispatcher test */
    DispatcherSuite dispatcher_suite;
    dispatcher_suite = new DispatcherSuite ();

    /* Friends.Utils test */
    UtilsSuite utils_suite;
    utils_suite = new UtilsSuite ();

    Test.run ();
    return 0;
}

