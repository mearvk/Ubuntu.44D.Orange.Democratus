/* -*- Mode: vala; indent-tabs-mode: nil; c-basic-offset: 2; tab-width: 2 -*- *//*
 * Copyright (C) 2012 Canonical Ltd
 *
 * This program is free software: you can redistribute it and/or modify
 * idst under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Authored by Ken VanDine <ken.vandine@canonical.com>
 *
 */

[CCode (gir_namespace = "Friends", gir_version = "0.1")]
namespace Friends
{
  public const string foo;
}

[CCode (gir_namespace = "FriendsGtk", gir_version = "0.1")]
namespace FriendsGtk
{
}

[CCode (cprefix = "", lower_case_cprefix = "", cheader_filename = "config.h")]
namespace Config
{
  public const string DATADIR;
  public const string PKGDATADIR;
  public const string GETTEXT_PACKAGE;
  public const string LOCALE_DIR;
  public const string VERSION;
  public const string PACKAGE;
  public const string PREFIX;
}

namespace G
{
  [CCode (cname = "g_get_monotonic_time")]
  static int64 get_monotonic_time ();
}
