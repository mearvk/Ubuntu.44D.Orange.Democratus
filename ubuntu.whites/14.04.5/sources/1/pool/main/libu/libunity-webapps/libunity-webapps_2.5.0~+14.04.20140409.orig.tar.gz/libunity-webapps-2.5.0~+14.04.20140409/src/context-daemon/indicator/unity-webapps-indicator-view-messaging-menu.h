/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * unity-webapps-indicator-view-messaging-menu.c
 * Copyright (C) Canonical LTD 2011
 * 
 * Author: Robert Carr <racarr@canonical.com>
 *         Lars Uebernickel <lars.uebernickel@canonical.com>
 * 
 * unity-webapps is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * unity-webapps is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.";
 */


#ifndef __UNITY_WEBAPPS_INDICATOR_VIEW_MESSAGING_MENU_H
#define __UNITY_WEBAPPS_INDICATOR_VIEW_MESSAGING_MENU_H

#include "unity-webapps-indicator-view.h"


#define UNITY_WEBAPPS_TYPE_INDICATOR_VIEW_MESSAGING_MENU              (unity_webapps_indicator_view_messaging_menu_get_type())
#define UNITY_WEBAPPS_INDICATOR_VIEW_MESSAGING_MENU(obj)              (G_TYPE_CHECK_INSTANCE_CAST((obj), UNITY_WEBAPPS_TYPE_INDICATOR_VIEW_MESSAGING_MENU, UnityWebappsIndicatorViewMessagingMenu))
#define UNITY_WEBAPPS_INDICATOR_VIEW_MESSAGING_MENU_CLASS(klass)      (G_TYPE_CHECK_CLASS_CAST((klass), UNITY_WEBAPPS_TYPE_INDICATOR_VIEW_MESSAGING_MENU, UnityWebappsIndicatorViewMessagingMenuClass))
#define UNITY_WEBAPPS_IS_INDICATOR_VIEW_MESSAGING_MENU(obj)           (G_TYPE_CHECK_INSTANCE_TYPE((obj), UNITY_WEBAPPS_TYPE_INDICATOR_VIEW_MESSAGING_MENU))
#define UNITY_WEBAPPS_IS_INDICATOR_VIEW_MESSAGING_MENU_CLASS(klass)   (G_TYPE_CHECK_CLASS_TYPE ((klass), UNITY_WEBAPPS_TYPE_INDICATOR_VIEW_MESSAGING_MENU))
#define UNITY_WEBAPPS_INDICATOR_VIEW_MESSAGING_MENU_GET_CLASS(obj)    (G_TYPE_INSTANCE_GET_CLASS((obj), UNITY_WEBAPPS_TYPE_INDICATOR_VIEW_MESSAGING_MENU, UnityWebappsIndicatorViewMessagingMenuClass))

typedef struct _UnityWebappsIndicatorViewMessagingMenuPrivate UnityWebappsIndicatorViewMessagingMenuPrivate;

typedef struct _UnityWebappsIndicatorViewMessagingMenu UnityWebappsIndicatorViewMessagingMenu;


struct _UnityWebappsIndicatorViewMessagingMenu {
	UnityWebappsIndicatorView object;
	
	UnityWebappsIndicatorViewMessagingMenuPrivate *priv;
};

typedef struct _UnityWebappsIndicatorViewMessagingMenuClass UnityWebappsIndicatorViewMessagingMenuClass;

struct _UnityWebappsIndicatorViewMessagingMenuClass
{
	UnityWebappsIndicatorViewClass parent_class;
};

GType unity_webapps_indicator_view_messaging_menu_get_type (void) G_GNUC_CONST;

UnityWebappsIndicatorView *unity_webapps_indicator_view_messaging_menu_new (UnityWebappsIndicatorModel *model, const gchar *desktop_file);

#endif
