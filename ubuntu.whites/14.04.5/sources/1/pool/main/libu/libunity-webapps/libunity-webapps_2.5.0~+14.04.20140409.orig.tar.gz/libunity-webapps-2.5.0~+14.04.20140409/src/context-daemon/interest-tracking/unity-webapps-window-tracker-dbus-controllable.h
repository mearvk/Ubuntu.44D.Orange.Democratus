/*
 * unity-webapps-window-tracker-dbus-controllable.h
 * Copyright (C) Canonical LTD 2011
 *
 * unity-webapps is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * unity-webapps is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.";
 */

#ifndef __UNITY_WEBAPPS_WINDOW_TRACKER_DBUS_CONTROLLABLE_H
#define __UNITY_WEBAPPS_WINDOW_TRACKER_DBUS_CONTROLLABLE_H

#include "unity-webapps-window-tracker.h"

#define UNITY_WEBAPPS_TYPE_WINDOW_TRACKER_DBUS_CONTROLLABLE \
  (unity_webapps_window_tracker_dbus_controllable_get_type())

#define UNITY_WEBAPPS_WINDOW_TRACKER_DBUS_CONTROLLABLE(obj) \
  (G_TYPE_CHECK_INSTANCE_CAST((obj), UNITY_WEBAPPS_TYPE_WINDOW_TRACKER_DBUS_CONTROLLABLE, UnityWebappsWindowTrackerDbusControllable))

#define UNITY_WEBAPPS_WINDOW_TRACKER_DBUS_CONTROLLABLE_CLASS(klass) \
  (G_TYPE_CHECK_CLASS_CAST((klass), UNITY_WEBAPPS_TYPE_WINDOW_TRACKER_DBUS_CONTROLLABLE, UnityWebappsWindowTrackerDbusControllableClass))

#define UNITY_WEBAPPS_IS_WINDOW_TRACKER_DBUS_CONTROLLABLE(obj) \
  (G_TYPE_CHECK_INSTANCE_TYPE((obj), UNITY_WEBAPPS_TYPE_WINDOW_TRACKER_DBUS_CONTROLLABLE))

#define UNITY_WEBAPPS_IS_WINDOW_TRACKER_DBUS_CONTROLLABLE_CLASS(klass) \
  (G_TYPE_CHECK_CLASS_TYPE ((klass), UNITY_WEBAPPS_TYPE_WINDOW_TRACKER_DBUS_CONTROLLABLE))

#define UNITY_WEBAPPS_WINDOW_TRACKER_DBUS_CONTROLLABLE_GET_CLASS(obj) \
  (G_TYPE_INSTANCE_GET_CLASS((obj), UNITY_WEBAPPS_TYPE_WINDOW_TRACKER_DBUS_CONTROLLABLE, UnityWebappsWindowTrackerDbusControllableClass))

typedef struct _UnityWebappsWindowTrackerDbusControllablePrivate
  UnityWebappsWindowTrackerDbusControllablePrivate;

typedef struct _UnityWebappsWindowTrackerDbusControllable {
  UnityWebappsWindowTracker object;

  UnityWebappsWindowTrackerDbusControllablePrivate *priv;

} UnityWebappsWindowTrackerDbusControllable;

typedef struct _UnityWebappsWindowTrackerDbusControllableClass
{
  UnityWebappsWindowTrackerClass parent_class;

} UnityWebappsWindowTrackerDbusControllableClass;


GType unity_webapps_window_tracker_dbus_controllable_get_type (void) G_GNUC_CONST;

UnityWebappsWindowTrackerDbusControllable *
unity_webapps_window_tracker_dbus_controllable_new (GDBusConnection *connection);

#endif
