/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * unity-webapps-telepathy-presence-manager.h
 * Copyright (C) Canonical LTD 2011
 * 
 * Author: Robert Carr <racarr@canonical.com>
 * 
unity-webapps is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * unity-webapps is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.";
 */


#ifndef __UNITY_WEBAPPS_TELEPATHY_PRESENCE_MANAGER_H
#define __UNITY_WEBAPPS_TELEPATHY_PRESENCE_MANAGER_H


#define UNITY_WEBAPPS_TYPE_TELEPATHY_PRESENCE_MANAGER              (unity_webapps_telepathy_presence_manager_get_type())
#define UNITY_WEBAPPS_TELEPATHY_PRESENCE_MANAGER(obj)              (G_TYPE_CHECK_INSTANCE_CAST((obj), UNITY_WEBAPPS_TYPE_TELEPATHY_PRESENCE_MANAGER, UnityWebappsTelepathyPresenceManager))
#define UNITY_WEBAPPS_TELEPATHY_PRESENCE_MANAGER_CLASS(klass)      (G_TYPE_CHECK_CLASS_CAST((klass), UNITY_WEBAPPS_TYPE_TELEPATHY_PRESENCE_MANAGER, UnityWebappsTelepathyPresenceManagerClass))
#define UNITY_WEBAPPS_IS_TELEPATHY_PRESENCE_MANAGER(obj)           (G_TYPE_CHECK_INSTANCE_TYPE((obj), UNITY_WEBAPPS_TYPE_TELEPATHY_PRESENCE_MANAGER))
#define UNITY_WEBAPPS_IS_TELEPATHY_PRESENCE_MANAGER_CLASS(klass)   (G_TYPE_CHECK_CLASS_TYPE ((klass), UNITY_WEBAPPS_TYPE_TELEPATHY_PRESENCE_MANAGER))
#define UNITY_WEBAPPS_TELEPATHY_PRESENCE_MANAGER_GET_CLASS(obj)    (G_TYPE_INSTANCE_GET_CLASS((obj), UNITY_WEBAPPS_TYPE_TELEPATHY_PRESENCE_MANAGER, UnityWebappsTelepathyPresenceManagerClass))

#include "unity-webapps-presence-manager.h"

typedef struct _UnityWebappsTelepathyPresenceManagerPrivate UnityWebappsTelepathyPresenceManagerPrivate;

typedef struct _UnityWebappsTelepathyPresenceManager UnityWebappsTelepathyPresenceManager;


struct _UnityWebappsTelepathyPresenceManager {
	UnityWebappsPresenceManager manager;

	UnityWebappsTelepathyPresenceManagerPrivate *priv;
};

typedef struct _UnityWebappsTelepathyPresenceManagerClass UnityWebappsTelepathyPresenceManagerClass;

struct _UnityWebappsTelepathyPresenceManagerClass
{
	UnityWebappsPresenceManagerClass parent_class;
};

GType unity_webapps_telepathy_presence_manager_get_type (void) G_GNUC_CONST;

UnityWebappsPresenceManager *unity_webapps_telepathy_presence_manager_new ();

#endif
