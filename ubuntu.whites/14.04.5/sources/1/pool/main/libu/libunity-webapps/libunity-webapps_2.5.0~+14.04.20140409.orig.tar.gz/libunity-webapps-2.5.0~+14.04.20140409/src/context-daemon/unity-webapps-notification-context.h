/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * unity-webapps-notification-context.h
 * Copyright (C) Canonical LTD 2011
 * 
 * Author: Robert Carr <racarr@canonical.com>
 * 
unity-webapps is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * unity-webapps is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.";
 */

#ifndef __UNITY_WEBAPPS_NOTIFICATION_CONTEXT_H
#define __UNITY_WEBAPPS_NOTIFICATION_CONTEXT_H

typedef struct _UnityWebappsNotificationContext UnityWebappsNotificationContext;

#include "unity-webapps-context-daemon.h"
#include "../unity-webapps-gen-notification.h"

struct _UnityWebappsNotificationContext {
	GDBusConnection *connection;
	
	UnityWebappsGenNotification *notification_service_interface;
	
	gchar *icon_file_name;
};

UnityWebappsNotificationContext *unity_webapps_notification_context_new (GDBusConnection *connection, const gchar *name, const gchar *icon_file_name);
void unity_webapps_notification_context_free (UnityWebappsNotificationContext *notification_context);

#endif
