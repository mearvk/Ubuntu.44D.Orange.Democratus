/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * unity-webapps-dirs.h
 * Copyright (C) Canonical LTD 2011
 * 
 * Author: Robert Carr <racarr@canonical.com>
 * 
unity-webapps is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * unity-webapps is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.";
 */

#ifndef __UNITY_WEBAPPS_DIRS_H
#define __UNITY_WEBAPPS_DIRS_H

const gchar *unity_webapps_dirs_get_user_dir ();
const gchar *unity_webapps_dirs_get_icon_dir ();
const gchar *unity_webapps_dirs_get_icon_theme_dir ();
const gchar *unity_webapps_dirs_get_application_dir ();
const gchar *unity_webapps_dirs_get_resource_dir ();


#endif
