/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * unity-webapps-apt-package-mechanism.h
 * Copyright (C) Canonical LTD 2011
 * 
 * Author: Robert Carr <racarr@canonical.com>
 * 
unity-webapps is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * unity-webapps is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.";
 */


#ifndef __UNITY_WEBAPPS_APT_PACKAGE_MECHANISM_H
#define __UNITY_WEBAPPS_APT_PACKAGE_MECHANISM_H


#define UNITY_WEBAPPS_TYPE_APT_PACKAGE_MECHANISM              (unity_webapps_apt_package_mechanism_get_type())
#define UNITY_WEBAPPS_APT_PACKAGE_MECHANISM(obj)              (G_TYPE_CHECK_INSTANCE_CAST((obj), UNITY_WEBAPPS_TYPE_APT_PACKAGE_MECHANISM, UnityWebappsAptPackageMechanism))
#define UNITY_WEBAPPS_APT_PACKAGE_MECHANISM_CLASS(klass)      (G_TYPE_CHECK_CLASS_CAST((klass), UNITY_WEBAPPS_TYPE_APT_PACKAGE_MECHANISM, UnityWebappsAptPackageMechanismClass))
#define UNITY_WEBAPPS_IS_APT_PACKAGE_MECHANISM(obj)           (G_TYPE_CHECK_INSTANCE_TYPE((obj), UNITY_WEBAPPS_TYPE_APT_PACKAGE_MECHANISM))
#define UNITY_WEBAPPS_IS_APT_PACKAGE_MECHANISM_CLASS(klass)   (G_TYPE_CHECK_CLASS_TYPE ((klass), UNITY_WEBAPPS_TYPE_APT_PACKAGE_MECHANISM))
#define UNITY_WEBAPPS_APT_PACKAGE_MECHANISM_GET_CLASS(obj)    (G_TYPE_INSTANCE_GET_CLASS((obj), UNITY_WEBAPPS_TYPE_APT_PACKAGE_MECHANISM, UnityWebappsAptPackageMechanismClass))

#include "unity-webapps-package-mechanism.h"

typedef struct _UnityWebappsAptPackageMechanismPrivate UnityWebappsAptPackageMechanismPrivate;

typedef struct _UnityWebappsAptPackageMechanism UnityWebappsAptPackageMechanism;


struct _UnityWebappsAptPackageMechanism {
	UnityWebappsPackageMechanism manager;

	UnityWebappsAptPackageMechanismPrivate *priv;
};

typedef struct _UnityWebappsAptPackageMechanismClass UnityWebappsAptPackageMechanismClass;

struct _UnityWebappsAptPackageMechanismClass
{
	UnityWebappsPackageMechanismClass parent_class;
};

GType unity_webapps_apt_package_mechanism_get_type (void) G_GNUC_CONST;

UnityWebappsPackageMechanism *unity_webapps_apt_package_mechanism_new ();

#endif
