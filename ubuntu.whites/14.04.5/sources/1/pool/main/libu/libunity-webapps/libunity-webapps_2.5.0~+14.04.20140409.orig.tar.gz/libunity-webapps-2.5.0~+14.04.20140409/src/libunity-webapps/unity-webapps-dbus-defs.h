/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * unity-webapps-dbus-defs.h
 * Copyright (C) Canonical LTD 2011
 * 
 * Author: Robert Carr <racarr@canonical.com>
 * 
unity-webapps is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * unity-webapps is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.";
 */

#ifndef __UNITY_WEBAPPS_DBUS_DEFS_H
#define __UNITY_WEBAPPS_DBUS_DEFS_H

#define UNITY_WEBAPPS_CONTEXT_IFACE "com.canonical.Unity.Webapps.Context"
#define UNITY_WEBAPPS_CONTEXT_PATH "/com/canonical/Unity/Webapps/Context"
#define UNITY_WEBAPPS_SERVICE_PATH  "/com/canonical/Unity/Webapps/Service"
#define UNITY_WEBAPPS_SERVICE_IFACE "com.canonical.Unity.Webapps.Service"
#define UNITY_WEBAPPS_SERVICE_NAME "com.canonical.Unity.Webapps.Service"
#define UNITY_WEBAPPS_NOTIFICATION_IFACE "com.canonical.Unity.Webapps.Notification"
#define UNITY_WEBAPPS_NOTIFICATION_PATH "/com/canonical/Unity/Webapps/Context/Notification"
#define UNITY_WEBAPPS_INDICATOR_IFACE "com.canonical.Unity.Webapps.Indicator"
#define UNITY_WEBAPPS_INDICATOR_PATH "/com/canonical/Unity/Webapps/Context/Indicator"
#define UNITY_WEBAPPS_MUSIC_PLAYER_IFACE "com.canonical.Unity.Webapps.MusicPlayer"
#define UNITY_WEBAPPS_MUSIC_PLAYER_PATH "/com/canonical/Unity/Webapps/Context/MusicPlayer"
#define UNITY_WEBAPPS_LAUNCHER_IFACE "com.canonical.Unity.Webapps.Launcher"
#define UNITY_WEBAPPS_LAUNCHER_PATH "/com/canonical/Unity/Webapps/Launcher"

#endif
