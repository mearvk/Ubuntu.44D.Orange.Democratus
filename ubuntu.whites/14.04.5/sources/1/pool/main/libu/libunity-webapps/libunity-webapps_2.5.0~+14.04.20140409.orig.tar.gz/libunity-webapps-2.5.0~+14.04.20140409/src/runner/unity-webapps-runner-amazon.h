#ifndef __UNITY_WEBAPPS_RUNNER_AMAZON_H
#define __UNITY_WEBAPPS_RUNNER_AMAZON_H
#include <glib.h>
gchar *unity_webapps_runner_amazon_get_country (void);
const gchar *unity_webapps_runner_amazon_get_homepage_for_country (const gchar *country);
#endif
