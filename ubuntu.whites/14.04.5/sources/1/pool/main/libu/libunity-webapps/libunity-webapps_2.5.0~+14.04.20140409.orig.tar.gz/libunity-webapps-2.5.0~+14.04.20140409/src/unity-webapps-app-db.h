/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * unity-webapps-app-db.h
 * Copyright (C) Canonical LTD 2012
 * 
 * Author: Robert Carr <racarr@canonical.com>
 * 
unity-webapps is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * unity-webapps is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.";
 */


#ifndef __UNITY_WEBAPPS_APP_DB_H
#define __UNITY_WEBAPPS_APP_DB_H

gboolean unity_webapps_app_db_update_homepage (const gchar *name, const gchar *domain, const gchar *homepage);
gchar *unity_webapps_app_db_get_homepage (const gchar *name, const gchar *domain);

gboolean unity_webapps_app_db_open ();

gboolean unity_webapps_app_db_add_action (const gchar *name, const gchar *domain, const gchar *label, const gchar *page);
gboolean unity_webapps_app_db_clear_actions (const gchar *name, const gchar *domain);
gboolean unity_webapps_app_db_get_actions (const gchar *name, const gchar *domain, gchar ***labels, gchar ***pages);

#endif
