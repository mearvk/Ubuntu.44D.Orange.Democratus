/*
 * unity-webapps-wire-version.h
 * Copyright (C) Canonical LTD 2012
 *
 * Author: Robert Carr <racarr@canonical.com>
 *
 unity-webapps is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * unity-webapps is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.";
 */

#ifndef _UNITY_WEBAPPS_WIRE_VERSION_H
#define _UNITY_WEBAPPS_WIRE_VERSION_H

#define UNITY_WEBAPPS_WIRE_PROTOCOL_VERSION "501712"

#endif
