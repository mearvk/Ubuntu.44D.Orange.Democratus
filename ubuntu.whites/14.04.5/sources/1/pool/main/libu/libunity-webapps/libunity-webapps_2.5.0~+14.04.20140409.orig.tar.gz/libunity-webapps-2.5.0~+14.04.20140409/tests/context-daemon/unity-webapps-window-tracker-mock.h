/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * unity-webapps-window-tracker.h
 * Copyright (C) Canonical LTD 2011
 * 
 * Author: Robert Carr <racarr@canonical.com>
 * 
unity-webapps is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * unity-webapps is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.";
 */


#ifndef __UNITY_WEBAPPS_WINDOW_TRACKER_MOCK_H
#define __UNITY_WEBAPPS_WINDOW_TRACKER_MOCK_H

#include "unity-webapps-window-tracker.h"


#define UNITY_WEBAPPS_TYPE_WINDOW_TRACKER_MOCK              (unity_webapps_window_tracker_mock_get_type())
#define UNITY_WEBAPPS_WINDOW_TRACKER_MOCK(obj)              (G_TYPE_CHECK_INSTANCE_CAST((obj), UNITY_WEBAPPS_TYPE_WINDOW_TRACKER_MOCK, UnityWebappsWindowTrackerMock))
#define UNITY_WEBAPPS_WINDOW_TRACKER_MOCK_CLASS(klass)      (G_TYPE_CHECK_CLASS_CAST((klass), UNITY_WEBAPPS_TYPE_WINDOW_TRACKER_MOCK, UnityWebappsWindowTrackerMockClass))
#define UNITY_WEBAPPS_IS_WINDOW_TRACKER_MOCK(obj)           (G_TYPE_CHECK_INSTANCE_TYPE((obj), UNITY_WEBAPPS_TYPE_WINDOW_TRACKER_MOCK))
#define UNITY_WEBAPPS_IS_WINDOW_TRACKER_MOCK_CLASS(klass)   (G_TYPE_CHECK_CLASS_TYPE ((klass), UNITY_WEBAPPS_TYPE_WINDOW_TRACKER_MOCK))
#define UNITY_WEBAPPS_WINDOW_TRACKER_MOCK_GET_CLASS(obj)    (G_TYPE_INSTANCE_GET_CLASS((obj), UNITY_WEBAPPS_TYPE_WINDOW_TRACKER_MOCK, UnityWebappsWindowTrackerMockClass))

typedef struct _UnityWebappsWindowTrackerMockPrivate UnityWebappsWindowTrackerMockPrivate;

typedef struct _UnityWebappsWindowTrackerMock UnityWebappsWindowTrackerMock;


struct _UnityWebappsWindowTrackerMock {
	UnityWebappsWindowTracker object;

	UnityWebappsWindowTrackerMockPrivate *priv;
};

typedef struct _UnityWebappsWindowTrackerMockClass UnityWebappsWindowTrackerMockClass;

struct _UnityWebappsWindowTrackerMockClass
{
	UnityWebappsWindowTrackerClass parent_class;
};

GType unity_webapps_window_tracker_mock_get_type (void) G_GNUC_CONST;

UnityWebappsWindowTrackerMock *unity_webapps_window_tracker_mock_new ();

void unity_webapps_window_tracker_mock_set_active_window (UnityWebappsWindowTrackerMock *tracker,
														  guint64 window_id);

#endif
