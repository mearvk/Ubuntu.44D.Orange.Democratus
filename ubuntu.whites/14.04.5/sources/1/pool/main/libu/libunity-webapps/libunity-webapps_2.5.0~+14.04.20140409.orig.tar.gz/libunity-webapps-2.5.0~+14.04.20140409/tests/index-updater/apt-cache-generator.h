#ifndef __APT_CACHE_GENERATOR_H
#define __APT_CACHE_GENERATOR_H

#include <glib.h>

typedef struct _AptCacheGenerator AptCacheGenerator;

AptCacheGenerator *apt_cache_generator_new ();
void apt_cache_generator_free (AptCacheGenerator *generator);

gchar *apt_cache_generator_get_available (AptCacheGenerator *generator);
void apt_cache_generator_add_application (AptCacheGenerator *generator, const gchar *name);

void apt_cache_generator_add_webapp (AptCacheGenerator *generator, const gchar *name, const gchar *webapp_name, const gchar *webapp_domain, ... /* Includes */);

#endif
