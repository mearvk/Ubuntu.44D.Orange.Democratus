#include <gio/gio.h>

#include "unity-webapps-application-collector.h"
#include "unity-webapps-local-url-index.h"
#include "unity-webapps-application-repository.h"
#include "unity-webapps-debug.h"


typedef struct _RepositoryTestFixture {
  UnityWebappsApplicationRepository *repository;
} RepositoryTestFixture;


static void
setup_fixture_simple (RepositoryTestFixture *fixture, gconstpointer user_data)
{
	fixture->repository = unity_webapps_application_repository_new_default();
	//	unity_webapps_application_repository_prepare (fixture->repository);
}


static void
teardown_fixture_simple (RepositoryTestFixture *fixture, gconstpointer user_data)
{
  g_object_unref (G_OBJECT (fixture->repository));
}

static void
test_resolve_simple_collection_1 (RepositoryTestFixture *fixture, gconstpointer user_data)
{
}

int 
main (int argc, char **argv)
{
  g_type_init ();
  g_test_init (&argc, &argv, NULL);
  
  unity_webapps_debug_initialize_flags ();
  
  g_test_add("/Applications/Repository/Resolvve", RepositoryTestFixture, NULL,
	     setup_fixture_simple, test_resolve_simple_collection_1, teardown_fixture_simple);
  
  //  return g_test_run ();
  return 0;
}
