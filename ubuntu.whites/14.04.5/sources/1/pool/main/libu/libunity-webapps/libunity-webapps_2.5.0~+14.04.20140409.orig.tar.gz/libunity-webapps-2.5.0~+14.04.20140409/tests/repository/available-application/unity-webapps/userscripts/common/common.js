var f = function (a) {
  console.log('common function');
  return a;
};

