#include <stdlib.h>
#include <stdio.h>

#include "unity-webapps-service.h"
#include "unity-webapps-context.h"

#include "uwa-test-client.h"

#define ICON_URL "http://www.ubuntu.com/sites/www.ubuntu.com/files/active/02_ubuntu/U_homepage/picto-desktop.png"

static GMainLoop *mainloop = NULL;

guint count = 0;

static void
on_action_callback (UnityWebappsContext *context, gpointer user_data)
{
  printf("Callback! \n");
  count ++;
  
  if (count == 2)
    {
      uwa_emit_test_finished ();
    }
}

static void
context_ready (UnityWebappsContext *context, gpointer user_data)
{
  unity_webapps_indicator_add_action (context, "Callback Action 1",
				      on_action_callback, NULL);
  unity_webapps_indicator_add_action (context, "Callback Action 2",
				      on_action_callback, NULL);
  
  printf("Activate Callback Action 1 and 2 from your messaging indicator\n");
  
}

gint
main (gint argc, gchar **argv)
{
  UnityWebappsService *service;
  
  g_type_init ();
  
  service = unity_webapps_service_new ();
  
  unity_webapps_context_new (service, "Test", "test.ts", ICON_URL, NULL, context_ready, NULL);
  
  mainloop = g_main_loop_new (NULL, FALSE);
  
  g_main_loop_run (mainloop);
  
  return 0;  
}
