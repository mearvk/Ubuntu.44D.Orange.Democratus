#include <stdlib.h>
#include <stdio.h>

#include "unity-webapps-service.h"
#include "unity-webapps-context.h"

#include "uwa-test-client.h"

#define ICON_URL "http://www.ubuntu.com/sites/www.ubuntu.com/files/active/02_ubuntu/U_homepage/picto-desktop.png"

static GMainLoop *mainloop = NULL;

static void
context_ready (UnityWebappsContext *context, gpointer user_data)
{
  unity_webapps_indicator_show_indicator (context, "Indicator Themed Icon Test");
  unity_webapps_indicator_set_property_icon(context, "Indicator Themed Icon Test",
					      "icon", "icon://user-trash");
  
  unity_webapps_indicator_show_indicator (context, "Indicator Invalid Themed Icon Test");

  unity_webapps_indicator_set_property_icon (context, "Indicator Invalid Themed Icon Test",
					     "icon", "icon://Whatwhat");
  
  printf("Set indicator property");

  uwa_emit_test_finished ();
}

gint
main (gint argc, gchar **argv)
{
  UnityWebappsService *service;
  
  g_type_init ();
  
  service = unity_webapps_service_new ();
  
  unity_webapps_context_new (service, "Test", "test.ts", ICON_URL, NULL, context_ready, NULL);
  
  mainloop = g_main_loop_new (NULL, FALSE);
  
  g_main_loop_run (mainloop);
  
  return 0;  
}
