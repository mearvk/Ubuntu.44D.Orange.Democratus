#!/usr/bin/env python

import sys, os


if len(sys.argv) != 3:
    print("Usage: ./make-test.py module name")
    exit()

module = sys.argv[1]
name = sys.argv[2]

os.system ("cp test-template.c %s/%s.c" % (module, name))

editor = os.getenv("EDITOR")

os.system("%s %s/%s.c" % (editor, module, name))
