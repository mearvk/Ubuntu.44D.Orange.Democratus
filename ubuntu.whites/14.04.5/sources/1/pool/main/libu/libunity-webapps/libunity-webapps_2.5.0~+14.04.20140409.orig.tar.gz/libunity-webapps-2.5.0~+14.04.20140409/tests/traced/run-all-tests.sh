#!/bin/bash
set -e

if [ -z $UNITY_WEBAPPS_DAEMON_EXEC_DIR ]; then
    export UNITY_WEBAPPS_DAEMON_EXEC_DIR="`pwd`/../../src/context-daemon/"
fi

for test in $(ls */*.trace | grep -v interactive)
do
    echo `echo $test | sed 's/\.trace//'`
    ./run-test.sh `echo $test | sed 's/\.trace//'`
done
