#!/bin/bash
set -e 

if [ -z $UNITY_WEBAPPS_DAEMON_EXEC_DIR ]; then
    export UNITY_WEBAPPS_DAEMON_EXEC_DIR="`pwd`/../../src/context-daemon/"
fi

if [ -d test-output-files ]; then
    rm -fR test-output-files
fi

mkdir test-output-files

export UNITY_WEBAPPS_CONTEXT_USER_DIR="test-output-files"
export UNITY_WEBAPPS_CONTEXT_ICON_DIR="test-output-files"
export UNITY_WEBAPPS_CONTEXT_ICON_THEME_DIR="test-output-files"
export UNITY_WEBAPPS_CONTEXT_ICON_APPLICATION_DIR="test-output-files"
export UNITY_WEBAPPS_CONTEXT_ICON_RESOURCE_DIR="test-output-files"
test-runner/test-runner -n $1 $2 $3
rm -fR test-output-files
