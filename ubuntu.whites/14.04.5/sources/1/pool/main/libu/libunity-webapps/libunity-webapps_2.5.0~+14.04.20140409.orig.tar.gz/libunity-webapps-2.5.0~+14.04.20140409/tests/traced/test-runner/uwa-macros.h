/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * uwa-macros.h
 * Copyright (C) Canonical LTD 2011
 * 
 * Author: Robert Carr <racarr@canonical.com>
 * 
unity-webapps is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * unity-webapps is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.";
 */

#ifndef __UWA_MACROS_H
#define __UWA_MACROS_H

#include <glib.h>

#define MACRO_STANDARD_SERVICE_CHECK "Exported Service interface\n"\
  "Handling GetContext\n"\
  "Spawning context\n"\
  "Handling ContextReady\n"


struct _UwaTraceMacro {
	gchar *identifier;
	gchar *substitution;
};

struct _UwaTraceMacro trace_macros[] = 
	{
	  { "STANDARD_SERVICE_CHECK", MACRO_STANDARD_SERVICE_CHECK}
	};

#endif
