#include <stdlib.h>

#include "unity-webapps-service.h"
#include "unity-webapps-context.h"

#define ICON_URL "http://www.ubuntu.com/sites/www.ubuntu.com/files/active/02_ubuntu/U_homepage/picto-desktop.png"

static GMainLoop *mainloop = NULL;

static void
context_ready (UnityWebappsContext *context)
{
  g_main_loop_quit (mainloop);
}

gint
main (gint argc, gchar **argv)
{
  UnityWebappsService *service;
  UnityWebappsContext *context;
  
  g_thread_init (NULL);
  g_type_init ();
  
  service = unity_webapps_service_new ();
  
  unity_webapps_context_new (service, "Test", "test.ts", ICON_URL, context_ready);
  
  mainloop = g_main_loop_new (NULL, FALSE);
  
  g_main_loop_run (mainloop);
  
  return 0;  
}
