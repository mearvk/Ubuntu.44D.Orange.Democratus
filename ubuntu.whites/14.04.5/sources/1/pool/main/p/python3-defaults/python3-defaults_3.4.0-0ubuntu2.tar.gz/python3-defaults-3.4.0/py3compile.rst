============
 py3compile
============

----------------------------------
byte compile Python 3 source files
----------------------------------

:Manual section: 1
:Author: Piotr Ożarowski, 2012-2013

SYNOPSIS
========
  py3compile [-V [X.Y][-][A.B]] DIR_OR_FILE [-X REGEXPR]

  pycompile -p PACKAGE

DESCRIPTION
===========
Wrapper around Python standard library's py_compile module to byte-compile
Python 3 files.

OPTIONS
=======
--version	show program's version number and exit

-h, --help	show this help message and exit

-f, --force	force rebuild of byte-code files even if timestamps are up-to-date

-O		byte-compile to .pyo files

-q, --quiet	be quiet

-v, --verbose	turn verbose mode on

-p PACKAGE, --package=PACKAGE	specify Debian package name whose files should
  be bytecompiled

-V VRANGE	force private modules to be bytecompiled with Python 3
  version from given range, regardless of the default Python 3 version in the
  system. If there are no other options, bytecompile all public modules for
  installed Python 3 versions that match given range.
  VERSION_RANGE examples:

   * ``3.1``	version 3.1 only,
   * ``3.1-``	version 3.1 or newer,
   * ``3.1-3.3``	version 3.1 or 3.2,
   * ``-4.0``	all supported 3.X versions

-X REGEXPR, --exclude=REGEXPR	exclude items that match given REGEXPR. You may
  use this option multiple times to build up a list of things to exclude
