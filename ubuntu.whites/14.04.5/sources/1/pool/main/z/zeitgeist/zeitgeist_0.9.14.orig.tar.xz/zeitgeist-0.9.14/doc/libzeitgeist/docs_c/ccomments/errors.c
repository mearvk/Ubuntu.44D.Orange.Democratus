/**
 * ZeitgeistEngineError:
 */
