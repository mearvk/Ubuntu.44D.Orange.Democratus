#!/bin/sh -e

TAR=../antlr3_$2.orig.tar.gz
DIR=antlr-$2
ORIG_TAR=$3

tar -x -z -v -f $ORIG_TAR

find $DIR -name ".*" -exec rm '{}' \;
rm -f $TAR
tar -c -z -f $TAR $DIR
rm -rf $DIR

# move to directory 'tarballs'
if [ -r .svn/deb-layout ]; then
  . .svn/deb-layout
  mv $TAR $origDir
  echo "moved $TAR to $origDir"
fi

