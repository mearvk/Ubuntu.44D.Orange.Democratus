#!/bin/sh -e

# called by uscan with '--upstream-version' <version> <file>
DEBIAN_VERSION=$2
DIR=dom4j-$DEBIAN_VERSION
TAR=../dom4j_$DEBIAN_VERSION+dfsg.3.orig.tar.gz

# clean up the upstream tarball
tar zxf $3
rm -f $3
GZIP=--best tar czf $TAR -X debian/orig-tar.exclude $DIR
rm -rf $DIR

exit 0
