/*
 * Copyright 2001-2009 OFFIS, Tammo Freese
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.easymock.internal;

public interface IMocksBehavior extends ILegacyMatcherMethods {

    // record
    void addExpected(ExpectedInvocation expected, Result result, Range count);

    void addStub(ExpectedInvocation expected, Result result);

    void checkOrder(boolean value);

    void makeThreadSafe(boolean isThreadSafe);
    
    void shouldBeUsedInOneThread(boolean shouldBeUsedInOneThread);
    
    // replay
    Result addActual(Invocation invocation);    
    
    boolean isThreadSafe();

    void checkThreadSafety();

    // verify
    void verify();
}
