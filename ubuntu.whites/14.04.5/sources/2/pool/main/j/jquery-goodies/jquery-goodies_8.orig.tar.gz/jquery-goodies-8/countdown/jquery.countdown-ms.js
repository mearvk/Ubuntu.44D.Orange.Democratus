/* http://keith-wood.name/countdown.html
   Malay initialisation for the jQuery countdown extension
   Written by Jason Ong (jason{at}portalgroove.com) May 2010. */
(function($) {
	$.countdown.regional['ms'] = {
		labels: ['Tahun', 'Bulan', 'Minggu', 'Hari', 'Jam', 'Minit', 'Saat'],
		labels1: ['Tahun', 'Bulan', 'Minggu', 'Hari', 'Jam', 'Minit', 'Saat'],
		compactLabels: ['t', 'b', 'm', 'h'],
		whichLabels: null,
		timeSeparator: ':', isRTL: false};
	$.countdown.setDefaults($.countdown.regional['ms']);
})(jQuery);
