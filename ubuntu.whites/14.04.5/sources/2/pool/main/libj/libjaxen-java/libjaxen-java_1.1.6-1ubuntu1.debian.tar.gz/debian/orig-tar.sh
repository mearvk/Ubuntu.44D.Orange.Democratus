#!/bin/sh -e

VERSION=$2
TAR=../libjaxen-java_$VERSION.orig.tar.gz
DIR=jaxen-$VERSION
TAG=V_$(echo $VERSION | sed 's/\./_/g')_Final

svn export http://svn.codehaus.org/jaxen/tags/$TAG/jaxen $DIR
rm -f $DIR/project.* $DIR/maven.xml $DIR/.cvsignore
tar -c -z -f $TAR $DIR
rm -rf $DIR


# move to directory 'tarballs'
if [ -r .svn/deb-layout ]; then
  . .svn/deb-layout
  mv $TAR $origDir
  echo "moved $TAR to $origDir"
fi
