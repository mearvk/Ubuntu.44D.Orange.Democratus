#!/bin/sh

# This script makes anacron jobs start/stop when a machine gets or loses AC
# power.

case $1 in
    false)
	/usr/sbin/invoke-rc.d anacron start >/dev/null   
	;;
    true)
	/usr/sbin/invoke-rc.d anacron stop >/dev/null   
	;;
esac
