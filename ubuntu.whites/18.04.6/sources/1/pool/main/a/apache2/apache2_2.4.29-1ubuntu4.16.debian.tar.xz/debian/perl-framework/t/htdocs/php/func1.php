<?php echo strlen("abcdef")?>
