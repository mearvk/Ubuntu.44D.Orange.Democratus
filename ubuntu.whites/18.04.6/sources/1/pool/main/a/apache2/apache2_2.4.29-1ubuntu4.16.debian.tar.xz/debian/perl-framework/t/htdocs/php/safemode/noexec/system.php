<?php system("/bin/ls /"); ?>
