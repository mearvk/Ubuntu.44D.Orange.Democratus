try:
    import barbican
except Importerror, e:
    print "ERROR IMPORTING MODULE"
