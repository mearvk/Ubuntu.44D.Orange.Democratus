# Dependencies for screen.$O:
screen.$O: $(SRC_DIR)/screen.c
screen.$O: $(SRC_TOP)Headers/prologue.h
screen.$O: $(BLD_TOP)config.h
screen.$O: $(BLD_TOP)forbuild.h
screen.$O: $(SRC_TOP)Headers/driver.h
screen.$O: $(SRC_TOP)Headers/ktb_types.h
screen.$O: $(SRC_TOP)Headers/scr_base.h
screen.$O: $(SRC_TOP)Headers/scr_driver.h
screen.$O: $(SRC_TOP)Headers/scr_gpm.h
screen.$O: $(SRC_TOP)Headers/scr_main.h
screen.$O: $(SRC_TOP)Headers/scr_real.h
screen.$O: $(SRC_TOP)Headers/scr_types.h
screen.$O: $(SRC_TOP)Headers/scr_utils.h

