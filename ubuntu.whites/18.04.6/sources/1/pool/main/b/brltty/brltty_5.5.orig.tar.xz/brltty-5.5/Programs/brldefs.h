/*
 * BRLTTY - A background process providing access to the console screen (when in
 *          text mode) for a blind person using a refreshable braille display.
 *
 * Copyright (C) 1995-2017 by The BRLTTY Developers.
 *
 * BRLTTY comes with ABSOLUTELY NO WARRANTY.
 *
 * This is free software, placed under the terms of the
 * GNU Lesser General Public License, as published by the Free Software
 * Foundation; either version 2.1 of the License, or (at your option) any
 * later version. Please see the file LICENSE-LGPL for details.
 *
 * Web Page: http://brltty.com/
 *
 * This software is maintained by Dave Mielke <dave@mielke.cc>.
 */

#ifndef BRLAPI_INCLUDED_BRLTTY_BRLDEFS
#define BRLAPI_INCLUDED_BRLTTY_BRLDEFS

#warning include <brlapi_brldefs.h> instead of <brltty/brldefs.h> (see man brlapi_deprecated)
#include <brlapi_brldefs.h>

#endif /* BRLAPI_INCLUDED_BRLTTY_BRLDEFS */
