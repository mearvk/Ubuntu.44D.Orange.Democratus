#!/usr/bin/env python
import os
import re
from subprocess import call, PIPE
import sys

sys.path.insert(0, '/home/abentley/bzrplugins')
sys.path.insert(0, os.path.dirname(os.path.realpath('/home/abentley/bin/bzr')))
import bzrtools
print "bzrtools version: %s" % bzrtools.__version__
def minigrep(pattern, filename):
    setup = open(filename, 'rb')
    for line in setup:
        match = re.search(pattern, line)
        if match is not None:
            return match

newsmatch = minigrep('RELEASE: bzrtools %s' % (bzrtools.__version__), 'NEWS')
if newsmatch is None:
    print "NEWS entry missing"
    sys.exit(1)
else:
    print "NEWS entry found"
if call(['bzr', 'diff'], stdout=PIPE) != 0:
    print "Please commit before releasing"
    sys.exit(1)
