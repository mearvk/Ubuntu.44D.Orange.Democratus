#!/usr/bin/env python
from distutils.core import setup
import version
if __name__ == '__main__':
    setup(name="BzrTools",
          version=version.__version__,
          description="Handy utilities for working with Bazaar (bzr).",
          author="Aaron Bentley",
          author_email="aaron@aaronbentley.com",
          license = "GNU GPL v2",
          url="http://bazaar-vcs.org/BzrTools",
          packages=['bzrlib.plugins.bzrtools',
                    'bzrlib.plugins.bzrtools.tests'],
          package_dir={'bzrlib.plugins.bzrtools': '.', })
