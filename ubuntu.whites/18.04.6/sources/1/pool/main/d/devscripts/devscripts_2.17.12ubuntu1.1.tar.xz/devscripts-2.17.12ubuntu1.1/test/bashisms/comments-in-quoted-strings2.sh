#!/bin/sh

echo "
\" # " # foo() {} '
