# initial version automatically generated from ./release-process/scripts/mk_exim_release
EXIM_RELEASE_VERSION=4.90
EXIM_VARIANT_VERSION=_1
EXIM_COMPILE_NUMBER=0
