CHANNEL			= release
MOZ_ENABLE_BREAKPAD 	= 1
MOZ_OFFICIAL_BUILD = 1
MOZ_ENABLE_TELEMETRY = 1

MOZILLA_REPO = https://hg.mozilla.org/releases/mozilla-release
L10N_REPO = https://hg.mozilla.org/l10n-central
