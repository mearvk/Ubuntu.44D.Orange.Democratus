.globl foo
foo:
ret
