        .globl  bar
bar:
        retq
