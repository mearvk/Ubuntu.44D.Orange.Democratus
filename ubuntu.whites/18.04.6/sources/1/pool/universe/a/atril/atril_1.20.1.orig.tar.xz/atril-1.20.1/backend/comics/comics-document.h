/* comics-document.h: Implementation of EvDocument for comic book archives
 * Copyright (C) 2005, Teemu Tervo <teemu.tervo@gmx.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __COMICS_DOCUMENT_H__
#define __COMICS_DOCUMENT_H__

#include "ev-document.h"

G_BEGIN_DECLS

#define COMICS_TYPE_DOCUMENT    (comics_document_get_type ())
#define COMICS_DOCUMENT(obj)    (G_TYPE_CHECK_INSTANCE_CAST ((obj), COMICS_TYPE_DOCUMENT, ComicsDocument))
#define COMICS_IS_DOCUMENT(obj) (G_TYPE_CHECK_INSTANCE_TYPE ((obj), COMICS_TYPE_DOCUMENT))

typedef struct _ComicsDocument ComicsDocument;

GType                 comics_document_get_type (void) G_GNUC_CONST;

G_MODULE_EXPORT GType register_atril_backend  (GTypeModule *module);
     
G_END_DECLS

#endif /* __COMICS_DOCUMENT_H__ */
