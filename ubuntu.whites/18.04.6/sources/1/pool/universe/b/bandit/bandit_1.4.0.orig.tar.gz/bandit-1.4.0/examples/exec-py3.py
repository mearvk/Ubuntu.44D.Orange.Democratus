exec("do evil")
