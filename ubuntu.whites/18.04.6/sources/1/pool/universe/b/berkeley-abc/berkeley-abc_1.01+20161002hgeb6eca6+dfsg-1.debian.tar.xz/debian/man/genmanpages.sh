#!/bin/bash


txt2man -t BERKELEY-ABC          -s 1 berkeley-abc.txt           > berkeley-abc.1
