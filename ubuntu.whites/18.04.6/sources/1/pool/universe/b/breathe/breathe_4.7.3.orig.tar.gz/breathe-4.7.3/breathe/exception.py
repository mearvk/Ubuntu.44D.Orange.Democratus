
class BreatheError(Exception):
    pass
