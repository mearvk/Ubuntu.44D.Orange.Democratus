Caja Admin
==============

This is a port/fork of https://github.com/brunonova/nautilus-admin for the Caja file manager

[![GPLv3 license](http://img.shields.io/badge/license-GPLv3-brightgreen.svg)](http://www.gnu.org/licenses/gpl-3.0.html)

Caja Admin is a simple Python extension for the Caja file manager that
adds some administrative actions to the right-click menu:

*   **Open as Administrator**: opens a folder in a new Caja window running
    with administrator (root) privileges.
*   **Edit as Administrator**: opens a file in a Pluma window running with
    administrator (root) privileges.
*   **Run as Administrator**: runs an executable file with administrator (root)
    privileges inside a MATE Terminal.


## WARNING!

Running the File Manager, the Text Editor or an executable with Administrator
privileges **is dangerous**!
**You can easily destroy your system if you are not careful!**
**Think twice** before doing so, especially before running untrusted executables
downloaded from the Internet.
**They can contain malware**, which can do
**irreversible damage to your system** when given Administrator privileges!

You will be warned the first time you use one of the actions above.


## Download

You can download the latest version of the extension from the
[Releases][download] page.


## Compiling from source

Check the [INSTALL.md][install] file for instruction on how to compile the
extension from source.


## Reporting bugs

You can report bugs and ask questions at the extension's [issue tracker][issues].


## Contributing

Check the [CONTRIBUTING.md][contribute] file for info on how to contribute.



[install]: INSTALL.md
[contribute]: CONTRIBUTING.md
[homepage]: https://github.com/infirit/caja-admin
[download]: https://github.com/infirit/caja-admin/releases
[issues]: https://github.com/infirit/caja-admin/issues
