#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  caja-rename.py
#
#  Copyright 2017 Robert Tari <robert.tari@gmail.com>
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

APPNAME = 'cajarename'
APPEXECUTABLE='/usr/share/caja-python/extensions/caja-rename.py'
APPDEPENDENCIES = ['python-gi', 'gir1.2-gtk-3.0', 'caja', 'python-caja']
APPVERSION = '17.3.28'
APPSHOWSETTINGS = 170323
APPYEAR = '2017'
APPTITLE = 'Rename...'
APPDESCRIPTION = 'Batch renaming extension for Caja.'
APPLONGDESCRIPTION = 'An extension for Caja allowing users to rename multiple files/folders in a single pass. The application can change the case, insert, replace and delete strings, as well as enumerate the selection. Any changes are instantly visible in the preview list. The user interface strives to be as simple as possible, without confusing advanced operations.'
APPAUTHOR = 'Robert Tari'
APPMAIL = 'robert.tari@gmail.com'
APPURL = 'https://tari.in/www/software/cajarename/'
APPKEYWORDS = ['caja','batch','rename','python','extension']
