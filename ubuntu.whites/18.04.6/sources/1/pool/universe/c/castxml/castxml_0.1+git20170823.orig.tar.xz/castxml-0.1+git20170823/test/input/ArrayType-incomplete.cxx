typedef int start[];
