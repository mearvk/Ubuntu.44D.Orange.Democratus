class start
{
  start();
};
