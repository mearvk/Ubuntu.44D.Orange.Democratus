class start
{
  operator int();
};
