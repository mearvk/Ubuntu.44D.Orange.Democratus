typedef int const start;
