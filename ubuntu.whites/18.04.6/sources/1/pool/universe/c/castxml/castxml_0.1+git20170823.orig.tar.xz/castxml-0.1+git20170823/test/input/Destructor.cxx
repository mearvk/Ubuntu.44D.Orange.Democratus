class start
{
  ~start();
};
