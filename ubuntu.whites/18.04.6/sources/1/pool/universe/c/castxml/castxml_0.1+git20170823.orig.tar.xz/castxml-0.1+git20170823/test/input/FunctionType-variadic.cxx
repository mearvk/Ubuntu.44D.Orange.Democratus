typedef void start(int, ...);
