typedef void start(int);
