typedef int start;
