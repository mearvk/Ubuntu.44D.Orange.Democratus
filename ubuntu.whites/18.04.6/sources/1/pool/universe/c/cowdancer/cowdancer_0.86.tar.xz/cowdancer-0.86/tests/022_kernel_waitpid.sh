#!/bin/bash
# just test kernel functionality on waitpid.
set -ex

022_kernel_waitpid
