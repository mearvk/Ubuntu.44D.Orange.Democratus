--  Copyright (C) 2013 Ganesh Sittampalam
--
--  BSD3

module Darcs.Patch.Matchable ( Matchable ) where

import Darcs.Patch.Inspect ( PatchInspect )
import Darcs.Patch.Patchy ( Patchy )

class (Patchy p, PatchInspect p)
    => Matchable p
