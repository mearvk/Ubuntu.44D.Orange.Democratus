{-# OPTIONS_GHC -fno-warn-orphans #-}
module Darcs.Patch.Prim.FileUUID ( Prim ) where

import Prelude ()
import Darcs.Prelude

import Darcs.Patch.Prim.FileUUID.Apply ()
import Darcs.Patch.Prim.FileUUID.Coalesce ()
import Darcs.Patch.Prim.FileUUID.Commute ()
import Darcs.Patch.Prim.FileUUID.Core ( Prim )
import Darcs.Patch.Prim.FileUUID.Details ()
import Darcs.Patch.Prim.FileUUID.Read ()
import Darcs.Patch.Prim.FileUUID.Show ()

import Darcs.Patch.Prim.Class ( PrimPatch, PrimPatchBase(..), FromPrim(..) )
import Darcs.Patch.Patchy ( Patchy )

instance PrimPatch Prim
instance Patchy Prim

instance PrimPatchBase Prim where
  type PrimOf Prim = Prim

instance FromPrim Prim where
  fromPrim = id
