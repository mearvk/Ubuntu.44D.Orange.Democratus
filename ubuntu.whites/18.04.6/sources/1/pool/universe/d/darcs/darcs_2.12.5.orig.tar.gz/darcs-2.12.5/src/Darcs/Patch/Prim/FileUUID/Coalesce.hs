{-# OPTIONS_GHC -fno-warn-orphans #-}
module Darcs.Patch.Prim.FileUUID.Coalesce () where

import Prelude ()
import Darcs.Prelude

import Darcs.Patch.Prim.Class ( PrimCanonize(..) )
import Darcs.Patch.Witnesses.Ordered( FL(..) )
import Darcs.Patch.Prim.FileUUID.Core( Prim )

-- TODO
instance PrimCanonize Prim where
   tryToShrink = error "tryToShrink"
   tryShrinkingInverse _ = error "tryShrinkingInverse"
   sortCoalesceFL = id
   canonize _ = (:>: NilFL)
   canonizeFL _ = id
   coalesce = const Nothing
