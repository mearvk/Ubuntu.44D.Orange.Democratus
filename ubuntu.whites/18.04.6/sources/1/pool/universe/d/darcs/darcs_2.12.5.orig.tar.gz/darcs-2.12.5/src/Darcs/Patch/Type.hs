module Darcs.Patch.Type ( PatchType(..), patchType ) where

import Darcs.Patch.RepoType ( RepoType )

-- |Used for indicating a patch type without having a concrete patch
data PatchType (rt :: RepoType) (p :: * -> * -> *) = PatchType

patchType :: p wX wY -> PatchType rt p
patchType _ = PatchType
