{-# OPTIONS_GHC -fno-warn-orphans #-}
module Darcs.Patch.V1 ( RepoPatchV1 ) where

import Darcs.Patch.Matchable ( Matchable )
import Darcs.Patch.Patchy ( Patchy )
import Darcs.Patch.Prim ( PrimPatch )
import Darcs.Patch.RepoPatch ( RepoPatch )

import Darcs.Patch.V1.Apply ()
import Darcs.Patch.V1.Commute ()
import Darcs.Patch.V1.Core ( RepoPatchV1 )
import Darcs.Patch.V1.Read ()
import Darcs.Patch.V1.Show ()
import Darcs.Patch.V1.Viewing ()

instance PrimPatch prim => Patchy    (RepoPatchV1 prim)
instance PrimPatch prim => Matchable (RepoPatchV1 prim)
instance PrimPatch prim => RepoPatch (RepoPatchV1 prim)
