{-# OPTIONS_GHC -fno-warn-orphans #-}
module Darcs.Patch.V2 ( RepoPatchV2, prim2repopatchV2 ) where

import Darcs.Patch.Matchable ( Matchable )
import Darcs.Patch.Prim ( PrimPatch )
import Darcs.Patch.RepoPatch ( RepoPatch )

import Darcs.Patch.V2.RepoPatch ( RepoPatchV2, prim2repopatchV2 )

instance PrimPatch prim => Matchable (RepoPatchV2 prim)
instance PrimPatch prim => RepoPatch (RepoPatchV2 prim)
