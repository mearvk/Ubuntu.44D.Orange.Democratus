#!/usr/bin/env bash

. lib
darcs init R
cd R
touch äöüßÄÖÜ
darcs record -lam'added äöüßÄÖÜ'
#darcs log -s | grep './äöüßÄÖÜ'
DARCS_DONT_ESCAPE_8BIT=1 darcs log -s | grep './äöüßÄÖÜ'
