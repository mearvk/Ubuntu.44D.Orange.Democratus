#!/usr/bin/env bash
. ./lib

# RT#544 using context created with 8-bit chars;
rm -rf temp1

mkdir temp1

cd temp1
darcs init
touch foo
darcs record -la -m 'add\212 foo' | grep 'Finished record'
darcs log --context >context
date > foo
darcs record -a -m 'date foo' | grep 'Finished record'
darcs send -a -o patch --context context . | grep 'Wrote patch to'
cd ..
rm -rf temp1
