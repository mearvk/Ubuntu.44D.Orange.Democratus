/* ============================================================
* Falkon - Qt web browser
* Copyright (C) 2010-2014  David Rosca <nowrep@gmail.com>
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
* ============================================================ */
#ifndef LICENSEVIEWER_H
#define LICENSEVIEWER_H

#include <QWidget>

#include "qzcommon.h"

class QTextBrowser;

class FALKON_EXPORT LicenseViewer : public QWidget
{
    Q_OBJECT

public:
    explicit LicenseViewer(QWidget* parent = 0);

    void setLicenseFile(const QString &fileName);
    void setText(const QString &text);

private:
    QTextBrowser* m_textBrowser;
};

#endif // LICENSEVIEWER_H
