<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>FeatherPad::AboutDialog</name>
    <message>
        <location filename="../../about.ui" line="124"/>
        <source>License</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FeatherPad::FPwin</name>
    <message>
        <location filename="../../fpwin.cpp" line="348"/>
        <location filename="../../fpwin.cpp" line="1417"/>
        <location filename="../../fpwin.cpp" line="1480"/>
        <location filename="../../fpwin.cpp" line="1873"/>
        <location filename="../../fpwin.cpp" line="1912"/>
        <location filename="../../fpwin.cpp" line="2573"/>
        <location filename="../../fpwin.cpp" line="2593"/>
        <location filename="../../fpwin.cpp" line="2596"/>
        <location filename="../../fpwin.cpp" line="3029"/>
        <location filename="../../fpwin.cpp" line="3691"/>
        <source>Untitled</source>
        <translation>无标题</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="71"/>
        <source>Go to line:</source>
        <translation>转到行:</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="107"/>
        <source>Select text from cursor to this line
(Ctrl+Shift+J)</source>
        <translation>选择从光标至此行的文本
(Ctrl+Shift+J)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="111"/>
        <source>Select Text</source>
        <translation>选择文本</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="114"/>
        <location filename="../../fpwin.cpp" line="656"/>
        <source>Ctrl+Shift+J</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="149"/>
        <source>&amp;File</source>
        <translation>文件(&amp;F)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="187"/>
        <location filename="../../fp.ui" line="966"/>
        <source>&amp;Edit</source>
        <translation>编辑(&amp;E)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="205"/>
        <source>&amp;Options</source>
        <translation>选项(&amp;O)</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1446"/>
        <location filename="../../fpwin.cpp" line="2500"/>
        <location filename="../../fpwin.cpp" line="3536"/>
        <source>Encoding</source>
        <translation>编码</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="268"/>
        <source>&amp;Search</source>
        <translation>搜索(&amp;S)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="276"/>
        <location filename="../../fp.ui" line="732"/>
        <source>&amp;Help</source>
        <translation>帮助(&amp;H)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="376"/>
        <source>Find:</source>
        <translation>查找:</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="392"/>
        <source>To be replaced</source>
        <translation>要替换的文本</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="405"/>
        <source>Replace with:</source>
        <translation>替换为:</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="421"/>
        <source>Replacing text</source>
        <translation>替换文本</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="105"/>
        <location filename="../../fpwin.cpp" line="249"/>
        <location filename="../../fpwin.cpp" line="649"/>
        <location filename="../../fpwin.cpp" line="1350"/>
        <source>F8</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="104"/>
        <location filename="../../fpwin.cpp" line="248"/>
        <location filename="../../fpwin.cpp" line="649"/>
        <location filename="../../fpwin.cpp" line="1349"/>
        <source>F7</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="106"/>
        <location filename="../../fpwin.cpp" line="250"/>
        <location filename="../../fpwin.cpp" line="649"/>
        <location filename="../../fpwin.cpp" line="1351"/>
        <source>F9</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="480"/>
        <source>&amp;New</source>
        <translation>新建(&amp;N)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="483"/>
        <source>New tab</source>
        <translation>新建标签</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="486"/>
        <location filename="../../fpwin.cpp" line="1290"/>
        <location filename="../../fpwin.cpp" line="4390"/>
        <source>Ctrl+N</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="491"/>
        <source>&amp;Open</source>
        <translation>打开(&amp;O)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="494"/>
        <source>Open a file</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="497"/>
        <location filename="../../fpwin.cpp" line="1291"/>
        <location filename="../../fpwin.cpp" line="4391"/>
        <source>Ctrl+O</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="505"/>
        <source>&amp;Save</source>
        <translation>保存(&amp;S)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="508"/>
        <source>Save the current tab</source>
        <translation>保存当前标签</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="511"/>
        <location filename="../../fpwin.cpp" line="1292"/>
        <location filename="../../fpwin.cpp" line="4392"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="519"/>
        <source>&amp;Undo</source>
        <translation>撤销(&amp;U)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="522"/>
        <source>Undo</source>
        <translation>撤销</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="525"/>
        <location filename="../../fpwin.cpp" line="643"/>
        <location filename="../../fpwin.cpp" line="1312"/>
        <location filename="../../fpwin.cpp" line="4414"/>
        <source>Ctrl+Z</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="533"/>
        <source>&amp;Redo</source>
        <translation>重做(&amp;R)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="536"/>
        <source>Redo</source>
        <translation>重做</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="539"/>
        <location filename="../../fpwin.cpp" line="643"/>
        <location filename="../../fpwin.cpp" line="1313"/>
        <location filename="../../fpwin.cpp" line="4415"/>
        <source>Ctrl+Shift+Z</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="547"/>
        <location filename="../../fp.ui" line="550"/>
        <source>Reload</source>
        <translation>刷新</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="553"/>
        <location filename="../../fpwin.cpp" line="1304"/>
        <location filename="../../fpwin.cpp" line="4393"/>
        <source>Ctrl+Shift+R</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="558"/>
        <source>&amp;Find</source>
        <translation>查找(&amp;F)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="564"/>
        <location filename="../../fpwin.cpp" line="1293"/>
        <location filename="../../fpwin.cpp" line="4394"/>
        <source>Ctrl+F</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="572"/>
        <source>Show/hide replacement dock</source>
        <translation>显示/隐藏替换工具栏</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="575"/>
        <location filename="../../fpwin.cpp" line="1294"/>
        <location filename="../../fpwin.cpp" line="4395"/>
        <source>Ctrl+R</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="580"/>
        <source>Save &amp;As</source>
        <translation>另存为(&amp;A)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="583"/>
        <location filename="../../fpwin.cpp" line="1295"/>
        <location filename="../../fpwin.cpp" line="4396"/>
        <source>Ctrl+Shift+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="588"/>
        <source>&amp;Print</source>
        <translation>打印(&amp;P)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="591"/>
        <location filename="../../fpwin.cpp" line="1296"/>
        <location filename="../../fpwin.cpp" line="4397"/>
        <source>Ctrl+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="596"/>
        <source>Documen&amp;t Properties</source>
        <translation>文档属性(&amp;T)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="599"/>
        <location filename="../../fpwin.cpp" line="1297"/>
        <location filename="../../fpwin.cpp" line="4398"/>
        <source>Ctrl+Shift+D</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="604"/>
        <source>&amp;Close</source>
        <translation>关闭(&amp;C)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="607"/>
        <location filename="../../fpwin.cpp" line="1298"/>
        <location filename="../../fpwin.cpp" line="4399"/>
        <source>Ctrl+Shift+Q</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="612"/>
        <source>&amp;Quit</source>
        <translation>退出(&amp;Q)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="615"/>
        <location filename="../../fpwin.cpp" line="1299"/>
        <location filename="../../fpwin.cpp" line="4400"/>
        <source>Ctrl+Q</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="623"/>
        <source>&amp;Cut</source>
        <translation>剪切(&amp;C)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="626"/>
        <location filename="../../fpwin.cpp" line="643"/>
        <location filename="../../fpwin.cpp" line="1344"/>
        <source>Ctrl+X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="634"/>
        <source>C&amp;opy</source>
        <translation>复制(&amp;O)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="637"/>
        <location filename="../../fpwin.cpp" line="643"/>
        <location filename="../../fpwin.cpp" line="1345"/>
        <source>Ctrl+C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="642"/>
        <source>&amp;Paste</source>
        <translation>粘贴(&amp;P)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="645"/>
        <location filename="../../fpwin.cpp" line="643"/>
        <location filename="../../fpwin.cpp" line="1346"/>
        <source>Ctrl+V</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="653"/>
        <source>&amp;Delete</source>
        <translation>删除(&amp;D)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="658"/>
        <source>&amp;Select All</source>
        <translation>全选(&amp;S)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="661"/>
        <location filename="../../fpwin.cpp" line="643"/>
        <location filename="../../fpwin.cpp" line="1347"/>
        <source>Ctrl+A</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="666"/>
        <source>&amp;Font</source>
        <translation>字体(&amp;F)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="674"/>
        <source>&amp;Line Numbers</source>
        <translation>行数(&amp;L)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="677"/>
        <location filename="../../fpwin.cpp" line="1285"/>
        <location filename="../../fpwin.cpp" line="4401"/>
        <source>Ctrl+L</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="688"/>
        <source>&amp;Wrap Lines</source>
        <translation>自动换行(&amp;W)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="691"/>
        <location filename="../../fpwin.cpp" line="1286"/>
        <location filename="../../fpwin.cpp" line="4402"/>
        <source>Ctrl+W</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="702"/>
        <source>&amp;Auto-Indentation</source>
        <translation>自动缩进(&amp;A)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="705"/>
        <location filename="../../fpwin.cpp" line="1287"/>
        <location filename="../../fpwin.cpp" line="4403"/>
        <source>Ctrl+I</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="716"/>
        <source>&amp;Syntax Highlighting</source>
        <translation>语法高亮(&amp;S)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="719"/>
        <location filename="../../fpwin.cpp" line="1288"/>
        <location filename="../../fpwin.cpp" line="4404"/>
        <source>Ctrl+Shift+H</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="724"/>
        <source>&amp;Preferences</source>
        <translation>首选项(&amp;P)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="727"/>
        <location filename="../../fpwin.cpp" line="1300"/>
        <location filename="../../fpwin.cpp" line="4405"/>
        <source>Ctrl+Shift+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="735"/>
        <location filename="../../fpwin.cpp" line="1301"/>
        <location filename="../../fpwin.cpp" line="4406"/>
        <source>Ctrl+H</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="740"/>
        <source>&amp;About</source>
        <translation>关于(&amp;A)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="767"/>
        <source>Enforce UTF-8</source>
        <translation>强制使用 UTF-8</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="950"/>
        <source>Save with &amp;Encoding</source>
        <translation>保存为编码(&amp;E)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="955"/>
        <source>&amp;Jump to</source>
        <translation>跳转至(&amp;J)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="958"/>
        <source>Show/hide jump bar</source>
        <translation>显示/隐藏跳转栏</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="961"/>
        <location filename="../../fpwin.cpp" line="1306"/>
        <location filename="../../fpwin.cpp" line="4407"/>
        <source>Ctrl+J</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="969"/>
        <source>Edit text</source>
        <translation>编辑文本</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="972"/>
        <location filename="../../fpwin.cpp" line="4408"/>
        <source>Ctrl+Shift+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1075"/>
        <source>&amp;Run</source>
        <translation>运行(&amp;R)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1081"/>
        <location filename="../../fpwin.cpp" line="1302"/>
        <location filename="../../fpwin.cpp" line="1307"/>
        <location filename="../../fpwin.cpp" line="4410"/>
        <source>Ctrl+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1086"/>
        <source>&amp;Clear</source>
        <translation>清除(&amp;C)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1089"/>
        <source>Clear the list of recently modified files</source>
        <translation>清除最近更改的文件</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1094"/>
        <source>Save/Restore Session</source>
        <translation>保存/恢复会话</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1097"/>
        <source>Sa&amp;ve/Restore Session</source>
        <translation>保存/恢复会话(&amp;V)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1100"/>
        <location filename="../../fpwin.cpp" line="1308"/>
        <location filename="../../fpwin.cpp" line="4411"/>
        <source>Ctrl+M</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1105"/>
        <source>Side-Pane</source>
        <translation>侧边栏</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1108"/>
        <location filename="../../fpwin.cpp" line="1310"/>
        <location filename="../../fpwin.cpp" line="4412"/>
        <source>Ctrl+Alt+P</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1113"/>
        <source>Paste Date and Time</source>
        <translation>粘贴日期与时间</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1116"/>
        <location filename="../../fpwin.cpp" line="1314"/>
        <location filename="../../fpwin.cpp" line="4416"/>
        <source>Ctrl+Shift+V</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="980"/>
        <source>&amp;Detach Tab</source>
        <translation>分离标签(&amp;D)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="983"/>
        <location filename="../../fpwin.cpp" line="1303"/>
        <location filename="../../fpwin.cpp" line="4409"/>
        <source>Ctrl+T</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="996"/>
        <source>Close Ne&amp;xt Tabs</source>
        <translation>关闭右侧标签(&amp;X)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1001"/>
        <source>Close &amp;Previous Tabs</source>
        <translation>关闭左侧标签(&amp;P)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1029"/>
        <source>Ne&amp;xt Tab</source>
        <translation>下一个标签(&amp;X)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1040"/>
        <source>Previous Ta&amp;b</source>
        <translation>上一个标签(&amp;B)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1078"/>
        <source>Execute</source>
        <translation>执行</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1006"/>
        <source>Close &amp;All Tabs</source>
        <translation>关闭所有标签(&amp;A)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="153"/>
        <source>Recently &amp;Modified</source>
        <translation>最近更改的文件(&amp;M)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="209"/>
        <source>&amp;Encoding</source>
        <translation>编码(&amp;E)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="213"/>
        <source>&amp;Unicode</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="220"/>
        <source>&amp;Western European</source>
        <translation>西欧(&amp;W)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="228"/>
        <source>&amp;East European</source>
        <translation>东欧(&amp;E)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="236"/>
        <source>Ea&amp;st Asian</source>
        <translation>东亚(&amp;S)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="328"/>
        <location filename="../../fpwin.cpp" line="3122"/>
        <location filename="../../replace.cpp" line="62"/>
        <location filename="../../replace.cpp" line="114"/>
        <source>Rep&amp;lacement</source>
        <translation>替换(&amp;L)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="561"/>
        <source>Focus/hide search bar</source>
        <translation>显示/隐藏搜索栏</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="569"/>
        <source>&amp;Replace</source>
        <translation>替换(&amp;R)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="751"/>
        <source>Windows Arabic (&amp;CP1256)</source>
        <translation>Windows 阿拉伯语（&amp;CP1256）</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="759"/>
        <source>&amp;Other</source>
        <translation>其它(&amp;O)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="778"/>
        <source>&amp;UTF-8</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="789"/>
        <source>UTF-&amp;16</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="800"/>
        <source>&amp;ISO-8859-1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="811"/>
        <source>&amp;Windows-1252</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="822"/>
        <source>&amp;Cyrillic (CP1251)</source>
        <translation>西里尔文（CP1251）(&amp;C)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="833"/>
        <source>Cyrillic (&amp;KOI8-U)</source>
        <translation>西里尔文（&amp;KOI8-U）</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="844"/>
        <source>Cyrillic (&amp;ISO-8859-5)</source>
        <translation>西里尔文（&amp;ISO-8859-5）</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="855"/>
        <source>&amp;Chineese (BIG5)</source>
        <translation>繁体中文（大五码）(&amp;C)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="866"/>
        <source>Chinese (&amp;GB18030)</source>
        <translation>简体中文（&amp;GB18030）</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="877"/>
        <source>&amp;Japanese (ISO-2022-JP)</source>
        <translation>日文（ISO-2022-JP）(&amp;J)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="888"/>
        <source>Japanese (&amp;ISO-2022-JP-2)</source>
        <translation>日文（&amp;ISO-2022-JP-2）</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="899"/>
        <source>Japanese (ISO-&amp;2022-KR)</source>
        <translation>日文（ISO-&amp;2022-KR）</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="910"/>
        <source>Ja&amp;panese (CP932)</source>
        <translation>日文（CP932）(&amp;P)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="921"/>
        <source>Japa&amp;nese (EUC-JP)</source>
        <translation>日文（EUC-JP）(&amp;N)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="929"/>
        <source>&amp;Korean (CP949)</source>
        <translation>韩文（CP949）(&amp;K)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="937"/>
        <source>K&amp;orean (CP1361)</source>
        <translation>韩文（CP1361）(&amp;O)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="945"/>
        <source>Korean (&amp;EUC-KR)</source>
        <translation>韩文（&amp;EUC-KR）</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="991"/>
        <source>ISO-&amp;8859-15</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1011"/>
        <source>Close &amp;Other Tabs</source>
        <translation>关闭其它标签(&amp;O)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1016"/>
        <source>&amp;Copy File Name</source>
        <translation>复制文件名(&amp;C)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1021"/>
        <source>Copy File &amp;Path</source>
        <translation>复制文件路径(&amp;P)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1032"/>
        <location filename="../../fpwin.cpp" line="559"/>
        <location filename="../../fpwin.cpp" line="625"/>
        <location filename="../../fpwin.cpp" line="655"/>
        <location filename="../../fpwin.cpp" line="1356"/>
        <location filename="../../fpwin.cpp" line="1360"/>
        <source>Alt+Right</source>
        <translation>Alt+右方向键</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1043"/>
        <location filename="../../fpwin.cpp" line="558"/>
        <location filename="../../fpwin.cpp" line="624"/>
        <location filename="../../fpwin.cpp" line="655"/>
        <location filename="../../fpwin.cpp" line="1355"/>
        <location filename="../../fpwin.cpp" line="1361"/>
        <source>Alt+Left</source>
        <translation>Alt+左方向键</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1051"/>
        <source>&amp;First Tab</source>
        <translation>第一个标签(&amp;F)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1054"/>
        <location filename="../../fpwin.cpp" line="655"/>
        <location filename="../../fpwin.cpp" line="1364"/>
        <source>Alt+Down</source>
        <translation>Alt+下方向键</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1062"/>
        <source>&amp;Last Tab</source>
        <translation>最后一个标签(&amp;L)</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1065"/>
        <location filename="../../fpwin.cpp" line="655"/>
        <location filename="../../fpwin.cpp" line="1363"/>
        <source>Alt+Up</source>
        <translation>Alt+上方向键</translation>
    </message>
    <message>
        <location filename="../../fp.ui" line="1070"/>
        <source>Menu</source>
        <translation>菜单</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="90"/>
        <source>Calculate number of words
(For huge texts, this may be CPU-intensive.)</source>
        <translation>统计字数
（对于大量文本，这可能导致 CPU 缓慢。）</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="104"/>
        <location filename="../../fpwin.cpp" line="478"/>
        <source>Next</source>
        <translation>下一个</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="105"/>
        <location filename="../../fpwin.cpp" line="479"/>
        <source>Previous</source>
        <translation>上一个</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="106"/>
        <source>Replace all</source>
        <translation>替换所有</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="461"/>
        <source>&amp;Recently Opened</source>
        <translation>最近打开的文件(&amp;R)</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="480"/>
        <source>All</source>
        <translation>所有</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1732"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1147"/>
        <source>Save changes?</source>
        <translation>是否保存更改？</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="881"/>
        <source>Please attend to that window or just close its dialog!</source>
        <translation>请转到那个窗口或关闭其对话框！</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1151"/>
        <source>The document has been modified.</source>
        <translation>文档已更改。</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1149"/>
        <location filename="../../fpwin.cpp" line="3036"/>
        <location filename="../../fpwin.cpp" line="3210"/>
        <source>The file has been removed.</source>
        <translation>文件已被删除。</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1161"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1162"/>
        <source>Discard changes</source>
        <translation>抛弃更改</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1163"/>
        <location filename="../../fpwin.cpp" line="2743"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1165"/>
        <source>No to all</source>
        <translation>全不</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1428"/>
        <location filename="../../fpwin.cpp" line="1481"/>
        <source>Unsaved</source>
        <translation>未保存</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1447"/>
        <location filename="../../fpwin.cpp" line="2502"/>
        <location filename="../../fpwin.cpp" line="2854"/>
        <location filename="../../fpwin.cpp" line="2865"/>
        <location filename="../../fpwin.cpp" line="2872"/>
        <location filename="../../fpwin.cpp" line="3540"/>
        <location filename="../../fpwin.cpp" line="4597"/>
        <location filename="../../fpwin.cpp" line="4608"/>
        <location filename="../../fpwin.cpp" line="4615"/>
        <source>Lines</source>
        <translation>行</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1448"/>
        <location filename="../../fpwin.cpp" line="3541"/>
        <location filename="../../fpwin.cpp" line="3555"/>
        <source>Sel. Chars</source>
        <translation>选区</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1449"/>
        <location filename="../../fpwin.cpp" line="3543"/>
        <location filename="../../fpwin.cpp" line="3556"/>
        <source>Words</source>
        <translation>字</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1639"/>
        <source>Another process is running in this tab!</source>
        <translation>另外的进程正在此标签内运行！</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1723"/>
        <source>Script File</source>
        <translation>脚本文件</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="880"/>
        <source>Another FeatherPad window has a modal dialog!</source>
        <translation>另外的 FeatherPad 窗口弹出了对话框！</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="252"/>
        <location filename="../../fpwin.cpp" line="652"/>
        <source>Ctrl+=</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="253"/>
        <location filename="../../fpwin.cpp" line="652"/>
        <source>Ctrl++</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="254"/>
        <location filename="../../fpwin.cpp" line="652"/>
        <source>Ctrl+-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="255"/>
        <location filename="../../fpwin.cpp" line="652"/>
        <source>Ctrl+0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="261"/>
        <location filename="../../fpwin.cpp" line="650"/>
        <source>F11</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="262"/>
        <location filename="../../fpwin.cpp" line="650"/>
        <source>Ctrl+Shift+W</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="272"/>
        <location filename="../../fpwin.cpp" line="653"/>
        <source>Ctrl+Alt+E</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="644"/>
        <source>Shift+Ins</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="644"/>
        <source>Shift+Del</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="644"/>
        <source>Ctrl+Ins</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="644"/>
        <source>Ctrl+Left</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="644"/>
        <source>Ctrl+Right</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="645"/>
        <source>Ctrl+Up</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="645"/>
        <source>Ctrl+Down</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="645"/>
        <source>Ctrl+Home</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="645"/>
        <source>Ctrl+End</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="648"/>
        <location filename="../../fpwin.cpp" line="1384"/>
        <source>F3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="648"/>
        <location filename="../../fpwin.cpp" line="1384"/>
        <source>F4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="648"/>
        <location filename="../../fpwin.cpp" line="1384"/>
        <source>F5</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="648"/>
        <location filename="../../fpwin.cpp" line="1384"/>
        <source>F6</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="654"/>
        <source>Shift+Enter</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="654"/>
        <source>Ctrl+Tab</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="654"/>
        <source>Ctrl+Meta+Tab</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="657"/>
        <source>Ctrl+K</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="681"/>
        <location filename="../../fpwin.cpp" line="3582"/>
        <source>Position:</source>
        <translation>位置:</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="767"/>
        <location filename="../../fpwin.cpp" line="3598"/>
        <location filename="../../fpwin.cpp" line="3616"/>
        <source>Normal</source>
        <translation>常规</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1640"/>
        <source>Only one process is allowed per tab.</source>
        <translation>每个标签只允许一个进程。</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1719"/>
        <source>Script Output</source>
        <translation>脚本输出</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="1735"/>
        <source>Clear</source>
        <translation>清除</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2270"/>
        <source>FeatherPad does not open files larger than 100 MiB.</source>
        <translation>FeatherPad 不能打开大于 100 MiB 的文件。</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2278"/>
        <source>Some file(s) could not be opened!</source>
        <translation>无法打开某些文件！</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2279"/>
        <source>You may not have the permission to read.</source>
        <translation>您可能没有读取权限。</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2287"/>
        <source>Uneditable file(s)!</source>
        <translation>文件不可编辑！</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2288"/>
        <source>Non-text files or files with huge lines cannot be edited.</source>
        <translation>无法编辑非文本文件或行数太多的文件。</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2325"/>
        <source>A previous crash detected!</source>
        <translation>检测到前次崩溃！</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2326"/>
        <source>Preferably, close all FeatherPad windows and start again!</source>
        <translation>建议关闭所有 FeatherPad 窗口并重新启动本程序！</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2404"/>
        <location filename="../../fpwin.cpp" line="2555"/>
        <location filename="../../fpwin.cpp" line="2582"/>
        <source>All Files (*)</source>
        <translation>所有文件（*）</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2409"/>
        <source>All Files (*);;.%1 Files (*.%1)</source>
        <translation>所有文件（*）;;.%1文件（*.%1）</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2413"/>
        <source>Open file...</source>
        <translation>打开文件...</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2560"/>
        <source>.%1 Files (*.%1);;All Files (*)</source>
        <translation>.%1文件（*.%1）;;所有文件（*）</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2607"/>
        <location filename="../../fpwin.cpp" line="2638"/>
        <source>Save as...</source>
        <translation>另存为...</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2667"/>
        <source>Keep encoding and save as...</source>
        <translation>保持编码并另存为...</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2741"/>
        <source>Yes</source>
        <translation>是</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2742"/>
        <source>No</source>
        <translation>否</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2744"/>
        <source>Do you want to use &lt;b&gt;MS Windows&lt;/b&gt; end-of-lines?</source>
        <translation>您是否想使用 &lt;b&gt;Windows&lt;/b&gt; 结束行？</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2745"/>
        <source>This may be good for readability under MS Windows.</source>
        <translation>这可能使之适合在 Windows 下阅读。</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2888"/>
        <source>Cannot be saved!</source>
        <translation>无法保存！</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="346"/>
        <location filename="../../fpwin.cpp" line="3027"/>
        <location filename="../../fpwin.cpp" line="4763"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2850"/>
        <location filename="../../fpwin.cpp" line="2856"/>
        <location filename="../../fpwin.cpp" line="2864"/>
        <location filename="../../fpwin.cpp" line="3539"/>
        <location filename="../../fpwin.cpp" line="4593"/>
        <location filename="../../fpwin.cpp" line="4599"/>
        <location filename="../../fpwin.cpp" line="4607"/>
        <source>Syntax</source>
        <translation>语法</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="2269"/>
        <source>Huge file(s) not opened!</source>
        <translation>未打开大文件！</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="3038"/>
        <location filename="../../fpwin.cpp" line="3212"/>
        <source>This file has been modified elsewhere or in another way!</source>
        <translation>此文件已在他处或以其他方式被修改！</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="3039"/>
        <location filename="../../fpwin.cpp" line="3213"/>
        <source>Please be careful about reloading or saving this document!</source>
        <translation>请小心刷新或保存此文档！</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="3702"/>
        <source>Print Document</source>
        <translation>打印文档</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="4292"/>
        <location filename="../../fpwin.cpp" line="4356"/>
        <source>Copy Target Path</source>
        <translation>复制目标路径</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="4296"/>
        <location filename="../../fpwin.cpp" line="4360"/>
        <source>Open Target Here</source>
        <translation>在此打开目标</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="4678"/>
        <source>Translators</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="4674"/>
        <source>A lightweight, tabbed, plain-text editor</source>
        <translation>轻量级标签式纯文本编辑器</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="4675"/>
        <source>based on Qt5</source>
        <translation>基于 Qt5</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="4676"/>
        <source>Author</source>
        <translation>作者</translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="4677"/>
        <source>aka.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../fpwin.cpp" line="4678"/>
        <location filename="../../fpwin.cpp" line="4679"/>
        <source>About FeatherPad</source>
        <translation>关于 FeatherPad</translation>
    </message>
    <message>
        <location filename="../../replace.cpp" line="239"/>
        <source>No Replacement</source>
        <translation>无替换</translation>
    </message>
    <message>
        <location filename="../../replace.cpp" line="241"/>
        <source>One Replacement</source>
        <translation>一次替换</translation>
    </message>
    <message>
        <location filename="../../replace.cpp" line="243"/>
        <source>Replacements</source>
        <translation>次替换</translation>
    </message>
</context>
<context>
    <name>FeatherPad::FileDialog</name>
    <message>
        <location filename="../../filedialog.h" line="48"/>
        <source>Ctrl+H</source>
        <comment>Toggle showing hidden files</comment>
        <translation></translation>
    </message>
    <message>
        <location filename="../../filedialog.h" line="49"/>
        <source>Alt+.</source>
        <comment>Toggle showing hidden files</comment>
        <translation></translation>
    </message>
</context>
<context>
    <name>FeatherPad::LineEdit</name>
    <message>
        <location filename="../../lineedit.cpp" line="37"/>
        <source>Clear text (Ctrl+K)</source>
        <translation>清除文本(Ctrl+K)</translation>
    </message>
    <message>
        <location filename="../../lineedit.cpp" line="82"/>
        <source>Ctrl+K</source>
        <comment>Clear text</comment>
        <translation></translation>
    </message>
</context>
<context>
    <name>FeatherPad::PrefDialog</name>
    <message>
        <location filename="../../predDialog.ui" line="14"/>
        <source>Preferences</source>
        <translation>首选项</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="30"/>
        <source>Window</source>
        <translation>窗口</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="36"/>
        <source>Window Settings</source>
        <translation>窗口设置</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="42"/>
        <source>Remember window &amp;size on closing</source>
        <translation>关闭时保存窗口大小(&amp;S)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="49"/>
        <location filename="../../predDialog.ui" line="62"/>
        <location filename="../../predDialog.ui" line="72"/>
        <location filename="../../predDialog.ui" line="85"/>
        <source>Window frame is excluded.</source>
        <translation>不包括窗口框架。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="52"/>
        <source>Start with this size: </source>
        <translation>默认尺寸: </translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="65"/>
        <location filename="../../predDialog.ui" line="88"/>
        <source> px</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="75"/>
        <source>×</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="111"/>
        <source>Most suitable with sessions
but without tab functionality.</source>
        <translation>最适合会话，但没有标签功能。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="138"/>
        <source>Uncheck for 1/5 of the width.</source>
        <translation>如取消勾选，则侧边栏宽度为窗口宽度的五分之一。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="141"/>
        <source>Remember splitter position</source>
        <translation>记住分割位置</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="161"/>
        <source>No icons in the main window and its menus.

KDE may have a bug that disables search and
replace shortcuts with the iconless mode.

Needs application restart to take effect.</source>
        <translation>主窗口与其菜单无图标。
如您在 KDE 下运行，则在无图标模式下
搜索与替换快捷方式可能被禁用。
需要重新启动应用程序以生效。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="169"/>
        <source>&amp;Iconless mode</source>
        <translation>无图标模式(&amp;I)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="176"/>
        <source>Do not show &amp;toolbar</source>
        <translation>隐藏工具栏(&amp;T)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="183"/>
        <source>If the menubar is hidden,
a menu button appears on the toolbar.</source>
        <translation>如果菜单栏被隐藏，则工具栏上会出现一个菜单按钮。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="187"/>
        <source>Do not show &amp;menubar</source>
        <translation>隐藏菜单栏(&amp;M)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="194"/>
        <source>Hide search &amp;bar by default</source>
        <translation>默认隐藏搜索栏(&amp;B)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="201"/>
        <source>Always show st&amp;atus bar</source>
        <translation>总是显示状态栏(&amp;A)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="208"/>
        <source>Show cursor position on status bar</source>
        <translation>在状态栏上显示光标位置</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="215"/>
        <location filename="../../predDialog.ui" line="225"/>
        <source>Will take effect after closing this dialog.</source>
        <translation>关闭此对话框后生效。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="218"/>
        <source>Tab position: </source>
        <translation>标签位置: </translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="229"/>
        <source>North</source>
        <translation>北</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="234"/>
        <source>South</source>
        <translation>南</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="239"/>
        <source>West</source>
        <translation>西</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="244"/>
        <source>East</source>
        <translation>东</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="252"/>
        <source>This means that, for LTR, Alt+Right goes to the first tab
after the last tab is activated, and the same for Alt+Left.

Tab navigation with mouse wheel is not affected.</source>
        <translation>意即对于从左到右的语言环境，Alt+Right 在最后一个
标签被激活后转至第一个标签，Alt+Left 同理。
此选项不影响鼠标滚轮控制的标签导航。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="258"/>
        <source>Tab navigation wraps &amp;around</source>
        <translation>标签导航循环(&amp;A)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="278"/>
        <source>By default, if a FeatherPad window exists on the
current desktop, files will be opened in its tabs.

However, some desktop environments may not
report that they have multiple desktops.</source>
        <translation>默认情况下，如当前桌面存在一个 FeatherPad
窗口，则文件会默认打开于其内。
但某些桌面环境可能不会报告其拥有多个桌面。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="285"/>
        <source>Always open in separate windows</source>
        <translation>总是在分离窗口打开文件</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="292"/>
        <source>If this is checked, the file dialog provided by the current
desktop environment will be used instead of the Qt file dialog.

Some desktop environments, like KDE and LXQt, provide files dialogs.</source>
        <translation>如勾选，则将使用当前桌面环境提供的文件对话框，而不使用
Qt 的文件对话框。
某些桌面环境，如 KDE 与 LXQt，提供了自己的文件对话框。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="298"/>
        <source>Native file dialog</source>
        <translation>原生文件对话框</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="354"/>
        <source>Uncheck for Monospace 9.</source>
        <translation>如不勾选，则字体默认为 Monospace 9。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="357"/>
        <source>Remember &amp;font</source>
        <translation>记住字体(&amp;F)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="378"/>
        <source>This covers parentheses, braces, brackets and quotes.</source>
        <translation>包括圆括号、方括号、大括号与引号。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="381"/>
        <source>Auto-&amp;bracket</source>
        <translation>自动补全括号(&amp;B)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="447"/>
        <source>Never highlight syntax for files &gt; </source>
        <translation>禁用语法高亮于文件大小 &gt; </translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="420"/>
        <source>This creates a menu button on the
status bar for changing the syntax.</source>
        <translation>如勾选，则将在状态栏上创建一个按钮，用于更改语法。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="424"/>
        <source>Support syntax override</source>
        <translation>支持语法重写</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="467"/>
        <source>Show spaces, tabs and tab lines
when the syntax is highlighted.</source>
        <translation>语法高亮时显示空格、缩进与缩进行。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="471"/>
        <source>Show whitespaces</source>
        <translation>用语法高亮显示空格</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="486"/>
        <location filename="../../predDialog.ui" line="497"/>
        <source>The vertical position lines will be drawn only if
the editor font has a fixed pitch (like Monospace).</source>
        <translation>垂直位置行只会在编辑器字体点数固定时绘制。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="490"/>
        <source>Show vertical lines starting from this position:</source>
        <translation>显示从此位置开始的竖行:</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="479"/>
        <source>Also show line and document ends</source>
        <translation>也显示行与文档结尾</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="560"/>
        <source>Date and time format:</source>
        <translation>日期与时间格式:</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="585"/>
        <source>Some text editors cannot open a document
whose last line is not empty.</source>
        <translation>某些文本编辑器只能打开最后一行为空的文档。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="589"/>
        <source>Ensure an empty last line on saving</source>
        <translation>确保保存时在文档末尾留下一行空白</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="596"/>
        <source>Remove trailing spaces on saving</source>
        <translation>保存时移除结尾空白</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="607"/>
        <source>Inertial scrolling with mouse wheel</source>
        <translation>鼠标滚论滚动时带惯性</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="633"/>
        <source>Files</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="639"/>
        <source>File Management</source>
        <translation>文件管理</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="763"/>
        <location filename="../../predDialog.ui" line="782"/>
        <source>This can be any starting command with
arguments, for example, &quot;xterm -hold&quot;
for running the process in XTerm.

If the command is left empty, the file
will be executed directly.

If the script is not run in a terminal
emulator, the output and error messages
will be shown by a popup dialog.</source>
        <translation>此处可以是任何带参数的运行命令。如
“xterm -hold”为在 XTerm 中运行进程。
如留空，则文件会被直接执行。
如脚本不在终端模拟器中运行，则输出
与错误信息会在弹出的对话框中显示。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="775"/>
        <source>Start with this command: </source>
        <translation>以此命令运行脚本: </translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="794"/>
        <source>Command + Arguments</source>
        <translation>命令 + 参数</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="689"/>
        <source>Show recentl&amp;y modified files</source>
        <translation>显示最近更改的文件(&amp;Y)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="699"/>
        <source>Show recentl&amp;y opened files</source>
        <translation>显示最近打开的文件(&amp;Y)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="820"/>
        <source>Save changes to opened files every:</source>
        <translation>自动保存时间间隔:</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="906"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="148"/>
        <source>Uncheck this if you want FeatherPad to
use system icons!

Needs application restart to take effect.</source>
        <translation>如要使用系统图标，则请取消勾选此选项！
需要重新启动本应用程序以生效。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="115"/>
        <source>Start with side-pane mode</source>
        <translation>以侧边栏模式启动</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="154"/>
        <source>&amp;Use own icons</source>
        <translation>使用系统图标(&amp;U)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="265"/>
        <source>If this is checked, not only you will lose the informative
tooltip and context menu of a single tab but you could not
merge a single tabbed window into another one by tab drag-
and-drop either.</source>
        <translation>如勾选，您不仅会丢失单标签的工具提示与上下文菜单，
还会导致不能通过拖放将单标签窗口合并至另一个窗口。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="271"/>
        <source>&amp;Do not show a single tab</source>
        <translation>不显示单个标签(&amp;D)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="309"/>
        <source>Text</source>
        <translation>文本</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="348"/>
        <source>Text Editor</source>
        <translation>文本编辑器</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="364"/>
        <source>&amp;Wrap lines by default</source>
        <translation>默认自动换行(&amp;W)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="371"/>
        <source>Auto-&amp;indent by default</source>
        <translation>默认自动缩进(&amp;I)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="388"/>
        <source>Always show line &amp;numbers</source>
        <translation>总是显示行数(&amp;N)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="395"/>
        <source>Highlight s&amp;yntax by default</source>
        <translation>默认语法高亮(&amp;Y)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="514"/>
        <source>Dark c&amp;olor scheme</source>
        <translation>暗色主题(&amp;O)</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="545"/>
        <source>Background color value: </source>
        <translation>背景颜色值: </translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="454"/>
        <source> MiB</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="614"/>
        <source>This is not a complete fix but
prevents annoying scroll jumps.</source>
        <translation>此修复并不完善，但避免了烦人的滚动跳转。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="618"/>
        <source>Workaround for &amp;Qt5&apos;s scroll jump bug</source>
        <translation>修复 &amp;Qt5 滚动时跳转错误</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="730"/>
        <source>This only includes executable files written
in script languages like Shell and Python.

If it is checked and the opened file is
executable, the file will be executed by clicking
the Run button, that appears on the toolbar/filemenu
when needed, or by its shortcut Ctrl+E. Then, the
process could be killed by Ctrl+Alt+E.</source>
        <translation>仅适用于以脚本语言，如 Shell 或 Python
所写的可执行文件。
如勾选，且已打开的文件可以执行，则
可以通过单击“运行”按钮执行文件，此
按钮位于工具栏或文件菜单上。
您也可以通过按下 Ctrl+E 运行脚本，
Ctrl+Alt+E 结束脚本运行。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="511"/>
        <source>Needs window reopening to take effect.</source>
        <translation>需要重新开启窗口以生效。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="521"/>
        <location filename="../../predDialog.ui" line="535"/>
        <source>The color value of the background.
255 means white while 0 means black.

For the light background, it can be
between 230 and 255; for the dark
background, between 0 and 50.

Needs window reopening to take effect.</source>
        <translation>255 为白，0 为黑。
对于亮色背景，其值需在 230 与 255 之间。
对于暗色背景，其值需在 0 与 50 之间。
需要重新启动应用程序以生效。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="740"/>
        <source>Run executable scripts</source>
        <translation>运行可执行脚本</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="645"/>
        <location filename="../../predDialog.ui" line="659"/>
        <source>The maximum number of recently modified or
opened files FeatherPad shows. The default
is 10.

Needs application restart to take effect.</source>
        <translation>指定 FeatherPad 显示最近更改
或最近打开的文件的最大数量。
默认为 10。
需要重新启动应用程序以生效。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="552"/>
        <location filename="../../predDialog.ui" line="567"/>
        <source>Used for pasting the date and time.

Takes effect after closing this dialog.

Leave empty for:
MMM dd, yyyy, hh:mm:ss</source>
        <translation>用于粘贴日期与时间，在关闭此对话框后生效。
默认格式为：MMM dd, yyyy, hh:mm:ss</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="603"/>
        <source>Should the mouse wheel scrolling be inertial
if the cursor is inside the text view?</source>
        <translation>如光标在文本视图内，鼠标滚轮滚动是否应带惯性？</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="652"/>
        <source>Number of recent files: </source>
        <translation>最近文件的数量: </translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="706"/>
        <location filename="../../predDialog.ui" line="718"/>
        <source>The maximum number of recently modified or
opened files FeatherPad should open with an
empty startup of a session.</source>
        <translation>指定 FeatherPad 以空会话启动时应打开的
最近更改或最近打开的文件的数量。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="711"/>
        <source>Start with recent files: </source>
        <translation>启动时打开最近文件: </translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="817"/>
        <location filename="../../predDialog.ui" line="827"/>
        <source>Only for files that exist and can be saved.</source>
        <translation>仅对于存在且可被保存的文件。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="830"/>
        <source> min</source>
        <translation> 分钟</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="847"/>
        <source>Shortcuts</source>
        <translation>快捷方式</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="866"/>
        <source>Action</source>
        <translation>动作</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="871"/>
        <source>Shortcut</source>
        <translation>快捷方式</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="879"/>
        <source>Restore default shortcuts.</source>
        <translation>恢复默认快捷方式。</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="882"/>
        <source>Default</source>
        <translation>默认</translation>
    </message>
    <message>
        <location filename="../../predDialog.ui" line="917"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../../pref.cpp" line="237"/>
        <location filename="../../pref.cpp" line="243"/>
        <location filename="../../pref.cpp" line="1112"/>
        <location filename="../../pref.cpp" line="1117"/>
        <location filename="../../pref.cpp" line="1126"/>
        <source>files</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../../pref.cpp" line="237"/>
        <location filename="../../pref.cpp" line="243"/>
        <location filename="../../pref.cpp" line="1112"/>
        <location filename="../../pref.cpp" line="1117"/>
        <location filename="../../pref.cpp" line="1126"/>
        <source>file</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../../pref.cpp" line="244"/>
        <source>No file</source>
        <translation>无文件</translation>
    </message>
    <message>
        <location filename="../../pref.cpp" line="356"/>
        <location filename="../../pref.cpp" line="1219"/>
        <source>Warning: Ambiguous shortcut detected!</source>
        <translation>警告：检测到不明确的快捷方式！</translation>
    </message>
    <message>
        <location filename="../../pref.cpp" line="458"/>
        <source>Application restart is needed for changes to take effect.</source>
        <translation>需要重新启动应用程序以使更改生效。</translation>
    </message>
    <message>
        <location filename="../../pref.cpp" line="469"/>
        <source>Window reopening is needed for changes to take effect.</source>
        <translation>需要重新开启窗口以生效。</translation>
    </message>
    <message>
        <location filename="../../pref.cpp" line="1141"/>
        <source>&amp;Recently Opened</source>
        <translation>最近打开的文件(&amp;R)</translation>
    </message>
    <message>
        <location filename="../../pref.cpp" line="1142"/>
        <source>Recently &amp;Modified</source>
        <translation>最近更改的文件(&amp;M)</translation>
    </message>
    <message>
        <location filename="../../pref.cpp" line="1209"/>
        <source>The typed shortcut was not valid.</source>
        <translation>输入的快捷方式无效。</translation>
    </message>
    <message>
        <location filename="../../pref.cpp" line="1211"/>
        <source>The typed shortcut was reserved.</source>
        <translation>输入的快捷方式已被保留。</translation>
    </message>
</context>
<context>
    <name>FeatherPad::SearchBar</name>
    <message>
        <location filename="../../searchbar.cpp" line="35"/>
        <source>Search...</source>
        <translation>搜索...</translation>
    </message>
    <message>
        <location filename="../../searchbar.cpp" line="66"/>
        <location filename="../../searchbar.cpp" line="70"/>
        <source>Match Case</source>
        <translation>区分大小写</translation>
    </message>
    <message>
        <location filename="../../searchbar.cpp" line="78"/>
        <location filename="../../searchbar.cpp" line="82"/>
        <source>Whole Word</source>
        <translation>全字匹配</translation>
    </message>
    <message>
        <location filename="../../searchbar.cpp" line="55"/>
        <location filename="../../searchbar.cpp" line="60"/>
        <source>Next</source>
        <translation>下一个</translation>
    </message>
    <message>
        <location filename="../../searchbar.cpp" line="56"/>
        <location filename="../../searchbar.cpp" line="61"/>
        <source>Previous</source>
        <translation>上一个</translation>
    </message>
</context>
<context>
    <name>FeatherPad::SessionDialog</name>
    <message>
        <location filename="../../sessionDialog.ui" line="14"/>
        <source>Session Manager</source>
        <translation>会话管理器</translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="101"/>
        <location filename="../../sessionDialog.ui" line="267"/>
        <source>&amp;Remove</source>
        <translation>移除(&amp;R)</translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="33"/>
        <source>&lt;b&gt;Save/Restore Session&lt;/b&gt;</source>
        <translation>&lt;b&gt;保存/恢复会话&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="56"/>
        <source>Filter...</source>
        <translation>过滤器...</translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="69"/>
        <source>Open the selected session(s).</source>
        <translation>打开选中的会话。</translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="72"/>
        <location filename="../../sessionDialog.ui" line="272"/>
        <source>&amp;Open</source>
        <translation>打开(&amp;O)</translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="98"/>
        <location filename="../../sessionDialog.ui" line="108"/>
        <source>Del</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="115"/>
        <location filename="../../sessionDialog.ui" line="125"/>
        <source>Ctrl+Del</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="159"/>
        <source>By default, all files that are opened in all
windows will be included in the saved session.</source>
        <translation>默认情况下，已保存的会话
包含所有已打开的文件。</translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="163"/>
        <source>Save only from this &amp;window</source>
        <translation>只从本窗口保存(&amp;W)</translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="177"/>
        <source>&lt;b&gt;Warning&lt;/b&gt;</source>
        <translation>&lt;b&gt;警告&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="223"/>
        <location filename="../../session.cpp" line="303"/>
        <source>&amp;Yes</source>
        <translation>是(&amp;Y)</translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="230"/>
        <source>&amp;No</source>
        <translation>否(&amp;N)</translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="280"/>
        <source>Re&amp;name</source>
        <translation>重命名(&amp;N)</translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="118"/>
        <source>Remove &amp;All</source>
        <translation>移除所有(&amp;A)</translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="257"/>
        <source>&amp;Close</source>
        <translation>关闭(&amp;C)</translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="135"/>
        <source>Save the curent session under the given title.</source>
        <translation>以指定标题保存会话。</translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="138"/>
        <source>&amp;Save</source>
        <translation>保存(&amp;S)</translation>
    </message>
    <message>
        <location filename="../../sessionDialog.ui" line="149"/>
        <source>Type a name to save session</source>
        <translation>输入名称以保存会话</translation>
    </message>
    <message>
        <location filename="../../session.cpp" line="148"/>
        <source>Nothing saved.&lt;br&gt;No file was opened.</source>
        <translation>未保存任何文件。&lt;br&gt;未打开任何文件。</translation>
    </message>
    <message>
        <location filename="../../session.cpp" line="240"/>
        <source>No file exists or can be opened.</source>
        <translation>没有可以打开的文件。</translation>
    </message>
    <message>
        <location filename="../../session.cpp" line="246"/>
        <source>Not all files exist or can be opened.</source>
        <translation>某些文件不存在或无法打开。</translation>
    </message>
    <message>
        <location filename="../../session.cpp" line="289"/>
        <source>&amp;OK</source>
        <translation>确定(&amp;O)</translation>
    </message>
    <message>
        <location filename="../../session.cpp" line="308"/>
        <source>Do you really want to remove all saved sessions?</source>
        <translation>您确定要移除所有已保存的会话吗？</translation>
    </message>
    <message>
        <location filename="../../session.cpp" line="314"/>
        <source>Do you really want to remove the selected sessions?</source>
        <translation>您确定要移除选中的会话吗？</translation>
    </message>
    <message>
        <location filename="../../session.cpp" line="316"/>
        <source>Do you really want to remove the selected session?</source>
        <translation>您确定要移除选中的会话吗？</translation>
    </message>
    <message>
        <location filename="../../session.cpp" line="321"/>
        <source>A session with the same name exists.&lt;br&gt;Do you want to overwrite it?</source>
        <translation>已有同名会话。&lt;br&gt;是否覆盖？</translation>
    </message>
</context>
<context>
    <name>FeatherPad::SidePane</name>
    <message>
        <location filename="../../sidepane.cpp" line="95"/>
        <source>Filter...</source>
        <translation>过滤器...</translation>
    </message>
</context>
<context>
    <name>FeatherPad::TextEdit</name>
    <message>
        <location filename="../../textedit.cpp" line="1196"/>
        <source>Open Link</source>
        <translation>打开链接</translation>
    </message>
    <message>
        <location filename="../../textedit.cpp" line="1206"/>
        <source>Copy Link</source>
        <translation>复制链接</translation>
    </message>
    <message>
        <location filename="../../textedit.cpp" line="1217"/>
        <source>Paste Date and Time</source>
        <translation>粘贴日期与时间</translation>
    </message>
</context>
<context>
    <name>FeatherPad::WarningBar</name>
    <message>
        <location filename="../../warningbar.h" line="43"/>
        <location filename="../../warningbar.h" line="52"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
</context>
</TS>
