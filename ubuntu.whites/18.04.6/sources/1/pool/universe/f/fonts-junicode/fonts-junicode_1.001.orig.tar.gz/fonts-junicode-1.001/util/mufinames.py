import fontforge

mufilist = ((0xF761,'a.sc'),(0xF762,'b.sc'),(0xF763,'c.sc'),
            (0xF764,'d.sc'),(0xF765,'e.sc'),(0xF766,'f.sc'),
            (0xF767,'g.sc'),(0xF768,'h.sc'),(0xF769,'i.sc'),
            (0xF76A,'j.sc'),(0xF76B,'k.sc'),(0xF76C,'l.sc'),
            (0xF76D,'m.sc'),(0xF76E,'n.sc'),(0xF76F,'o.sc'),
            (0xF770,'p.sc'),(0xF771,'q.sc'),(0xF772,'r.sc'),
            (0xF773,'s.sc'),(0xF774,'t.sc'),(0xF775,'u.sc'),
            (0xF776,'v.sc'),(0xF777,'w.sc'),(0xF778,'x.sc'),
            (0xF779,'y.sc'),(0xF77A,'z.sc'),(0xF7E0,'agrave.sc'),
            (0xF7E1,'aacute.sc'),(0xF7E2,'acircumflex.sc'),(0xF7E3,'atilde.sc'),
            (0xF7E4,'adieresis.sc'),(0xF7E5,'aring.sc'),(0xF7E6,'ae.sc'),
            (0xF7E7,'ccedilla.sc'),(0xF7E8,'egrave.sc'),(0xF7E9,'eacute.sc'),
            (0xF7EA,'ecircumflex.sc'),(0xF7EB,'edieresis.sc'),(0xF7EC,'igrave.sc'),
            (0xF7ED,'iacute.sc'),(0xF7EE,'icircumflex.sc'),(0xF7EF,'idieresis.sc'),
            (0xF7F0,'eth.sc'),(0xF7F1,'ntilde.sc'),(0xF7F2,'ograve.sc'),
            (0xF7F3,'oacute.sc'),(0xF7F4,'ocircumflex.sc'),(0xF7F5,'otilde.sc'),
            (0xF7F6,'odieresis.sc'),(0xF7F8,'oslash.sc'),(0xF7F9,'ugrave.sc'),
            (0xF7FA,'uacute.sc'),(0xF7FB,'ucircumflex.sc'),(0xF7FC,'udieresis.sc'),
            (0xF7FD,'yacute.sc'),(0xF7FE,'thorn.sc'),(0xF7FF,'ydieresis.sc'),
            (0xEBD0,'uni00620307.sc'),(0xEBD2,'uni00640307.sc'),
            (0xEBD7,'uni00660307.sc'),(0xEF20,'uni00670307.sc'),
            (0xEBDA,'uni00680307.sc'),(0xEBDB,'uni006B0307.sc'),
            (0xEBDC,'uni006C0307.sc'),(0xEBDD,'uni006D0307.sc'),
            (0xEF21,'uni006E0307.sc'),(0xEBCF,'uni00700307.sc'),
            (0xEF22,'uni00720307.sc'),(0xEF23,'uni00730307.sc'),
            (0xEF24,'uni00740307.sc'),(0xEF25,'uni00620323.sc'),
            (0xEF26,'uni00640323.sc'),(0xEF27,'uni00670323.sc'),
            (0xEF28,'uni006C0323.sc'),(0xEF29,'uni006D0323.sc'),
            (0xEF2A,'uni006E0323.sc'),(0xEF2B,'uni00720323.sc'),
            (0xEF2C,'uni00730323.sc'),(0xEF2D,'uni00740323.sc'),
            (0xEEE0,'a.enlarged'),(0xEAF0,'aacute.enlarged'),
            (0xEFDF,'uniA733.enlarged'),(0xEAF1,'ae.enlarged'),
            (0xEFDE,'uniA735.enlarged'),(0xEFDE,'uniA735.alt1'),(0xEEE1,'b.enlarged'),
            (0xEEE2,'c.enlarged'),(0xEEE3,'d.enlarged'),
            (0xEEE4,'uniA77A.enlarged'),(0xEEE5,'eth.enlarged'),
            (0xEEE6,'e.enlarged'),(0xEAF3,'eogonek.enlarged'),
            (0xEEE7,'f.enlarged'),(0xEEFF,'uniA77C.enlarged'),
            (0xEEE8,'g.enlarged'),(0xEEE9,'h.enlarged'),
            (0xEEEA,'i.enlarged'),(0xEEFD,'dotlessi.enlarged'),
            (0xEEEB,'j.enlarged'),(0xEEFE,'dotlessj.enlarged'),
            (0xEEEC,'k.enlarged'),(0xEEED,'l.enlarged'),
            (0xEEEE,'m.enlarged'),(0xEEEF,'n.enlarged'),
            (0xEEF0,'o.enlarged'),(0xEFDD,'oe.enlarged'),
            (0xEEF1,'p.enlarged'),(0xEEF2,'q.enlarged'),
            (0xEEF3,'r.enlarged'),(0xEEF4,'s.enlarged'),
            (0xEEDF,'longs.enlarged'),(0xEEF5,'t.enlarged'),
            (0xEEF7,'u.enlarged'),(0xEEF8,'v.enlarged'),
            (0xEEF9,'w.enlarged'),(0xEEFA,'x.enlarged'),
            (0xEEFB,'y.enlarged'),(0xEEFC,'z.enlarged'),
            (0xEEF6,'thorn.enlarged'),(0xEFA0,'uniA733.alt'),
            (0xF204,'ae.alt1'),(0xEFAE,'AE.alt1'),
            (0xEFA1,'ae.alt2'),(0xF205,'uniA734.alt'),
            (0xF206,'uniA735.alt2'),(0xEFA2,'uniA739.alt'),
            (0xEFA3,'a_f'),(0xEFA4,'a_uniA77C'),(0xEFA5,'a_g'),
            (0xEFA6,'a_l'),(0xEFA7,'a_n'),(0xEFA8,'a_n.alt'),
            (0xEFA9,'a_p'),(0xEFAA,'a_r'),(0xEFAB,'a_r.alt'),
            (0xEFAC,'a_thorn'),(0xEEC2,'b_b'),(0xEEC3,'b_g'),
            (0xEEC4,'c_k'),(0xEEC5,'c_t'),(0xEEC6,'uniA77A_uniA77A'),
            (0xEEC7,'e_y'),(0xEEC8,'f_adieresis'),(0xE18A,'f_j'),
            (0xF1BC,'f_odieresis'),(0xEECA,'f_r'),(0xEECB,'f_t'),
            (0xEECC,'f_udieresis'),(0xEECD,'f_y'),(0xEECE,'f_f_t'),
            (0xEECF,'f_f_y'),(0xEED0,'f_t_y'),(0xEED1,'g_g'),
            (0xEED2,'g_d'),(0xEED3,'g_uniA77A'),(0xEED4,'g_eth'),
            (0xEEDE,'g_o'),(0xEAD2,'g_p'),(0xEAD0,'g_r'),
            (0xEAD1,'q_v'),(0xE8C3,'h_r'),(0xE8C2,'H_r'),
            (0xE8C5,'k_r'),(0xF4F9,'l_l'),(0xEED5,'n_longs'),
            (0xEFAD,'o_c'),(0xEEDD,'P_P'),(0xEED6,'p_p'),
            (0xEED7,'uniA753_p'),(0xEBA0,'longs_adieresis'),
            (0xF4FA,'longs_c_h'),(0xE1A7,'longs_h'),(0xE1A8,'longs_i'),
            (0xF4FB,'longs_j'),(0xE1A9,'longs_k'),(0xE1AA,'longs_l'),
            (0xEBA4,'longs_odieresis'),(0xEBA5,'longs_p'),
            (0xF4FD,'longs_s'),(0xE1AB,'longs_longs'),(0xE1AC,'longs_longs_i'),
            (0xF4FE,'longs_longs_k'),(0xE1AD,'longs_longs_l'),
            (0xF4FF,'longs_longs_t'),(0xEBA9,'longs_t_i'),
            (0xEBAA,'longs_t_r'),(0xEBAB,'longs_udieresis'),
            (0xEBAC,'longs_v'),(0xEADA,'longs_t'),
            (0xEED8,'t_r'),(0xEED9,'t_t'),(0xEEDA,'uniA787_uniA787'),
            (0xEEDB,'t_y'),(0xEEDC,'t_z'),(0xE8C1,'thorn_r'))

currentfont = fontforge.open("Junicode-Regular.sfd")

def exists(g):
    try:
        l = len(currentfont[g].foreground)
        return True
    except TypeError:
        return False

def renameGlyph(e,n):
    if exists(e):
        currentfont[e].glyphname = n

for encoding, gname in mufilist:
    renameGlyph(encoding,gname)

currentfont.save("newfont.sfd")
