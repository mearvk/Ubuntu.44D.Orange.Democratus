.global foo
foo:
