.global bar
bar:
