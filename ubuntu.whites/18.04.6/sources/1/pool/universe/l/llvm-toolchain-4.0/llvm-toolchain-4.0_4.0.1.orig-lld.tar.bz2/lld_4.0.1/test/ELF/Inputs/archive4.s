.quad bar
