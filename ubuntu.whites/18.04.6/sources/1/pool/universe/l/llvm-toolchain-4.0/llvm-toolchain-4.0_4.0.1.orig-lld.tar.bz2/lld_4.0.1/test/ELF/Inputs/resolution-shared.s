        .global foo
foo:
