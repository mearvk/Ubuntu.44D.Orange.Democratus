.globl bar
bar:
