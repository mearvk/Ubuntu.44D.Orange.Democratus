.global und
und:
