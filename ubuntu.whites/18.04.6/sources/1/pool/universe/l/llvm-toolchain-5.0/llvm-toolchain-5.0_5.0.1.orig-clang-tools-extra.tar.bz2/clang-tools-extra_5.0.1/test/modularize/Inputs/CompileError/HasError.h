typedef WithoutDep BadType;

