import "src/module.prefix";
import "src/ngCookies/cookies.js";
import "src/ngCookies/cookieStore.js";
import "src/ngCookies/cookieWriter.js";
import "src/module.suffix";
