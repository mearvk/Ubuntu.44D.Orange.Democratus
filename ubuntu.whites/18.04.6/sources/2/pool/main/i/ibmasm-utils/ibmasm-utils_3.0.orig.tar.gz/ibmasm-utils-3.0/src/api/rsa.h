
/*
 * This software may be used and distributed according to the terms
 * of the Lesser GNU Public License, incorporated herein by reference
 *
 * Copyright (C) IBM Corporation, 2004
 *
 * Author: Max Asb�ck <amax@us.ibm.com>
 */

#ifndef __ibmrsa_h__
#define __ibmrsa_h__

/* File names provided by the ibmasmfs file system */
#define RSA_NAME_SIZE   1024
#define RSA_COMMAND     "command"
#define RSA_EVENT       "event"
#define RSA_HEARTBEAT   "reverse_heartbeat"

#define IBMASM_EVENT_MAX_SIZE	2048u

#endif /* __ibmrsa_h__ */
