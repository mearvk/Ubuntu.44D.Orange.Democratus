/* Copyright (C) 1998-99 Martin Baulig
   This file is part of LibGTop 1.0.

   Contributed by Martin Baulig <martin@home-of-linux.org>, April 1998.

   LibGTop is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License,
   or (at your option) any later version.

   LibGTop is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
   for more details.

   You should have received a copy of the GNU General Public License
   along with LibGTop; see the file COPYING. If not, write to the
   Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.
*/

#include <config.h>
#include <sys/systemcfg.h>

#include <glibtop.h>
#include <glibtop/open.h>
#include <glibtop/close.h>

void
glibtop_open_s (glibtop *server,
		const char *program_name,
		const unsigned long features,
		const unsigned flags)
{
	server->ncpu = _system_configuration.ncpus;

	if (server->ncpu == 1)
	{
		server->ncpu = 0; /* means single-processor, see glibtop.h */
	}
}

void
glibtop_close_s (glibtop *server)
{ }
