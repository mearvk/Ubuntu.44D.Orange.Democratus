#include "tc-rand.c"
