#include "tc-strquote.c"
