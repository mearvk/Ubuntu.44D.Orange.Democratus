
/* nautilus-preferences-window.h - Function to show the nautilus preference
   window.

   Copyright (C) 2002 Jan Arne Petersen
   Copyright (C) 2016 Carlos Soriano <csoriano@gnome.org>

   The Gnome Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.

   The Gnome Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with the Gnome Library; see the file COPYING.LIB.  If not,
   see <http://www.gnu.org/licenses/>.

   Authors: Jan Arne Petersen <jpetersen@uni-bonn.de>
*/

#ifndef NAUTILUS_PREFERENCES_WINDOW_H
#define NAUTILUS_PREFERENCES_WINDOW_H

#include <glib-object.h>
#include <gtk/gtk.h>

G_BEGIN_DECLS

void nautilus_preferences_window_show(GtkWindow *window);

G_END_DECLS

#endif /* NAUTILUS_PREFERENCES_WINDOW_H */
