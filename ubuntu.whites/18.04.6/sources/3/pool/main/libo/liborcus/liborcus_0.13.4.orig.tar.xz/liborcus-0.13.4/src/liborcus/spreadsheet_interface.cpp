/* -*- Mode: C++; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */
/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

#include "orcus/spreadsheet/import_interface.hpp"
#include "orcus/spreadsheet/import_interface_pivot.hpp"
#include "orcus/spreadsheet/import_interface_view.hpp"
#include "orcus/spreadsheet/export_interface.hpp"

namespace orcus { namespace spreadsheet { namespace iface {

import_sheet_view::~import_sheet_view() {}

import_pivot_cache_definition::~import_pivot_cache_definition() {}

import_pivot_cache_field_group::~import_pivot_cache_field_group() {}

import_pivot_cache_records::~import_pivot_cache_records() {}

import_shared_strings::~import_shared_strings() {}

import_styles::~import_styles() {}

import_sheet_properties::~import_sheet_properties() {}

import_named_expression::~import_named_expression() {}

import_data_table::~import_data_table() {}

import_auto_filter::~import_auto_filter() {}

import_table::~import_table() {}

import_conditional_format::~import_conditional_format() {}

import_auto_filter* import_table::get_auto_filter()
{
    return nullptr;
}

import_sheet::~import_sheet() {}

import_sheet_view* import_sheet::get_sheet_view()
{
    return nullptr;
}

import_sheet_properties* import_sheet::get_sheet_properties()
{
    return nullptr;
}

import_data_table* import_sheet::get_data_table()
{
    return nullptr;
}

import_auto_filter* import_sheet::get_auto_filter()
{
    return nullptr;
}

import_table* import_sheet::get_table()
{
    return nullptr;
}

import_conditional_format* import_sheet::get_conditional_format()
{
    return nullptr;
}

import_named_expression* import_sheet::get_named_expression()
{
    return nullptr;
}

import_global_settings::~import_global_settings() {}

import_reference_resolver::~import_reference_resolver() {}

import_factory::~import_factory() {}

import_global_settings* import_factory::get_global_settings()
{
    return nullptr;
}

import_shared_strings* import_factory::get_shared_strings()
{
    return nullptr;
}

import_named_expression* import_factory::get_named_expression()
{
    return nullptr;
}

import_styles* import_factory::get_styles()
{
    return nullptr;
}

import_reference_resolver* import_factory::get_reference_resolver()
{
    return nullptr;
}

import_pivot_cache_definition* import_factory::create_pivot_cache_definition(
        orcus::spreadsheet::pivot_cache_id_t cache_id)
{
    return nullptr;
}

import_pivot_cache_records* import_factory::create_pivot_cache_records(
        orcus::spreadsheet::pivot_cache_id_t cache_id)
{
    return nullptr;
}

export_sheet::~export_sheet() {}

export_factory::~export_factory() {}

}}}

/* vim:set shiftwidth=4 softtabstop=4 expandtab: */
