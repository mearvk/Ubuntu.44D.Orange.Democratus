TEMPLATE = subdirs
SUBDIRS += svg 
