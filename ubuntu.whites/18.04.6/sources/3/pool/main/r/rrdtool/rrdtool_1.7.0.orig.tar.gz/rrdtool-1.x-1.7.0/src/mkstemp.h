int mkstemp(char *tmpl);
