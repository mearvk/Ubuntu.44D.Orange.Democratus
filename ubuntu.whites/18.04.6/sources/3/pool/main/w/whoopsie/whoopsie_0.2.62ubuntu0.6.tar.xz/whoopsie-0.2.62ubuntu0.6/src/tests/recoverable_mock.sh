#!/bin/bash

echo -n $@ > recoverable_mock.cmdline
cat /dev/stdin > recoverable_mock.contents
