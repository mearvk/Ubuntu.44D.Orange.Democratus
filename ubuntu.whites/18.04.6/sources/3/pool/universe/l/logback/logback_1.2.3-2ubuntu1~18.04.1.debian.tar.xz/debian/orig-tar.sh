#!/bin/sh -e

# $2 = version
# $3 = file
DIR=logback_$2
TAR=../logback_$2.orig.tar.xz

# clean up the upstream tarball
tar xzf $3
rm $3
mv logback-$2 $DIR
XZ_OPT=--best tar cJf $TAR -X debian/orig-tar.exclude $DIR
rm -rf $DIR

# move to directory 'tarballs'
if [ -r .svn/deb-layout ]; then
  . .svn/deb-layout
  mv $3 $origDir
  echo "moved $3 to $origDir"
fi
