☃
% die;♥
☃
