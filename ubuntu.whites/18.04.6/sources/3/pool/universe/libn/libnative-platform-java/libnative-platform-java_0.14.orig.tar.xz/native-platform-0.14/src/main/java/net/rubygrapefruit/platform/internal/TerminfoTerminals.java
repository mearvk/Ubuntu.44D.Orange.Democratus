/*
 * Copyright 2012 Adam Murdoch
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package net.rubygrapefruit.platform.internal;

import net.rubygrapefruit.platform.Terminals;
import net.rubygrapefruit.platform.internal.jni.PosixTerminalFunctions;

import java.io.PrintStream;

public class TerminfoTerminals extends AbstractTerminals {
    public boolean isTerminal(Output output) {
        return PosixTerminalFunctions.isatty(output.ordinal());
    }

    @Override
    protected AbstractTerminal createTerminal(Output output) {
        PrintStream stream = output == Terminals.Output.Stdout ? System.out : System.err;
        return new WrapperTerminal(stream, new TerminfoTerminal(output));
    }
}
