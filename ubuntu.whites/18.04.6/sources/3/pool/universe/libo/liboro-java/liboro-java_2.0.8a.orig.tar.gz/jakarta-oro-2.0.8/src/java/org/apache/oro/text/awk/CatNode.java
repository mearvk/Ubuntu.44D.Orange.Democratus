/*
 * $Id: CatNode.java,v 1.7 2003/11/07 20:16:24 dfs Exp $
 *
 * ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2000 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation", "Jakarta-Oro" 
 *    must not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache" 
 *    or "Jakarta-Oro", nor may "Apache" or "Jakarta-Oro" appear in their 
 *    name, without prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */


package org.apache.oro.text.awk;

import java.util.*;

/**
 * @version @version@
 * @since 1.0
 */
final class CatNode extends SyntaxNode {
  SyntaxNode _left, _right;

  boolean _nullable() {
    return (_left._nullable() && _right._nullable());
  }

  BitSet _firstPosition() {
    if(_left._nullable()){
      BitSet ls, rs, bs;

      ls = _left._firstPosition();
      rs = _right._firstPosition();
      bs = new BitSet(Math.max(ls.size(), rs.size()));
      bs.or(rs);
      bs.or(ls);

      return bs;
    }

    return _left._firstPosition();
  }

  BitSet _lastPosition()  {
    if(_right._nullable()) {
      BitSet ls, rs, bs;

      ls = _left._lastPosition();
      rs = _right._lastPosition();
      bs = new BitSet(Math.max(ls.size(), rs.size()));
      bs.or(rs);
      bs.or(ls);

      return bs;
    }

    return _right._lastPosition();
  }


  void _followPosition(BitSet[] follow, SyntaxNode[] nodes)  {
    int size;
    BitSet leftLast, rightFirst;

    _left._followPosition(follow, nodes);
    _right._followPosition(follow, nodes);

    leftLast   = _left._lastPosition();
    rightFirst = _right._firstPosition();

    size = leftLast.size();
    while(0 < size--)
      if(leftLast.get(size))
	follow[size].or(rightFirst);
  }

  SyntaxNode _clone(int pos[]) {
    CatNode node;

    node        = new CatNode();
    node._left  = _left._clone(pos);
    node._right = _right._clone(pos);

    return node;
  }
}
