#!/bin/bash

# output version
bash printinfo.sh

make clean > /dev/null

echo "checking..."
./helper.pl --check-source --check-makefiles --check-defines|| exit 1

exit 0

# ref:         HEAD -> master, tag: v1.18.1
# git commit:  e08fd8630f9d9771226466877064055ee7e863d0
# commit time: 2018-01-22 11:02:57 +0100
