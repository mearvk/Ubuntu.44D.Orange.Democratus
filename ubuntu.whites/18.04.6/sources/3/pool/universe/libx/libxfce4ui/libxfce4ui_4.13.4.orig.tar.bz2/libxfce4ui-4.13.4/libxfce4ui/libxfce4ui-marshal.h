/* This file is generated, all changes will be lost */
#ifndef ___LIBXFCE4UI_MARSHAL_MARSHAL_H__
#define ___LIBXFCE4UI_MARSHAL_MARSHAL_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* BOOLEAN:VOID (./libxfce4ui-marshal.list:1) */
extern
void _libxfce4ui_marshal_BOOLEAN__VOID (GClosure     *closure,
                                        GValue       *return_value,
                                        guint         n_param_values,
                                        const GValue *param_values,
                                        gpointer      invocation_hint,
                                        gpointer      marshal_data);


G_END_DECLS

#endif /* ___LIBXFCE4UI_MARSHAL_MARSHAL_H__ */
