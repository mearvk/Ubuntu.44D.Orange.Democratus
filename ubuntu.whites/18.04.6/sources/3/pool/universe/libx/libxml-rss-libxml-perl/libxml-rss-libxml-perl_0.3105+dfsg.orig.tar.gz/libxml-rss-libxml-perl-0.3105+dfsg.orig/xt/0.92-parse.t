use strict;
use Test::More;

use constant RSS_VERSION       => "0.92";
use constant RSS_CHANNEL_TITLE => "Example 0.92 Channel";

use constant RSS_DOCUMENT      => qq(<?xml version="1.0"?>
<rss version="0.92">
  <channel>
    <title>Example 0.92 Channel</title>
    <link>http://example.com</link>
    <description>To lead by example</description>
  </channel>
  <item>
     <title>News for September the Second</title>
     <link>http://example.com/2002/09/02</link>
     <description>other things happened today</description>
  </item>
  <item>
     <title>News for September the First</title>
     <link>http://example.com/2002/09/01</link>
     <description>something happened today</description>
  </item>
</rss>);

use_ok("XML::RSS::LibXML");

my $xml = XML::RSS::LibXML->new();
isa_ok($xml,"XML::RSS::LibXML");

eval { $xml->parse(RSS_DOCUMENT); };
is($@,'',"Parsed RSS feed");

cmp_ok($xml->{'_internal'}->{'version'},
       "eq",
       RSS_VERSION,
       "Is RSS version ".RSS_VERSION);

cmp_ok($xml->{channel}->{'title'},
       "eq",
       RSS_CHANNEL_TITLE,
       "Feed title is ".RSS_CHANNEL_TITLE);

cmp_ok(ref($xml->{items}),
       "eq",
       "ARRAY",
       "\$xml->{items} is an ARRAY ref");

my $ok = 1;

foreach my $item (@{$xml->{items}}) {

  foreach my $el ("title","link","description") {
    if (! exists $item->{$el}) {
      $ok = 0;
      last;
    }
  }

  last if (! $ok);
}

ok($ok,"All items have title,link and description elements");

done_testing();

__END__

=head1 NAME

0.92-parse.t - tests for parsing RSS 0.92 data with XML::RSS::LibXML.pm

=head1 SYNOPSIS

 use Test::Harness qw (runtests);
 runtests (./XML-RSS/t/*.t);

=head1 DESCRIPTION

Tests for parsing RSS 0.92 data with XML::RSS::LibXML.pm

=head1 VERSION

$Revision: 1.2 $

=head1 DATE

$Date: 2002/11/19 23:58:03 $

=head1 AUTHOR

Aaron Straup Cope

=head1 SEE ALSO

http://my.netscape.com/publish/formats/rss-spec-0.92.html

http://backend.userland.com/rss092

=cut
