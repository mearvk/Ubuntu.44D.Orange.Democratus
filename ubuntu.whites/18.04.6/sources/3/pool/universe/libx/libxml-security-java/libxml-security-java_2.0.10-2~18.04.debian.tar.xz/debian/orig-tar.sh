#!/bin/sh -e

VERSION=$2
TAR=../libxml-security-java_$VERSION.orig.tar.xz
DIR=libxml-security-java-$VERSION
TAG="xmlsec-$VERSION"

svn export https://svn.apache.org/repos/asf/santuario/xml-security-java/tags/${TAG}/ $DIR
tar -c -J -f $TAR --exclude '*.jar' --exclude 'rfc*.txt' $DIR
rm -rf $DIR ../$TAG
