package org.apache.maven.shared.artifact.filter;

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

import java.util.List;

/**
 * Filter to include artifacts from a list of patterns. <code>AbstractStrictPatternArtifactFilter</code> describes the
 * artifact pattern syntax.
 * 
 * @author <a href="mailto:markhobson@gmail.com">Mark Hobson</a>
 * @version $Id: StrictPatternIncludesArtifactFilter.java 1400653 2012-10-21 14:18:01Z hboutemy $
 * @see AbstractStrictPatternArtifactFilter
 * @see PatternIncludesArtifactFilter
 */
public class StrictPatternIncludesArtifactFilter
    extends AbstractStrictPatternArtifactFilter
{
    /**
     * Creates a new filter that includes artifacts that match the specified patterns.
     * 
     * @param patterns
     *            the list of artifact patterns to match, as described above
     */
    public StrictPatternIncludesArtifactFilter( List<String> patterns )
    {
        super( patterns, true );
    }
}
