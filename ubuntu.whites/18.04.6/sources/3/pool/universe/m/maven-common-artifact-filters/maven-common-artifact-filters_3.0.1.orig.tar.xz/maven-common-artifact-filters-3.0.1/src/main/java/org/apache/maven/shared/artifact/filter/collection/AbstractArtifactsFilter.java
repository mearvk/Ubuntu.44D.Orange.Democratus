package org.apache.maven.shared.artifact.filter.collection;

/* 
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.    
 */

import java.util.LinkedHashSet;
import java.util.Set;

import org.apache.maven.artifact.Artifact;

/**
 * @author <a href="mailto:brianf@apache.org">Brian Fox</a>
 * @version $Id: AbstractArtifactsFilter.java 1716978 2015-11-28 14:47:04Z khmarbaise $
 */
public abstract class AbstractArtifactsFilter
    implements ArtifactsFilter
{
    /**
     * @param artifact {@link Artifact}
     * @return {@code true} if artifact is includes {@code false} otherwise.
     * @throws ArtifactFilterException when filtering fails
     */
    public boolean isArtifactIncluded( Artifact artifact )
        throws ArtifactFilterException
    {
        Set<Artifact> set = new LinkedHashSet<Artifact>();
        set.add( artifact );

        set = filter( set );
        return set.contains( artifact );
    }
}
