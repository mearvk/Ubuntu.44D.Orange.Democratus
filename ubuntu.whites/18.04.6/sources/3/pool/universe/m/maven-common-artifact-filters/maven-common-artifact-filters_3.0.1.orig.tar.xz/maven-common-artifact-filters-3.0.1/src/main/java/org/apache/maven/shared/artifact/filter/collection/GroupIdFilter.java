package org.apache.maven.shared.artifact.filter.collection;

/* 
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.    
 */

import org.apache.maven.artifact.Artifact;

/**
 * Filter on GroupId Name.
 * 
 * @author clove
 * @since 2.0
 * @version $Id: GroupIdFilter.java 1685387 2015-06-14 11:36:28Z rfscholte $
 */
public class GroupIdFilter
    extends AbstractArtifactFeatureFilter
{

    /**
     * Construction will setup the super call with a filtertype of 'GroupId'
     * 
     * @param include comma separated list of groupIds to include, may be {@code null}
     * @param exclude comma separated list of groupIds to exclude, may be {@code null}
     */
    public GroupIdFilter( String include, String exclude )
    {
        super( include, exclude );
    }

    @Override
    protected String getArtifactFeature( Artifact artifact )
    {
        return artifact.getGroupId();
    }

    @Override
    protected boolean compareFeatures( String lhs, String rhs )
    {
        return lhs.startsWith( rhs );
    }

}
