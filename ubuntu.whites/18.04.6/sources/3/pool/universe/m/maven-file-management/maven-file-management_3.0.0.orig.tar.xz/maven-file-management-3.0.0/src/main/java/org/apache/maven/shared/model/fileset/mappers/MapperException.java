package org.apache.maven.shared.model.fileset.mappers;

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

/**
 * Mapper Exception
 *
 * @version $Id: MapperException.java 1721672 2015-12-25 13:18:36Z khmarbaise $
 */
public class MapperException
    extends Exception
{
    static final long serialVersionUID = 20064059145045044L;

    /**
     * Constructor
     *
     * @param message The error message
     * @param cause The root cause of the problem.
     */
    public MapperException( String message, Throwable cause )
    {
        super( message, cause );
    }

    /**
     * Constructor
     *
     * @param message The error message.
     */
    public MapperException( String message )
    {
        super( message );
    }
}
