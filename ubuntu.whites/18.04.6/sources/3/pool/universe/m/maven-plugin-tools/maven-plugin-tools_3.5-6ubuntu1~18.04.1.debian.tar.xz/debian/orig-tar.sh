#!/bin/sh -e

TAR=../maven-plugin-tools_$2.orig.tar.xz
DIR=maven-plugin-tools-$2
TAG=maven-plugin-tools-$2

svn export http://svn.apache.org/repos/asf/maven/plugin-tools/tags/$TAG $DIR
tar -c -J -f $TAR $DIR
rm -rf $DIR ../$TAG

# move to directory 'tarballs'
if [ -r .svn/deb-layout ]; then
  . .svn/deb-layout
  mv $TAR $origDir
  echo "moved $TAR to $origDir"
fi
