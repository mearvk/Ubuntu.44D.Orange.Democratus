package org.apache.maven.tools.plugin.generator;

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

import java.io.File;

import org.codehaus.plexus.util.ReaderFactory;
import org.codehaus.plexus.util.xml.Xpp3DomBuilder;

/**
 * @author <a href="mailto:jason@maven.org">Jason van Zyl </a>
 * @author <a href="mailto:vincent.siveton@gmail.com">Vincent Siveton</a>
 * @version $Id: PluginXdocGeneratorTest.java 821512 2009-10-04 11:22:41Z bentmann $
 */
public class PluginXdocGeneratorTest
    extends AbstractGeneratorTestCase
{

    // inherits tests from base class

    protected void validate( File destinationDirectory )
        throws Exception
    {
        File docFile = new File( destinationDirectory, "testGoal-mojo.xml" );

        // sanity check: is the output well-formed?
        Xpp3DomBuilder.build( ReaderFactory.newXmlReader( docFile ) );
    }

}
