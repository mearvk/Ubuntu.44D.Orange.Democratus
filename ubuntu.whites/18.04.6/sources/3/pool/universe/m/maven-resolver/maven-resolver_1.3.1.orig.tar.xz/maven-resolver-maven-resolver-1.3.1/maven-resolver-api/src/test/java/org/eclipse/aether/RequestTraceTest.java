package org.eclipse.aether;

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * 
 *  http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

import static org.junit.Assert.*;

import org.junit.Test;

/**
 */
public class RequestTraceTest
{

    @Test
    public void testConstructor()
    {
        RequestTrace trace = new RequestTrace( null );
        assertSame( null, trace.getData() );

        trace = new RequestTrace( this );
        assertSame( this, trace.getData() );
    }

    @Test
    public void testParentChaining()
    {
        RequestTrace trace1 = new RequestTrace( null );
        RequestTrace trace2 = trace1.newChild( this );

        assertSame( null, trace1.getParent() );
        assertSame( null, trace1.getData() );
        assertSame( trace1, trace2.getParent() );
        assertSame( this, trace2.getData() );
    }

    @Test
    public void testNewChildRequestTrace()
    {
        RequestTrace trace = RequestTrace.newChild( null, this );
        assertNotNull( trace );
        assertSame( null, trace.getParent() );
        assertSame( this, trace.getData() );
    }

}
