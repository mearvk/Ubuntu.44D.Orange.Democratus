package org.apache.maven.scm.command.tag;

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

import java.util.List;

import org.apache.maven.scm.ScmFile;
import org.apache.maven.scm.ScmResult;

/**
 * @author <a href="mailto:trygvis@inamo.no">Trygve Laugst&oslash;l</a>
 * @author Olivier Lamy
 *
 */
public class TagScmResult
    extends ScmResult
{
    private static final long serialVersionUID = -5068975000282095635L;
    
    private List<ScmFile> taggedFiles;

    public TagScmResult( String commandLine, String providerMessage, String commandOutput, boolean success )
    {
        super( commandLine, providerMessage, commandOutput, success );
    }

    public TagScmResult( String commandLine, List<ScmFile> taggedFiles )
    {
        super( commandLine, null, null, true );

        this.taggedFiles = taggedFiles;
    }

    public TagScmResult( List<ScmFile> taggedFiles, ScmResult result )
    {
        super( result );

        this.taggedFiles = taggedFiles;
    }

    public List<ScmFile> getTaggedFiles()
    {
        return taggedFiles;
    }
}
