/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

def jarFile = new java.util.jar.JarFile( new File( basedir, "target/mshade240-1.0-SNAPSHOT.jar" ) )
try 
{
  assert null != jarFile.getJarEntry( "META-INF/maven/org.apache.maven.plugins.shade.its/mshade240/pom.properties" )
  assert null != jarFile.getJarEntry( "META-INF/maven/org.apache.maven.plugins.shade.its/mshade240/pom.xml" )
  assert null != jarFile.getJarEntry( "META-INF/shade/maven/org.apache.maven/maven-core/pom.properties" )
  assert null != jarFile.getJarEntry( "META-INF/shade/maven/org.apache.maven/maven-core/pom.xml" )

  assert null == jarFile.getJarEntry( "META-INF/shade/maven/org.apache.maven.plugins.shade.its/mshade240/pom.properties" )
  assert null == jarFile.getJarEntry( "META-INF/shade/maven/org.apache.maven.plugins.shade.its/mshade240/pom.xml" )
  assert null == jarFile.getJarEntry( "META-INF/maven/org.apache.maven/maven-core/pom.properties" )
  assert null == jarFile.getJarEntry( "META-INF/maven/org.apache.maven/maven-core/pom.xml" )
}
finally 
{
  jarFile.close()
}
