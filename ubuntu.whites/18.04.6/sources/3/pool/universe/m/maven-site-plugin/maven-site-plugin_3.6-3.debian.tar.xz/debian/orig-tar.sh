#!/bin/sh

set -e

TAR=../maven-site-plugin_$2.orig.tar.xz
DIR=maven-site-plugin-$2
TAG=$(echo maven-site-plugin-$2 | sed -e's,~beta,-beta-,')

svn export http://svn.apache.org/repos/asf/maven/plugins/tags/$TAG $DIR
XZ_OPT=--best tar -c -J -f $TAR $DIR
rm -rf $DIR ../$TAG
