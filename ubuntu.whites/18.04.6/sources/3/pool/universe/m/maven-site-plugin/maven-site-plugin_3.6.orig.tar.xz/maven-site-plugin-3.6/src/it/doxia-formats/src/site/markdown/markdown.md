<!---
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.
-->


Markdown Format works
---------------

But 'quotes' and "double quotes" were stripped from HTML result with DOXIA 1.3:
see [DOXIA-473](https://jira.codehaus.org/browse/DOXIA-473).

<!-- MACRO{toc|fromDepth=1|toDepth=2} -->

### Subsection
