package org.codehaus.modello.model;

/*
 * Copyright (c) 2004, Codehaus.org
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

public class VersionDefinition
{
    private static final String FIELD = "field";
    
    private static final String NAMESPACE = "namespace";
    
    private static final String FIELD_NAMESPACE = "field+namespace";
    
    private String type;

    private String value;

    public String getType()
    {
        return type;
    }

    public void setType( String type )
    {
        this.type = type;
    }

    public String getValue()
    {
        return value;
    }

    public void setValue( String value )
    {
        this.value = value;
    }
    
    /**
     * 
     * @return {@code true} if the versionDefinition can be based on the namespace
     * @since 1.9 
     */
    public boolean isNamespaceType()
    {
        return NAMESPACE.equals( type ) || FIELD_NAMESPACE.equals( type );
    }

    /**
     * 
     * @return {@code true} if the versionDefinition can be based on the field
     * @since 1.9
     */
    public boolean isFieldType()
    {
        return FIELD.equals( type ) || FIELD_NAMESPACE.equals( type );
    }

}
