var empty_template = {};
