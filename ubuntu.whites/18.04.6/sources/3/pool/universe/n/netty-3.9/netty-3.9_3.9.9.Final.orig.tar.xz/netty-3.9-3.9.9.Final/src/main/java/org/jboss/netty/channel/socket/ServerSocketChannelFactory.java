/*
 * Copyright 2012 The Netty Project
 *
 * The Netty Project licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
package org.jboss.netty.channel.socket;

import org.jboss.netty.channel.ChannelFactory;
import org.jboss.netty.channel.ChannelPipeline;
import org.jboss.netty.channel.ServerChannelFactory;

/**
 * A {@link ChannelFactory} which creates a {@link ServerSocketChannel}.
 *
 * @apiviz.has org.jboss.netty.channel.socket.ServerSocketChannel oneway - - creates
 */
public interface ServerSocketChannelFactory extends ServerChannelFactory {
    ServerSocketChannel newChannel(ChannelPipeline pipeline);
}
