/*
 * Copyright 2006-2018 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.objenesis;

/**
 * Exception thrown by Objenesis. It wraps any instantiation exceptions. Note that this exception is
 * runtime to prevent having to catch it.
 * 
 * @author Henri Tremblay
 */
public class ObjenesisException extends RuntimeException {

   private static final long serialVersionUID = -2677230016262426968L;
   
   /**
    * @param msg Error message
    */
   public ObjenesisException(String msg) {
      super(msg);
   }

   /**
    * @param cause Wrapped exception. The message will be the one of the cause.
    */
   public ObjenesisException(Throwable cause) {
      super(cause);
   }

   /**
    * @param msg Error message
    * @param cause Wrapped exception
    */
   public ObjenesisException(String msg, Throwable cause) {
      super(msg, cause);
   }
}
