/*
Copyright (c) 2003-2017 Sony Pictures Imageworks Inc., et al.
All Rights Reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:
* Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions and the following disclaimer in the
  documentation and/or other materials provided with the distribution.
* Neither the name of Sony Pictures Imageworks nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#define OpenColorIOSignature    'ocio'

#define ocioKeySource           'oSrc'
#define ocioKeyConfigName       'oCfN'
#define ocioKeyConfigFileHandle 'oCfH'
#define ocioKeyAction           'oAct'
#define ocioKeyInvert           'oInv'
#define ocioKeyInterpolation    'oInt'
#define ocioKeyInputSpace       'oInp'
#define ocioKeyOutputSpace      'oOut'
#define ocioKeyTransform        'oTrn'
#define ocioKeyDevice           'oDev'

#define typeSource          'tSrc'
#define sourceEnvironment   'sEnv'
#define sourceStandard      'sStd'
#define sourceCustom        'sCus'

#define typeAction          'tAct'
#define actionLUT           'aLUT'
#define actionConvert       'aCvt'
#define actionDisplay       'aDis'

#define typeInterpolation   'tInt'
#define interpNearest       'tNer'
#define interpLinear        'tLin'
#define interpTetrahedral   'tTet'
#define interpBest          'tBst'
