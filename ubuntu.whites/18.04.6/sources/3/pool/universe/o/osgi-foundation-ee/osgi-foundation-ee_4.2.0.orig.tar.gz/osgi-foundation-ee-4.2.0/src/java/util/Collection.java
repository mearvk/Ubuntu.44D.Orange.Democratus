/*
 * $Revision: 6107 $
 *
 * (C) Copyright 2001 Sun Microsystems, Inc.
 * Copyright (c) OSGi Alliance (2001, 2008). All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package java.util;
public abstract interface Collection {
	public abstract boolean add(java.lang.Object var0);
	public abstract boolean addAll(java.util.Collection var0);
	public abstract void clear();
	public abstract boolean contains(java.lang.Object var0);
	public abstract boolean containsAll(java.util.Collection var0);
	public abstract boolean equals(java.lang.Object var0);
	public abstract int hashCode();
	public abstract boolean isEmpty();
	public abstract java.util.Iterator iterator();
	public abstract boolean remove(java.lang.Object var0);
	public abstract boolean removeAll(java.util.Collection var0);
	public abstract boolean retainAll(java.util.Collection var0);
	public abstract int size();
	public abstract java.lang.Object[] toArray();
	public abstract java.lang.Object[] toArray(java.lang.Object[] var0);
}

