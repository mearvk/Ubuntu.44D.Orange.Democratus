One line
