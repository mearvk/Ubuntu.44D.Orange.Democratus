package org.codehaus.plexus.util.xml;

/*
 * Copyright The Codehaus Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.PrintWriter;
import java.io.Writer;

/**
 * @version $Id$
 */
public class CompactXMLWriter
    extends PrettyPrintXMLWriter
{

    public CompactXMLWriter( PrintWriter writer )
    {
        super( writer );
    }

    public CompactXMLWriter( Writer writer )
    {
        super( writer );
    }

    protected void endOfLine()
    {
        // override parent: don't write anything at end of line
    }
}
