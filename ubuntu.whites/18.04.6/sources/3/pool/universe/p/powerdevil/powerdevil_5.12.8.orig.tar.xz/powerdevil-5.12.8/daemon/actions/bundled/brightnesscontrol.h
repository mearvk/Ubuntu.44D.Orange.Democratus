/***************************************************************************
 *   Copyright (C) 2010 by Dario Freddi <drf@kde.org>                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA .        *
 ***************************************************************************/


#ifndef POWERDEVIL_BUNDLEDACTIONS_BRIGHTNESSCONTROL_H
#define POWERDEVIL_BUNDLEDACTIONS_BRIGHTNESSCONTROL_H

#include <powerdevilaction.h>
#include <powerdevilbackendinterface.h>

namespace PowerDevil {
namespace BundledActions {

class BrightnessControl : public PowerDevil::Action
{
    Q_OBJECT
    Q_DISABLE_COPY(BrightnessControl)
    Q_CLASSINFO("D-Bus Interface", "org.kde.Solid.PowerManagement.Actions.BrightnessControl")

public:
    explicit BrightnessControl(QObject* parent);
    virtual ~BrightnessControl() = default;

protected:
    void onProfileUnload() Q_DECL_OVERRIDE;
    void onWakeupFromIdle() Q_DECL_OVERRIDE;
    void onIdleTimeout(int msec) Q_DECL_OVERRIDE;
    void onProfileLoad() Q_DECL_OVERRIDE;
    void triggerImpl(const QVariantMap& args) Q_DECL_OVERRIDE;
    bool isSupported() Q_DECL_OVERRIDE;

public:
    bool loadAction(const KConfigGroup& config) Q_DECL_OVERRIDE;

public Q_SLOTS:
    // DBus export
    void increaseBrightness();
    void decreaseBrightness();
    int brightness() const;
    int brightnessMax() const;
    void setBrightness(int percent);
    void setBrightnessSilent(int percent);

    int brightnessSteps() const;

private Q_SLOTS:
    void onBrightnessChangedFromBackend(const BrightnessLogic::BrightnessInfo &brightnessInfo, BackendInterface::BrightnessControlType type);

Q_SIGNALS:
    void brightnessChanged(int value);
    void brightnessMaxChanged(int valueMax);

private:
    int brightnessPercent(float value) const;

    int m_defaultValue = -1;
    QString m_lastProfile;
    QString m_currentProfile;
};

}

}

#endif // POWERDEVIL_BUNDLEDACTIONS_BRIGHTNESSCONTROL_H
