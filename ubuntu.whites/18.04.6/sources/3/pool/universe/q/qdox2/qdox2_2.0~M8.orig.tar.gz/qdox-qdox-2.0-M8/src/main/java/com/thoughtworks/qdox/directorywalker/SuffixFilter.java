package com.thoughtworks.qdox.directorywalker;

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

import java.io.File;

/**
 * 
 * A file filter based on its suffix
 *
 */
public class SuffixFilter
    implements Filter
{
    private String suffixFilter;

    /**
     * 
     * @param suffixFilter the suffix which will be matched for every file, must not be <code>null</code>
     */
    public SuffixFilter( String suffixFilter )
    {
        this.suffixFilter = suffixFilter;
    }

    /**
     * @param file the file to filter
     * @return <code>true</code> if the file ends with the specified suffix, otherwise <code>false</code>
     */
    public boolean filter( File file )
    {
        return file.getName().endsWith( this.suffixFilter );
    }
}
