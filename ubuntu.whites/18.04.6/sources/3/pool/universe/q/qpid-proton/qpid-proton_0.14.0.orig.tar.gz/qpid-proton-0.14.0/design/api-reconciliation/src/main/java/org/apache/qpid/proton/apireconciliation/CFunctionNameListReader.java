/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 */
package org.apache.qpid.proton.apireconciliation;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;

public class CFunctionNameListReader
{

    public List<String> readCFunctionNames(String fileContainingFunctionNames) throws IOException
    {
        File functionNameFile = new File(fileContainingFunctionNames);
        if (!functionNameFile.canRead())
        {
            throw new FileNotFoundException("File " + functionNameFile + " cannot be found or is not readable.");
        }

        List<String> cFunctionNames = FileUtils.readLines(functionNameFile);
        return cFunctionNames;
    }

}
