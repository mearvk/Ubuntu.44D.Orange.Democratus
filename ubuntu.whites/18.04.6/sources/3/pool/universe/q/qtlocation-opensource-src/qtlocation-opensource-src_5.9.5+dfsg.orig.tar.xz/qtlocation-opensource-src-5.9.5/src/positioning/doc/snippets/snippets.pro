TEMPLATE = subdirs
SUBDIRS += cpp
