SOURCES += main.cpp
