/****************************************************************************
**
** Copyright (C) 2016 Research In Motion
** Contact: https://www.qt.io/licensing/
**
** This file is part of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:LGPL$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** GNU Lesser General Public License Usage
** Alternatively, this file may be used under the terms of the GNU Lesser
** General Public License version 3 as published by the Free Software
** Foundation and appearing in the file LICENSE.LGPL3 included in the
** packaging of this file. Please review the following information to
** ensure the GNU Lesser General Public License version 3 requirements
** will be met: https://www.gnu.org/licenses/lgpl-3.0.html.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU
** General Public License version 2.0 or (at your option) the GNU General
** Public license version 3 or any later version approved by the KDE Free
** Qt Foundation. The licenses are as published by the Free Software
** Foundation and appearing in the file LICENSE.GPL2 and LICENSE.GPL3
** included in the packaging of this file. Please review the following
** information to ensure the GNU General Public License requirements will
** be met: https://www.gnu.org/licenses/gpl-2.0.html and
** https://www.gnu.org/licenses/gpl-3.0.html.
**
** $QT_END_LICENSE$
**
****************************************************************************/
#ifndef BBCAMERAEXPOSURECONTROL_H
#define BBCAMERAEXPOSURECONTROL_H

#include <qcameraexposurecontrol.h>

QT_BEGIN_NAMESPACE

class BbCameraSession;

class BbCameraExposureControl : public QCameraExposureControl
{
    Q_OBJECT
public:
    explicit BbCameraExposureControl(BbCameraSession *session, QObject *parent = 0);

    virtual bool isParameterSupported(ExposureParameter parameter) const Q_DECL_OVERRIDE;
    virtual QVariantList supportedParameterRange(ExposureParameter parameter, bool *continuous) const Q_DECL_OVERRIDE;

    virtual QVariant requestedValue(ExposureParameter parameter) const Q_DECL_OVERRIDE;
    virtual QVariant actualValue(ExposureParameter parameter) const Q_DECL_OVERRIDE;
    virtual bool setValue(ExposureParameter parameter, const QVariant& value) Q_DECL_OVERRIDE;

private Q_SLOTS:
    void statusChanged(QCamera::Status status);

private:
    BbCameraSession *m_session;
    QCameraExposure::ExposureMode m_requestedExposureMode;
};

QT_END_NAMESPACE

#endif
