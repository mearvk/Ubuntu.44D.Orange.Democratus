[playlist]
NumberOfEntries=100
