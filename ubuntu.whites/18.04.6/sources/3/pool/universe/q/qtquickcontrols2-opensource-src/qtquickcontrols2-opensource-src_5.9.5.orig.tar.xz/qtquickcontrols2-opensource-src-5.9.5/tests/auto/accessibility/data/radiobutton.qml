import QtQuick 2.5
import QtQuick.Controls 2.1

RadioButton {
    text: "RadioButton"
}
