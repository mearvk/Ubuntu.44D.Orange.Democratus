/****************************************************************************
**
** Copyright (C) 2017 Lorn Potter.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the QtSensors module of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:GPL-EXCEPT$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU
** General Public License version 3 as published by the Free Software
** Foundation with exceptions as appearing in the file LICENSE.GPL3-EXCEPT
** included in the packaging of this file. Please review the following
** information to ensure the GNU General Public License requirements will
** be met: https://www.gnu.org/licenses/gpl-3.0.html.
**
** $QT_END_LICENSE$
**
****************************************************************************/

#ifndef COLLECTOR_H
#define COLLECTOR_H

#include <QtCore/QObject>
#include <QtCore/QString>
#include <QFile>

class QAccelerometer;
class QOrientationSensor;
class QProximitySensor;
class QIRProximitySensor;
class QTapSensor;

class Collector : public QObject
{
    Q_OBJECT

public:
    explicit Collector(QObject *parent = 0);
    ~Collector();

public slots:
    void startCollecting();
    void stopCollecting();

private Q_SLOTS:
    void accelChanged();
    void orientationChanged();
    void proximityChanged();
    void irProximityChanged();
    void tapChanged();

private:

    QAccelerometer *accel;
    QOrientationSensor *orientation;
    QProximitySensor *proximity;
    QIRProximitySensor *irProx;
    QTapSensor *tapSensor;
    QFile dataFile;

    bool isActive;
    int fileCounter;

    Q_DISABLE_COPY(Collector)
};

#endif // COLLECTOR_H

