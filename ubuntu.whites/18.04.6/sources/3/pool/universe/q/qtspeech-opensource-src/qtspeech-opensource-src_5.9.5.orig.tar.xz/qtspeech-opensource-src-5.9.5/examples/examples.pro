TEMPLATE = subdirs
SUBDIRS = speech
