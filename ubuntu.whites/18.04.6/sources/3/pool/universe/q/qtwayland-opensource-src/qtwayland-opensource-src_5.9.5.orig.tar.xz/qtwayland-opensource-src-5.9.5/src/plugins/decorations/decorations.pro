TEMPLATE = subdirs
SUBDIRS += \
    bradient
