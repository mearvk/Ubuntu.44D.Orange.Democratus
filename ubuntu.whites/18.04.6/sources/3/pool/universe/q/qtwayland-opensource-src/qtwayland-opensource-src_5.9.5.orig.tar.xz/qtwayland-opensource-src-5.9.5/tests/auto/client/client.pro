TEMPLATE=subdirs

SUBDIRS += client
