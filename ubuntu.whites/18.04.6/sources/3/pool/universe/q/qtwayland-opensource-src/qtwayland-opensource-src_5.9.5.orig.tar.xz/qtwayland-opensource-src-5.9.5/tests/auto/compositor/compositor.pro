TEMPLATE=subdirs

SUBDIRS += compositor
