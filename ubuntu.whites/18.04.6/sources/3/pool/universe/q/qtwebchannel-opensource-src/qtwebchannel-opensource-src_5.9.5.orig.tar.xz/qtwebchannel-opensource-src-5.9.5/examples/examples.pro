TEMPLATE = subdirs

SUBDIRS += webchannel
