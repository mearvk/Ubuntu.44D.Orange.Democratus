TEMPLATE = subdirs

SUBDIRS = websockets