TEMPLATE = subdirs
SUBDIRS +=  xmlpatterns
