doc("classExample.xml")
