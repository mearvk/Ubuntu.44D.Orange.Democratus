doc('documentElementWithWS.xml')
