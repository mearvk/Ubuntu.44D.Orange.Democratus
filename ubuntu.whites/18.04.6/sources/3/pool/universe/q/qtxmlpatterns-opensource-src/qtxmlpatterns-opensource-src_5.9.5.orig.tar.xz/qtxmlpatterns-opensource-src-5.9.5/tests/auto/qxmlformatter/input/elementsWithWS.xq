doc('elementsWithWS.xml')
