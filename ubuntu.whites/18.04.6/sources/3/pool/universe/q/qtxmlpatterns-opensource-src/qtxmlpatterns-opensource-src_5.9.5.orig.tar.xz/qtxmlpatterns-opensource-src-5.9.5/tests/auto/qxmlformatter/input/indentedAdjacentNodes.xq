doc("indentedAdjacentNodes.xml")
