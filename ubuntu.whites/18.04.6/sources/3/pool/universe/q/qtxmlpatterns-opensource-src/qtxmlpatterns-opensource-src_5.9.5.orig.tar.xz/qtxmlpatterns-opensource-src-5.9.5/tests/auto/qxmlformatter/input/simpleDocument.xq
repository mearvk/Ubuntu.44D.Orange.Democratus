doc("simpleDocument.xml")
