concat("START ", $externalString, " END")
