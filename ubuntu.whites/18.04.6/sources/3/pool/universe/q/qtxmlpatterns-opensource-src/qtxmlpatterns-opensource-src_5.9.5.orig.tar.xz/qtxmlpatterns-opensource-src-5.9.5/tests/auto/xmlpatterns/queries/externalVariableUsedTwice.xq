$externalVariable, $externalVariable
