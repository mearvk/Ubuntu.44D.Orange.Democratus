tokenize("input", "pattern", "INVALID")
