("someString", tokenize("a,b",","))
