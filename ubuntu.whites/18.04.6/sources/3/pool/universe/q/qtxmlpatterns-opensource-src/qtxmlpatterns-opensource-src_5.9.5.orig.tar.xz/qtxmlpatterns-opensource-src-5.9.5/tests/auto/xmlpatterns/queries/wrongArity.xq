fn:doc()
