shptest(1) -- create some shapefiles for testing
================================================

##SYNOPSIS
`shptest` _num_

##DESCRIPTION
Writes out a shapefile consisting of files test<num>.shp and test<num>.shx in the current directory.  The _num_ argument specifies the type of shapes in the shapefile to create and takes values from:

 * `0`:
 `NullShape`

 * `1`:
 `Point`

 * `2`:
 `PointZ`

 * `3`:
 `PointM`

 * `4`:
 `MultiPoint`

 * `5`:
 `MultiPointZ`

 * `6`:
 `MultiPointM`

 * `7`:
 `Arc`

 * `8`:
 `ArcZ`

 * `9`:
 `ArcM`

 * `10`:
 `Polygon`

 * `11`:
 `PolygonZ`

 * `12`:
 `PolygonM`

 * `13`:
 `MultiPatch`

##EXIT STATUS
 * `0`:
 Successful program execution.

 * `1`:
 Missing argument.

 * `10`:
 Test `_num_' not recognised.

##DIAGNOSTICS
The following diagnostics may be issued on stdout:

Test `_num_' not recognised.

##AUTHORS
Frank Warmerdam (warmerdam@pobox.com) is the maintainer of the shapelib shapefile library.  Joonas Pihlaja (jpihlaja@cc.helsinki.fi) wrote this man page.

##SEE ALSO
`dbfadd`(1), `dbfcat`(1), `dbfcreate`(1), `dbfdump`(1), `dbfinfo`(1), `shpadd`(1), `shpcat`(1), `shpcentrd`(1), `shpcreate`(1), `shpdump`(1), `shpdxf`(1), `shpfix`(1), `shpinfo`(1), `shpproj`(1), `shprewind`(1)

