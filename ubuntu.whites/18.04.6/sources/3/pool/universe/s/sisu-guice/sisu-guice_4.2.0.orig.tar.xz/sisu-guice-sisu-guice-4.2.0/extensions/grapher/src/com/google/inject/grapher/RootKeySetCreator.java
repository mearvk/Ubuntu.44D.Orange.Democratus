/*
 * Copyright (C) 2011 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.inject.grapher;

import com.google.inject.Injector;
import com.google.inject.Key;
import java.util.Set;

/**
 * Creator of the default starting set of keys to graph. These keys and their transitive
 * dependencies will be graphed.
 *
 * @author bojand@google.com (Bojan Djordjevic)
 * @since 4.0
 */
public interface RootKeySetCreator {

  /** Returns the set of starting keys to graph. */
  Set<Key<?>> getRootKeys(Injector injector);
}
