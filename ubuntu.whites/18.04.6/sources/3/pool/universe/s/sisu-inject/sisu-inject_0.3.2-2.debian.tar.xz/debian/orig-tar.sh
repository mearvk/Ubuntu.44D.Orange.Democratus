#!/bin/sh
VERSION=$2
TAR=../sisu-inject_$VERSION.orig.tar.xz
DIR=sisu-inject-$VERSION.orig

mkdir $DIR
tar -xf $3 --strip 2 -C $DIR
rm $3

XZ_OPT=--best tar -cJvf $TAR --exclude '.gitignore' --exclude 'doclava-style' --exclude 'leftovers' --exclude 'bin' $DIR
rm -Rf $DIR
