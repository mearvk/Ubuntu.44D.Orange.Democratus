package org.codehaus.plexus.component.composition;

/*
 * Copyright 2001-2006 Codehaus Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @author <a href="mailto:trygvis@inamo.no">Trygve Laugst&oslash;l</a>
 * @version $Id: ComponentWithSeveralFieldsOfTheSameType.java 4779 2006-11-23 04:09:31Z jvanzyl $
 */
public class ComponentWithSeveralFieldsOfTheSameType
{
    private ComponentE one;

    private ComponentE two;

    public ComponentE getOne()
    {
        return one;
    }

    public ComponentE getTwo()
    {
        return two;
    }
}
