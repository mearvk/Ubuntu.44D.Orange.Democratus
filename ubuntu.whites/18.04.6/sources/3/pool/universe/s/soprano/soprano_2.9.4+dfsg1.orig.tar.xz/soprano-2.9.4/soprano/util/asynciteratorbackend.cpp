/*
 * This file is part of Soprano Project.
 *
 * Copyright (C) 2008 Sebastian Trueg <trueg@kde.org>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public License
 * along with this library; see the file COPYING.LIB.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301, USA.
 */

#include "asynciteratorbackend.h"
#include "asyncmodel_p.h"


Soprano::Util::AsyncIteratorHandle::AsyncIteratorHandle( AsyncModelPrivate* d )
    : m_asyncModelPrivate( d )
{
    if ( d->mode == AsyncModel::SingleThreaded ) {
        m_asyncModelPrivate->addIterator( this );
    }
}


Soprano::Util::AsyncIteratorHandle::~AsyncIteratorHandle()
{
    remove();
}


void Soprano::Util::AsyncIteratorHandle::setModelGone()
{
    m_asyncModelPrivate = 0;
}


void Soprano::Util::AsyncIteratorHandle::remove()
{
    if ( m_asyncModelPrivate ) {
        if ( m_asyncModelPrivate->mode == AsyncModel::SingleThreaded )
            m_asyncModelPrivate->removeIterator( this );
        m_asyncModelPrivate = 0;
    }
}
