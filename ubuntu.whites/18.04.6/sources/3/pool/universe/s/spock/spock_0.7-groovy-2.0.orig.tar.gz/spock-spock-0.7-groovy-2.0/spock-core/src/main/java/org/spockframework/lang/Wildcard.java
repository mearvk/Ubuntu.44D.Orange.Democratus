/*
 * Copyright 2011 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.spockframework.lang;

import java.util.AbstractList;

// make it List<Object> rather than List<SpreadWildcard>
// because IDE type inference might like this better
public class Wildcard extends AbstractList<Object> {
  public static final Wildcard INSTANCE = new Wildcard();

  private Wildcard() {}

  @Override
  public Object get(int index) {
    if (index != 0) throw new IndexOutOfBoundsException("Wildcard.INSTANCE only has a single element");
    return SpreadWildcard.INSTANCE;
  }

  @Override
  public int size() {
    return 1;
  }

  @Override
  public String toString() {
    return "_"; // both compiler and runtime sometimes need String representation
  }
}


