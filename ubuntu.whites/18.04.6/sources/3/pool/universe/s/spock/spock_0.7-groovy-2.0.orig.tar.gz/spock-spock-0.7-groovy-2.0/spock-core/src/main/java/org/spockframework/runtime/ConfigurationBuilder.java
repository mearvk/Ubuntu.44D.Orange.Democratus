/*
 * Copyright 2010 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.spockframework.runtime;

import java.util.Arrays;
import java.util.List;

import org.spockframework.builder.*;

public class ConfigurationBuilder {
  private final GestaltBuilder gestaltBuilder = new GestaltBuilder();
  private final List<ISlotFactory> slotFactories =
      Arrays.asList(new SetterSlotFactory(), new AddSlotFactory(), new CollectionSlotFactory());
  
  public void build(List<Object> configurations, DelegatingScript configScript) {
    IBlueprint blueprint = new DelegatingScriptBlueprint(configScript);
    IGestalt configGestalt = new SpockConfigurationGestalt(configurations, blueprint, slotFactories);
    gestaltBuilder.build(configGestalt);
  }
}
