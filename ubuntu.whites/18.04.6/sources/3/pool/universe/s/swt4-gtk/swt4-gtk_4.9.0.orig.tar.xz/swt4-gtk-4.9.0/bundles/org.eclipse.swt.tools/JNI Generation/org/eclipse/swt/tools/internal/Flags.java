/*******************************************************************************
 * Copyright (c) 2005, 2012 IBM Corporation and others.
 *
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License 2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.swt.tools.internal;

public interface Flags {

	public static final String FLAG_NO_GEN = "no_gen";
	public static final String FLAG_NO_IN = "no_in";
	public static final String FLAG_NO_OUT = "no_out";
	public static final String FLAG_NO_WINCE = "no_wince";
	public static final String FLAG_CRITICAL = "critical";
	public static final String FLAG_INIT = "init";
	public static final String FLAG_STRUCT = "struct";
	public static final String FLAG_UNICODE = "unicode";
	public static final String FLAG_SENTINEL = "sentinel";
	public static final String FLAG_CPP = "cpp";
	public static final String FLAG_M = "m";
	public static final String FLAG_NEW = "new";
	public static final String FLAG_DELETE ="delete";
	public static final String FLAG_CONST = "const";
	public static final String FLAG_CAST = "cast";
	public static final String FLAG_DYNAMIC = "dynamic";
	public static final String FLAG_TRYCATCH = "trycatch";
	public static final String FLAG_JNI = "jni";
	public static final String FLAG_ADDRESS = "address";
	public static final String FLAG_GCNEW = "gcnew";
	public static final String FLAG_OBJECT = "object";
	public static final String FLAG_SETTER = "setter";
	public static final String FLAG_GETTER = "getter";
	public static final String FLAG_ADDER = "adder";
}
