/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * Contributor(s):
 *
 * IBM
 * -  Binding to permit interfacing between Cairo and SWT
 * -  Copyright (C) 2005, 2012 IBM Corp.  All Rights Reserved.
 *
 * ***** END LICENSE BLOCK ***** */

/* Libraries for dynamic loaded functions */
#ifdef AIX
#define LIB_CAIRO "libcairo.a(libcairo.so.2)"
#elif _WIN32
#define LIB_CAIRO "libcairo-2.dll"
#else
#define LIB_CAIRO "libcairo.so.2"
#endif

#define cairo_pdf_surface_set_size_LIB LIB_CAIRO
#define cairo_ps_surface_set_size_LIB LIB_CAIRO
#define cairo_region_num_rectangles_LIB LIB_CAIRO
#define cairo_region_contains_point_LIB LIB_CAIRO
#define cairo_region_copy_LIB LIB_CAIRO
#define cairo_region_get_rectangle_LIB LIB_CAIRO
#define cairo_surface_set_device_scale_LIB LIB_CAIRO
#define cairo_surface_get_device_scale_LIB LIB_CAIRO

#ifdef CAIRO_HAS_XLIB_SURFACE
#define cairo_xlib_surface_get_height_LIB LIB_CAIRO
#define cairo_xlib_surface_get_width_LIB LIB_CAIRO 
#endif
