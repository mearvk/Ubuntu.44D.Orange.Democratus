/*
 * $Id: package-info.java 1294457 2012-02-28 04:45:29Z nlebas $
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
/**
 * Classes to allow rendering of a template (described by its path) 
 * in a uniform way.
 * 
 * Besides the top level interface {@link org.apache.tiles.request.render.Renderer},
 * the package contains:
 * <ul>
 * <li>trivial examples: {@link org.apache.tiles.request.render.StringRenderer} 
 * and {@link org.apache.tiles.request.render.DispatchRenderer}.
 * <li>usual design patterns: {@link org.apache.tiles.request.render.ChainedDelegateRenderer},
 * {@link org.apache.tiles.request.render.PublisherRenderer}, and 
 * {@link org.apache.tiles.request.render.RendererFactory}.
 * </ul>
 */
package org.apache.tiles.request.render;
