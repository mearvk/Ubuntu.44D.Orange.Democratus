/*
 * $Id$
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.tiles.request.locale;

import java.util.Locale;

import junit.framework.TestCase;

/**
 * Tests {@link LocaleUtil}.
 *
 * @version $Rev$ $Date$
 */
public class LocaleUtilTest extends TestCase {

    /**
     * Test method for {@link LocaleUtil#getParentLocale(Locale)}.
     */
    public void testGetParentLocale() {
        assertNull("The parent locale of NULL_LOCALE is not correct",
                LocaleUtil.getParentLocale(Locale.ROOT));
        assertEquals("The parent locale of 'en' is not correct",
                Locale.ROOT, LocaleUtil
                        .getParentLocale(Locale.ENGLISH));
        assertEquals("The parent locale of 'en_US' is not correct",
                Locale.ENGLISH, LocaleUtil.getParentLocale(Locale.US));
        Locale locale = new Locale("es", "ES", "Traditional_WIN");
        Locale parentLocale = new Locale("es", "ES");
        assertEquals("The parent locale of 'es_ES_Traditional_WIN' is not correct",
                parentLocale, LocaleUtil.getParentLocale(locale));
    }
}
