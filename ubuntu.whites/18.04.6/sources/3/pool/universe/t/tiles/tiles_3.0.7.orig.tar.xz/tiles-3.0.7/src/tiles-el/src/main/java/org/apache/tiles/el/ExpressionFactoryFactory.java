/*
 * $Id: ExpressionFactoryFactory.java 816924 2009-09-19 13:45:40Z apetrelli $
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.tiles.el;

import javax.el.ExpressionFactory;

/**
 * Interface to define a factory of {@link ExpressionFactory}.
 *
 * @version $Rev: 816924 $ $Date: 2009-09-19 23:45:40 +1000 (Sat, 19 Sep 2009) $
 * @since 2.2.1
 */
public interface ExpressionFactoryFactory {

    /**
     * Returns the expression factory to use.
     *
     * @return The expression factory.
     * @since 2.2.1
     */
    ExpressionFactory getExpressionFactory();
}
