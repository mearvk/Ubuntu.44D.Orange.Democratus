/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.uima.lucas.indexer.analysis;

import java.io.IOException;
import java.util.Properties;

import org.apache.lucene.analysis.TokenFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.snowball.SnowballFilter;

public class SnowballFilterFactory implements TokenFilterFactory {

	public static final String STEMMER_NAME_PARAMETER = "stemmerName";
  private static final String DEFAULT_STEMMER_NAME = "English";

	public TokenFilter createTokenFilter(TokenStream tokenStream,
			Properties properties) throws IOException {

    String stemmerName = properties.getProperty(STEMMER_NAME_PARAMETER);
    if( stemmerName == null )
      stemmerName = DEFAULT_STEMMER_NAME;
    
		return new SnowballFilter(tokenStream, stemmerName);
	}

	public void preloadResources(Properties properties) throws IOException {
	}

}
