/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.uima.annotator.regex.impl;

import java.util.HashMap;

import org.apache.uima.annotator.regex.RegexVariables;

/**
 * Implementation of the RegexVariables interface
 */
public class RegexVariables_impl implements RegexVariables {

   private HashMap<String, String> variables;

   public RegexVariables_impl() {
      this.variables = new HashMap<String, String>();
   }

   /* (non-Javadoc)
    * @see org.apache.uima.annotator.regex.Variables#addVariable(java.lang.String, java.lang.String)
    */
   public void addVariable(String varName, String varValue) {
      this.variables.put(varName, varValue);
   }

   /* (non-Javadoc)
    * @see org.apache.uima.annotator.regex.Variables#getVariableValue(java.lang.String)
    */
   public String getVariableValue(String varName) {
      return this.variables.get(varName);
   }

}
