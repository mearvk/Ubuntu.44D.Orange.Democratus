/* $Id: version.h.in,v 1.4 2005/07/16 20:44:30 rocky Exp $ */
/** \file version.h 
 *  \brief  A file simply containing the library version number.
 */

/*! LIBVCD_VERSION can as a string in programs to show what version is used. */
#define LIBVCD_VERSION "0.7.24"

/*! LIBVCD_VERSION_NUM  can be used for testing in the C preprocessor */
#define LIBVCD_VERSION_NUM 24

