var bar = 42;
