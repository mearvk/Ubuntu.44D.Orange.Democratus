var multiple = 42;
