var spaces = 42;
