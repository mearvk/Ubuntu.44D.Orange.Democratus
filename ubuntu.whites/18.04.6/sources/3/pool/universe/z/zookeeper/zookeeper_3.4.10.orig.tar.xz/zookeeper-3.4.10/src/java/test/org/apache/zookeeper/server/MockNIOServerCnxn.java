/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.zookeeper.server;

import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.io.IOException;

public class MockNIOServerCnxn extends NIOServerCnxn {

    public MockNIOServerCnxn(ZooKeeperServer zk, SocketChannel sock,
                         SelectionKey sk, NIOServerCnxnFactory factory)
                         throws IOException {
        super(zk, sock, sk, factory);
    }

    /**
     * Handles read/write IO on connection.
     */
    public void doIO(SelectionKey k) throws InterruptedException {
        super.doIO(k);
    }

     @Override
     protected boolean isSocketOpen() {
         return true;
     }

}
