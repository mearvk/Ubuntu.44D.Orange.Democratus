
class OtherClass:
    pass
