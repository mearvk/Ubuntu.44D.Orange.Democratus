@echo off
echo bar
