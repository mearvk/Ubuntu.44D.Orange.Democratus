x ** delete y
