function a({}) {}
