export {default} from "foo";
