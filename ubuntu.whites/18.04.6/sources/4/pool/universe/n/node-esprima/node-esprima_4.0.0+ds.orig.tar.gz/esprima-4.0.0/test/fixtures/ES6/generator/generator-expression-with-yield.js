(function*() { yield 3; })
