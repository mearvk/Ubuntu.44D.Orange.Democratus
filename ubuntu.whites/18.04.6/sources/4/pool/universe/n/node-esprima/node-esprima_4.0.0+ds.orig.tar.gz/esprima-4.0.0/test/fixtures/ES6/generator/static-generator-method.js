class Foo { static *foo() {} }
