var 𞸆_$
