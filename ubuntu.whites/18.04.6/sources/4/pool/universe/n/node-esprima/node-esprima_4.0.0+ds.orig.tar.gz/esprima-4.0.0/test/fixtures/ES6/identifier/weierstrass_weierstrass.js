var ℘\u2118
