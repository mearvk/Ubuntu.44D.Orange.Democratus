import {default as foo}
