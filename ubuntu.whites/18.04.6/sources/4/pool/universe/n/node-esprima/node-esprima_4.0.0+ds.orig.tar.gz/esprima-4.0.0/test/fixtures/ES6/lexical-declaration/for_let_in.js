for (let in x) {}
