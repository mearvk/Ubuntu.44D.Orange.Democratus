function f() {
    new.target;
}
