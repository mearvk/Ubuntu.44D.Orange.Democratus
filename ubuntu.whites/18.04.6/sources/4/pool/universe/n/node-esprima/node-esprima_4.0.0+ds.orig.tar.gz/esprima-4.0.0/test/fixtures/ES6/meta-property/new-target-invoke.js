function f() {
    new.target();
}
