x = { set f(...y) {} }
