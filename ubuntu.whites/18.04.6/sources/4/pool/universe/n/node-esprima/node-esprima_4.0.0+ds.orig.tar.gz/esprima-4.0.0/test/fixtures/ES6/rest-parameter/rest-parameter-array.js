function f(...[a]) {}
