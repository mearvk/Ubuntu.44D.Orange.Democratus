function f(...{a}) {}
