f(...x, y, z);
