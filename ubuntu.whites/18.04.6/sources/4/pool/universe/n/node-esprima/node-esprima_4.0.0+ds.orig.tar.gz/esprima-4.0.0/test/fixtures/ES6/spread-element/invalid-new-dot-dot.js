new f(..g);
