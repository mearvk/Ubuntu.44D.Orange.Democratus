new f(....g);
