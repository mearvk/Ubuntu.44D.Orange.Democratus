new f(... ... g);
