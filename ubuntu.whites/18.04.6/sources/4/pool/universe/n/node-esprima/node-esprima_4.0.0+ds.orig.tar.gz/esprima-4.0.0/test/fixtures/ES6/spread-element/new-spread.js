new f(...g);
