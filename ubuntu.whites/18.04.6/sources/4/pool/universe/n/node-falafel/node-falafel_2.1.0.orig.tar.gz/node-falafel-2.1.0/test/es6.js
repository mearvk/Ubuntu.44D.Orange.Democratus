var falafel = require('../');
var test = require('tape');

test('generators', function (t) {
    t.plan(1);
    
    var src = 'console.log((function * () { yield 3 })().next().value)';
    var output = falafel(src, { ecmaVersion: 6 }, function (node) {
        if (node.type === 'Literal') {
            node.update('555');
        }
    });
    Function(['console'],output)({log:log});
    function log (n) { t.equal(n, 555) }
});
