module.exports = [[Infinity]];
