module.exports = ['arguments'];
