module.exports = [function * gen() {}]
