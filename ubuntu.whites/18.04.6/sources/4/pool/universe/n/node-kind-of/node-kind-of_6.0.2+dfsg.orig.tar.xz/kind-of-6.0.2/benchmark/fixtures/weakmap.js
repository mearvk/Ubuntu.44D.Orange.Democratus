module.exports = [new WeakMap()];
