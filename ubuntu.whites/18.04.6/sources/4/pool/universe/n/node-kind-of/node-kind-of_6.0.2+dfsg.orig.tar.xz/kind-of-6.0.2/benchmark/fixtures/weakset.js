module.exports = [new WeakSet()];
