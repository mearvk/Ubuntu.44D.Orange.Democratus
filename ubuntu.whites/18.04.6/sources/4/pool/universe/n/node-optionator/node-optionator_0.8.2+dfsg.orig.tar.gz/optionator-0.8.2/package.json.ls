name: 'optionator'
version: '0.8.2'

author: 'George Zahariev <z@georgezahariev.com>'
description: 'option parsing and help generation'
homepage: 'https://github.com/gkz/optionator'
keywords:
  'options'
  'flags'
  'option parsing'
  'cli'
files:
  'lib'
  'README.md'
  'LICENSE'
main: './lib/'

bugs: 'https://github.com/gkz/optionator/issues'
license: 'MIT'
engines:
  node: '>= 0.8.0'
repository:
  type: 'git'
  url: 'git://github.com/gkz/optionator.git'
scripts:
  test: "make test"

dependencies:
  'prelude-ls': '~1.1.2'
  'deep-is': '~0.1.3'
  wordwrap: '~1.0.0'
  'type-check': '~0.3.2'
  levn: '~0.3.0'
  'fast-levenshtein': '~2.0.4'

dev-dependencies:
  livescript: '~1.5.0'
  mocha: '~3.0.2'
  istanbul: '~0.4.1'
