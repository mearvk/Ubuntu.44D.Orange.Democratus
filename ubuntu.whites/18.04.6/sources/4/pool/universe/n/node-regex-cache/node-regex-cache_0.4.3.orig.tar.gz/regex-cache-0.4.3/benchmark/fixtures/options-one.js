module.exports = [{ a: true }];
