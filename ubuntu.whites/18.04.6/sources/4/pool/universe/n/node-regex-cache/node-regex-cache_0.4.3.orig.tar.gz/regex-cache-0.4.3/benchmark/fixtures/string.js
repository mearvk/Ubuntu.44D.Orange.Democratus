module.exports = ['foo'];
