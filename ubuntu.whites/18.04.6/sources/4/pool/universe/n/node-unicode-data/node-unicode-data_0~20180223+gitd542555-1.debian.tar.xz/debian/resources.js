var resources = [
    {
        'version': '10.0.0',
        'main': '/usr/share/unicode/UnicodeData.txt',
        'scripts': '/usr/share/unicode/Scripts.txt',
        'script-extensions': '/usr/share/unicode/ScriptExtensions.txt',
        'blocks': '/usr/share/unicode/Blocks.txt',
        'properties': '/usr/share/unicode/PropList.txt',
        'derived-core-properties': '/usr/share/unicode/DerivedCoreProperties.txt',
        'derived-normalization-properties': '/usr/share/unicode/DerivedNormalizationProps.txt',
        'composition-exclusions': '/usr/share/unicode/CompositionExclusions.txt',
        'case-folding': '/usr/share/unicode/CaseFolding.txt',
        'bidi-mirroring': '/usr/share/unicode/BidiMirroring.txt',
        'bidi-brackets': '/usr/share/unicode/BidiBrackets.txt',
        'line-break': '/usr/share/unicode/LineBreak.txt',
        'word-break': '/usr/share/unicode/auxiliary/WordBreakProperty.txt'
    }
];

module.exports = resources;


