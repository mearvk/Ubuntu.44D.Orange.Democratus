"""An empty module."""
