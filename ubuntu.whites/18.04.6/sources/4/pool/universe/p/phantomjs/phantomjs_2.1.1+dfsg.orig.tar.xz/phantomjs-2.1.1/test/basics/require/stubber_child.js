exports.stubbed = require('stubbed');
