#!/bin/sh
#
#  Copyright (C) 2011 Harald Sitter <sitter@kde.org>
#
#  This library is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published by
#  the Free Software Foundation, either version 2.1 or 3 of the License.
#
#  This library is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with this library.  If not, see <http://www.gnu.org/licenses/>.

if [ -z $GST_DEBUG_DUMP_DOT_DIR ]; then
    GST_DEBUG_DUMP_DOT_DIR="."
fi

for i in `ls ${GST_DEBUG_DUMP_DOT_DIR}/*.dot`; do
    echo "processing ${i}"
    dot -Tpng -o${i}.png < ${i}
done
