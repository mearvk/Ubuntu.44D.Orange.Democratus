Python Prompt Toolkit
=====================

|Build Status|  |PyPI|

``prompt_toolkit`` is a library for building powerful interactive command lines
and terminal applications in Python.

Read the `documentation on readthedocs
<http://python-prompt-toolkit.readthedocs.io/en/stable/>`_.


Ptpython
********

`ptpython <http://github.com/jonathanslenders/ptpython/>`_ is an interactive
Python Shell, build on top of prompt_toolkit.

.. image :: https://github.com/jonathanslenders/python-prompt-toolkit/raw/master/docs/images/ptpython.png


prompt_toolkit features
***********************

``prompt_toolkit`` could be a replacement for `GNU readline
<http://cnswww.cns.cwru.edu/php/chet/readline/rltop.html>`_, but it can be much
more than that.

Some features:

- Pure Python.
- Syntax highlighting of the input while typing. (For instance, with a Pygments lexer.)
- Multi-line input editing.
- Advanced code completion.
- Both Emacs and Vi key bindings. (Similar to readline.)
- Even some advanced Vi functionality, like named registers and digraphs.
- Reverse and forward incremental search.
- Runs on all Python versions from 2.6 up to 3.5.
- Works well with Unicode double width characters. (Chinese input.)
- Selecting text for copy/paste. (Both Emacs and Vi style.)
- Support for `bracketed paste <https://cirw.in/blog/bracketed-paste>`_.
- Mouse support for cursor positioning and scrolling.
- Auto suggestions. (Like `fish shell <http://fishshell.com/>`_.)
- Multiple input buffers.
- No global state.
- Lightweight, the only dependencies are Pygments, six and wcwidth.
- Runs on Linux, OS X, FreeBSD, OpenBSD and Windows systems.
- And much more...

Feel free to create tickets for bugs and feature requests, and create pull
requests if you have nice patches that you would like to share with others.


About Windows support
*********************

``prompt_toolkit`` is cross platform, and everything that you build on top
should run fine on both Unix and Windows systems. On Windows, it uses a
different event loop (``WaitForMultipleObjects`` instead of ``select``), and
another input and output system. (Win32 APIs instead of pseudo-terminals and
VT100.)

It's worth noting that the implementation is a "best effort of what is
possible". Both Unix and Windows terminals have their limitations. But in
general, the Unix experience will still be a little better.

For Windows, it's recommended to use either `cmder
<http://cmder.net/>`_ or `conemu <https://conemu.github.io/>`_.


Installation
************

::

    pip install prompt_toolkit

For Conda, do:

::

    conda install -c https://conda.anaconda.org/conda-forge prompt_toolkit


Getting started
***************

The most simple example of the library would look like this:

.. code:: python

    from prompt_toolkit import prompt

    if __name__ == '__main__':
        answer = prompt('Give me some input: ')
        print('You said: %s' % answer)

For more complex examples, have a look in the ``examples`` directory. All
examples are chosen to demonstrate only one thing. Also, don't be afraid to
look at the source code. The implementation of the ``prompt`` function could be
a good start.

Note for Python 2: all strings are expected to be unicode strings. So, either
put a small ``u`` in front of every string or put ``from __future__ import
unicode_literals`` at the start of the above example.


Projects using prompt_toolkit
*****************************

Shells:

- `ptpython <http://github.com/jonathanslenders/ptpython/>`_: Python REPL
- `ptpdb <http://github.com/jonathanslenders/ptpdb/>`_: Python debugger (pdb replacement)
- `pgcli <http://pgcli.com/>`_: Postgres client.
- `mycli <http://mycli.net>`_: MySql client.
- `wharfee <http://wharfee.com/>`_: A Docker command line.
- `xonsh <http://xon.sh/>`_: A Python-ish, BASHwards-compatible shell.
- `saws <https://github.com/donnemartin/saws>`_: A Supercharged AWS Command Line Interface.
- `cycli <https://github.com/nicolewhite/cycli>`_:  A Command Line Interface for Cypher.
- `crash <https://github.com/crate/crash>`_:  Crate command line client.
- `vcli <https://github.com/dbcli/vcli>`_: Vertica client.
- `aws-shell <https://github.com/awslabs/aws-shell>`_: An integrated shell for working with the AWS CLI.
- `softlayer-python <https://github.com/softlayer/softlayer-python>`_: A command-line interface to manage various SoftLayer products and services.
- `ipython <http://github.com/ipython/ipython/>`_: The IPython REPL
- `click-repl <https://github.com/click-contrib/click-repl>`_: Subcommand REPL for click apps.
- `haxor-news <https://github.com/donnemartin/haxor-news>`_: A Hacker News CLI.
- `gitsome <https://github.com/donnemartin/gitsome>`_: A Git/Shell Autocompleter with GitHub Integration.
- `http-prompt <https://github.com/eliangcs/http-prompt>`_: An interactive command-line HTTP client.
- `coconut <http://coconut-lang.org/>`_: Functional programming in Python.
- `Ergonomica <https://ergonomica.github.io/>`_: A Bash alternative written in Python.
- `Kube-shell <https://github.com/cloudnativelabs/kube-shell>`_: Kubernetes shell: An integrated shell for working with the Kubernetes CLI

Full screen applications:

- `pymux <http://github.com/jonathanslenders/pymux/>`_: A terminal multiplexer (like tmux) in pure Python.
- `pyvim <http://github.com/jonathanslenders/pyvim/>`_: A Vim clone in pure Python.

(Want your own project to be listed here? Please create a GitHub issue.)


Philosophy
**********

The source code of ``prompt_toolkit`` should be readable, concise and
efficient. We prefer short functions focussing each on one task and for which
the input and output types are clearly specified. We mostly prefer composition
over inheritance, because inheritance can result in too much functionality in
the same object. We prefer immutable objects where possible (objects don't
change after initialisation). Reusability is important. We absolutely refrain
from having a changing global state, it should be possible to have multiple
independent instances of the same code in the same process. The architecture
should be layered: the lower levels operate on primitive operations and data
structures giving -- when correctly combined -- all the possible flexibility;
while at the higher level, there should be a simpler API, ready-to-use and
sufficient for most use cases. Thinking about algorithms and efficiency is
important, but avoid premature optimization.


Special thanks to
*****************

- `Pygments <http://pygments.org/>`_: Syntax highlighter.
- `wcwidth <https://github.com/jquast/wcwidth>`_: Determine columns needed for a wide characters.

.. |Build Status| image:: https://api.travis-ci.org/jonathanslenders/python-prompt-toolkit.svg?branch=master
    :target: https://travis-ci.org/jonathanslenders/python-prompt-toolkit#

.. |PyPI| image:: https://img.shields.io/pypi/v/prompt_toolkit.svg
    :target: https://pypi.python.org/pypi/prompt-toolkit/
    :alt: Latest Version
