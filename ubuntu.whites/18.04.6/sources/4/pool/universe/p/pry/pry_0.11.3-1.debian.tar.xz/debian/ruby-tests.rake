require 'gem2deb/rake/spectask'

ENV['EDITOR'] = '/bin/true'

Gem2Deb::Rake::RSpecTask.new do |spec|
  spec.pattern = './spec/**/*_spec.rb'
end
