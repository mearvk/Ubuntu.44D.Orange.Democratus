"""PyDoctor's test suite."""
