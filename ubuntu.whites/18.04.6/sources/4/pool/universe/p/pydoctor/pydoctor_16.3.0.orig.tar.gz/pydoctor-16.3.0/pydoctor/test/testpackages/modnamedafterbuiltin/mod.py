class Dict(dict):
    pass
