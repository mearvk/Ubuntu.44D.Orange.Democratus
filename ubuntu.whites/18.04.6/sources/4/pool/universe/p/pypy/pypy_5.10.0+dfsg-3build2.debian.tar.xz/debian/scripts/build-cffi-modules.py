#!/usr/bin/env python

import os
import sys
sys.path.insert(0, '.')

import py.path

from pypy.tool.build_cffi_imports import create_cffi_import_libraries


class FakeOptions(object):
    def __getattr__(self, name):
        # Build all the modules
        if name.startswith('no_'):
            return False

        raise AttributeError()


os.environ['LD_LIBRARY_PATH'] = 'pypy/goal'
pypy_c = py.path.local('pypy/goal/pypy-c')
options = FakeOptions()
basedir = py.path.local('.')
create_cffi_import_libraries(pypy_c, options, basedir)
