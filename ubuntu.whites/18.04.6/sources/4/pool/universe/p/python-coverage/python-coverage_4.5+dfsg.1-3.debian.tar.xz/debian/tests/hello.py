print('Hello, world!")
