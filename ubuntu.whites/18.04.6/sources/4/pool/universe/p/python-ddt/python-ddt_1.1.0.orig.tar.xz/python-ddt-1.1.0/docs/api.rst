API
===

.. automodule:: ddt
    :members:
