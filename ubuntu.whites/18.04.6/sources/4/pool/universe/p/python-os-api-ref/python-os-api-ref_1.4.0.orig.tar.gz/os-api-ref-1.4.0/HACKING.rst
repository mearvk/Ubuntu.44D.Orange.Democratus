os-api-ref Style Commandments
===============================================

Read the OpenStack Style Commandments http://docs.openstack.org/developer/hacking/
