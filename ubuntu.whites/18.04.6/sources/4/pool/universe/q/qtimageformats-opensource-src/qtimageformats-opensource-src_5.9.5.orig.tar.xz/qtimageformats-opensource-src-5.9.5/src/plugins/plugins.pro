TEMPLATE = subdirs
SUBDIRS = imageformats
