TEMPLATE = subdirs
SUBDIRS += util
