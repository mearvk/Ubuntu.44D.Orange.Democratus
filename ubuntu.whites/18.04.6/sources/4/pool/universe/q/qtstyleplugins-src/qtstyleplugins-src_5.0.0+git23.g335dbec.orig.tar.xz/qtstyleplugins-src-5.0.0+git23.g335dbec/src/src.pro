TEMPLATE = subdirs
SUBDIRS = plugins
