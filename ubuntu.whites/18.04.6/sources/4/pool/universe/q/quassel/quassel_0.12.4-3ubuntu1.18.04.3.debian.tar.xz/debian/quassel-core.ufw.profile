[Quassel]
title=Quassel Core
description=Quassel IRC core/server component
ports=4242/tcp
