DROP TABLE coreinfo
