DROP TABLE ircserverold
