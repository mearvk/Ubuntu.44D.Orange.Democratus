DROP TABLE networkold
