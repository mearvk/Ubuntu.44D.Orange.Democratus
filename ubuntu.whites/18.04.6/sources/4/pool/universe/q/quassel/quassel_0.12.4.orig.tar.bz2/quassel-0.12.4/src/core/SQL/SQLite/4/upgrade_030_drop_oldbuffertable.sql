DROP TABLE bufferold
