
class A
rule
end
