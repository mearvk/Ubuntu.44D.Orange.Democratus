require 'rspec/autorun'

$: << 'ext/mri' << 'lib' << 'spec' << '.'

Dir['spec/**/*.rb'].each { |f| require f }
