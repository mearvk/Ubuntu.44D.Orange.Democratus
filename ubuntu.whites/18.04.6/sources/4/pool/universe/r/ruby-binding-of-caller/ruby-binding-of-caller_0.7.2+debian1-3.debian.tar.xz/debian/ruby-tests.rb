def run(cmdline)
  puts cmdline
  system(cmdline) || exit(1)
end

ruby = RbConfig::CONFIG['ruby_install_name']
run("#{ruby} -S bacon test/test_*.rb")
