require 'gem2deb/rake/spectask'

Gem2Deb::Rake::RSpecTask.new do |spec|
  spec.rspec_opts = '--color --backtrace --format documentation --seed 1'
  spec.pattern = './spec/concurrent/*_spec.rb'
end
