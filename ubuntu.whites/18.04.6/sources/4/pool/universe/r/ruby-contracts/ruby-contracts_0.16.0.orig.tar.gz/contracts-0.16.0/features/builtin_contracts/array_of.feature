Feature: ArrayOf (TODO)
