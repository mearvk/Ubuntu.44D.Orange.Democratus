Feature: Enum (TODO)
