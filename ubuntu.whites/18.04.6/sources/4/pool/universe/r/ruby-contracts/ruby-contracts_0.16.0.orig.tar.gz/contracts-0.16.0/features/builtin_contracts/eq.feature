Feature: Eq (TODO)
