Feature: HashOf (TODO)
