Feature: RangeOf (TODO)
