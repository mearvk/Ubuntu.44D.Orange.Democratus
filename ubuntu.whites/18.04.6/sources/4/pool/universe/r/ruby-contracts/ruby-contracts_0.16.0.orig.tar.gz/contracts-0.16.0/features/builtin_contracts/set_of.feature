Feature: SetOf (TODO)
