require "bacon"

Dir.glob("spec/**/redis*_spec.rb").each { |f| require f }
