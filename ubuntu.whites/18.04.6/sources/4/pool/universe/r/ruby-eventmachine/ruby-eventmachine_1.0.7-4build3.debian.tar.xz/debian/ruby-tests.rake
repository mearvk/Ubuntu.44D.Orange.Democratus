require 'gem2deb/rake/testtask'

disabled_tests= [
  'tests/test_idle_connection.rb',
  'tests/test_get_sock_opt.rb',
  'tests/test_set_sock_opt.rb',
]

ENV['TESTOPTS'] = '-v'

Gem2Deb::Rake::TestTask.new do |t|
  t.libs = ['tests']
  t.test_files = FileList['tests/**/test_*.rb'] - disabled_tests
  t.verbose = true
end
