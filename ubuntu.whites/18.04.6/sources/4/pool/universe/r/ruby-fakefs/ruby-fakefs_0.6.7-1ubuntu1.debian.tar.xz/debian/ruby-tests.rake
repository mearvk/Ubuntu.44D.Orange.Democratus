require 'rake/testtask'
# require 'rspec/core/rake_task'

Rake::TestTask.new do |t|
  t.libs << 'test'
  t.test_files = FileList['test/**/*test.rb']
end

# # TODO: run rspec tests once ruby-rspec is upgraded to rspec 3
# desc 'Run specs'
# RSpec::Core::RakeTask.new

task default: [:test]
