exec("sleep 10;script/test default em_http em_synchrony excon logger \
httpclient net_http_persistent net_http_test rack test_middleware")

# uncomment this when all tests can be run
#exec("script/test")

# TODO:

# typhoeus >=0.3 already provides a faraday adapter
# https://github.com/lostisland/faraday/issues/274
#exec("script/test typhoeus")
