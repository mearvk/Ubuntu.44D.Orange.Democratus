require 'rspec/autorun'
Dir.glob('./spec/*/*_spec.rb').each do |spec|
  require spec
end
