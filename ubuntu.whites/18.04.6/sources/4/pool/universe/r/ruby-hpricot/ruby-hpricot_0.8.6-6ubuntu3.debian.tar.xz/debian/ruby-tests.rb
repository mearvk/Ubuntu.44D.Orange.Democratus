$: << 'test'
Encoding.default_external = "UTF-8"
Dir['test/test*.rb'].each { |f| require f }
