require 'rspec/core/rake_task'

task :default do
  sh 'cp spec/configuration.yml.example spec/configuration.yml'
  sh 'cp spec/my.cnf.example spec/my.cnf'

  ruby = RbConfig::CONFIG['ruby_install_name']
  sh "./debian/start_mysqld_and_run.sh #{ruby} -S rspec"
end
