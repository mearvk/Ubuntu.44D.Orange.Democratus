require "rspec/autorun"
$LOAD_PATH.delete(File.expand_path("../../lib",__FILE__))

RSpec.configure do |c|
  c.filter_run_excluding :unresolved => true
end

Dir['./spec/*_spec.rb'].each { |f| require f }
