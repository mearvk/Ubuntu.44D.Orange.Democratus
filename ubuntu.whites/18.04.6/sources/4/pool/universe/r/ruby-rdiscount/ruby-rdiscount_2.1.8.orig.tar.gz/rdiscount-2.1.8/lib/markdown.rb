require 'rdiscount'
