require 'gem2deb/rake/spectask'

Gem2Deb::Rake::RSpecTask.new do |spec|
  spec.rspec_opts = '-rspec_helper'
  spec.pattern = './spec/**/*_spec.rb'
end
