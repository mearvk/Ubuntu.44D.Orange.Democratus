exec('bin/shindo')
