Spruz = Tins
