#!/bin/sh
if [ -z "$1" ]
  then
    echo "please specify the build directory to clean up"
    exit 1
fi
rm -rf debian/$1/

rm -f debian/files

