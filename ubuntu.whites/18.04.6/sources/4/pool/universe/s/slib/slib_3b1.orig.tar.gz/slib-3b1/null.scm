;;; Stub for AGGREGATE feature.
