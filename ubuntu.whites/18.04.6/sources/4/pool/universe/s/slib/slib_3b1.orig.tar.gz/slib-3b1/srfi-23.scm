(define error slib:error)
