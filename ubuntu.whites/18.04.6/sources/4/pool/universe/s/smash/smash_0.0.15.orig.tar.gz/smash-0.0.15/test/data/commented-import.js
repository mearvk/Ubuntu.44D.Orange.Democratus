// import "foo";
var bar;
