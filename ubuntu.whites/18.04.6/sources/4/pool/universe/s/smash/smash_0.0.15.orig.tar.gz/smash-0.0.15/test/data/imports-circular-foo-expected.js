var bar;
var foo;
