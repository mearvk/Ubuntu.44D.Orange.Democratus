var foo;
var bar;
