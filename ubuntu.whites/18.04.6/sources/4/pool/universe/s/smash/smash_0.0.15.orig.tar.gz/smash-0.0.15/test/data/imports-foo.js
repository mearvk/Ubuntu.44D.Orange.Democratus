import "foo";
var bar;
