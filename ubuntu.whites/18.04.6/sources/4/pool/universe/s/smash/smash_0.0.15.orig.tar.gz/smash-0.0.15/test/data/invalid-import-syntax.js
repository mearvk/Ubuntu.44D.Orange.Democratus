import foo;
var bar;
