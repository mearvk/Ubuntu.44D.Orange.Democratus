import 'foo";
var bar;
