/*
var foo;
*/
var bar;
