/*
import "foo";
*/
var bar;
