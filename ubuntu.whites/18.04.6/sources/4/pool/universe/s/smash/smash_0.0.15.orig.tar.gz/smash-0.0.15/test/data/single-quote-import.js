import 'foo';
var bar;
