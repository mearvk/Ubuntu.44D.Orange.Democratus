#! /bin/sh

downloaded_package=$(basename $3)
version=$2

mydir=$(pwd)
cd ..
tar xzf $downloaded_package
mv sympy-sympy-$version sympy-$version
tar czf $downloaded_package sympy-$version

cd $mydir
echo "Created ../$downloaded_package and ../sympy-$version"

