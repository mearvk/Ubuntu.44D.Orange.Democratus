run
bt full
quit
