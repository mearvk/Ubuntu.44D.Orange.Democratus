:orphan:

tox manual page
===============

Synopsis
--------

**tox** [*options*]  [*args*]


Description
-----------

:program:`tox` is a generic `virtualenv`_ management and test command line
tool you can use for:

 * checking that your package installs correctly with different Python
   versions and interpreters
 * running your tests in each of the environments, configuring your test tool
   of choice
 * acting as a front-end to Continuous Integration servers, greatly reducing
   boilerplate and merging CI and shell-based testing


Options
-------

-h, --help      Show the help message and exit.
--version       Report version information to stdout.
-v              Increase the verbosity of reporting output.
--showconfig    Show configuration information.
-c <path>       Use the specified path as the configuration file.
-e <envlist>    Work against specified environments.  ``ALL`` selects all
                available environments.
--notest        Skip invoking test commands.
--sdistonly     Only perform the sdist packaging activity.
-i <url>        Set indexserver url (if ``url`` is of form ``name=url`` set
                the url for the ``name`` indexserver, specifically)
-r, --recreate  Force recreation of virtual environments.


.. _`virtualenv`: http://pypi.python.org/pypi/virtualenv
