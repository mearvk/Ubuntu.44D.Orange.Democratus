# Installation
> `npm install --save @types/jsdom`

# Summary
This package contains type definitions for jsdom (https://github.com/tmpvar/jsdom).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/jsdom

Additional Details
 * Last updated: Mon, 13 Feb 2017 18:30:04 GMT
 * Dependencies: node, jquery
 * Global values: none

# Credits
These definitions were written by Asana <https://asana.com>.
