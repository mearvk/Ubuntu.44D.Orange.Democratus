# Installation
> `npm install --save @types/mathjax`

# Summary
This package contains type definitions for MathJax (https://github.com/mathjax/MathJax).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/types-2.0/mathjax

Additional Details
 * Last updated: Fri, 23 Sep 2016 17:58:35 GMT
 * File structure: Global
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: MathJax

# Credits
These definitions were written by Roland Zwaga <https://github.com/rolandzwaga>.
