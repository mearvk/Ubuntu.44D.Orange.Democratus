# Installation
> `npm install --save @types/semver`

# Summary
This package contains type definitions for semver (https://github.com/npm/node-semver).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/semver

Additional Details
 * Last updated: Mon, 13 Mar 2017 17:09:17 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Bart van der Schoor <https://github.com/Bartvds>.
