# Installation
> `npm install --save @types/shelljs`

# Summary
This package contains type definitions for ShellJS (http://shelljs.org).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/shelljs

Additional Details
 * Last updated: Fri, 28 Apr 2017 02:11:04 GMT
 * Dependencies: child_process, node
 * Global values: none

# Credits
These definitions were written by Niklas Mollenhauer <https://github.com/nikeee>.
