# Installation
> `npm install --save @types/sinon`

# Summary
This package contains type definitions for Sinon (http://sinonjs.org/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/sinon

Additional Details
 * Last updated: Tue, 16 May 2017 20:45:07 GMT
 * Dependencies: none
 * Global values: sinon

# Credits
These definitions were written by William Sears <https://github.com/mrbigdog2u>, Jonathan Little <https://github.com/rationull>, Lukas Spieß <https://github.com/lumaxis>, Nico Jansen <https://github.com/nicojs>.
