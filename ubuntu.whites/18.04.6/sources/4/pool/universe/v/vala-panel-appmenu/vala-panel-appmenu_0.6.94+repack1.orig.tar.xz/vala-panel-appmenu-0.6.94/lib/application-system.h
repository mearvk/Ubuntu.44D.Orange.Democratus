#ifndef APPLICATION_SYSTEM_H
#define APPLICATION_SYSTEM_H

#include <gio/gio.h>

G_BEGIN_DECLS

G_DECLARE_FINAL_TYPE(ApplicationSystem, application_system, APPMENU, SYSTEM, GObject)

G_END_DECLS

#endif
