# btdownloadheadless(1) completion                         -*- shell-script -*-

_btdownload()
{
    local cur prev words cword
    _init_completion || return

    case $prev in
        --responsefile|--saveas)
            _filedir
            return
            ;;
    esac

    if [[ "$cur" == -* ]]; then
        COMPREPLY=( $(compgen -W '--max_uploads --keepalive_interval
            --download_slice_size --request_backlog --max_message_length
            --ip --minport --maxport --responsefile --url --saveas --timeout
            --timeout_check_interval --max_slice_length --max_rate_period
            --bind --upload_rate_fudge --display_interval --rerequest_interval
            --min_peers --http_timeout --max_initiate --max_allow_in
            --check_hashes --max_upload_rate --snub_time --spew
            --rarest_first_cutoff --min_uploads --report_hash_failures' \
            -- "$cur") )
    else
        _filedir
    fi
} &&
complete -F _btdownload btdownloadheadless.py btdownloadcurses.py \
    btdownloadgui.py

# ex: filetype=sh
