/* Copyright (C) 2018-2019 Free Software Foundation, Inc.

   This file is part of GDB.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

   This was copied from the git://sourceware.org/git/binutils-gdb.git
   repository, file gdb/testsuite/gdb.dwarf2/varval.c.  */

/* Test program for DW_OP_GNU_variable_value.  */

int var_a = 8;
int var_b = 3;
int *var_p = &var_b;
struct { int a, b, c, d, e, f, g, h; } var_s = { 101, 102, 103, 104, 105, 106, 107, 108 };

int
main (void)
{
  asm ("main_label: .globl main_label");
  return 0;
}
