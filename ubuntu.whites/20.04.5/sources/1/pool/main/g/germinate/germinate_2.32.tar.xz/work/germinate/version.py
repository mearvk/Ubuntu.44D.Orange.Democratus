# Copyright (C) 2019 Canonical Ltd.
#
# Germinate is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 2, or (at your option) any
# later version.
#
# Germinate is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Germinate; see the file COPYING.  If not, write to the Free
# Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
# 02110-1301, USA.

from __future__ import print_function

try:
    try:
        from importlib.resources import read_binary as resource_bytes
    except ImportError:
        from pkg_resources import resource_string as resource_bytes
except ImportError:
    VERSION = 'local'
else:
    VERSION = resource_bytes(
        'germinate', 'version.txt').decode('UTF-8').rstrip('\n')
