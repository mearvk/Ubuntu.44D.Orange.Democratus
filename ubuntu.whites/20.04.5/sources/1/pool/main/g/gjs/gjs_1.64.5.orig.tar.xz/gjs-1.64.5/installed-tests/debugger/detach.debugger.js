print('hi');
