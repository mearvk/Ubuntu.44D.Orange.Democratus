/* exported mockFunction */
function mockFunction() {}
