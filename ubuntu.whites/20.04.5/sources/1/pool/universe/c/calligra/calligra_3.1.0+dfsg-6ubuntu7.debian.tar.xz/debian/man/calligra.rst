=========
Calligra 
=========

------------------------
Calligra Document Opener
------------------------

:Author: This manual page was written by Adrien Grellier <perso@adrieng.fr> for the Debian project (but may be used by others).
:Date: |date|
:Manual section: 1
:Manual group: office


Synopsis
========

  calligra [options] FILES

Description
===========

Calligra is an integrated office suite for KDE. It offers a word processor,
a spreadsheet, a presentation program, graphics tools, and more.


Options
=======

**file**  File to open

Generic options:

--help                    Show help about options
--author                  Show author information
-v, --version             Show version information
--license                 Show license information

Options:

--apps                    Lists names of all available Calligra applications


SEE ALSO
=========

More detailed user documentation is available from **help:/calligra** (either enter this URL into Konqueror, or run **khelpcenter** *help:/calligra*).


.. |date| date:: %y %B %Y
