==============
CalligraSheets
==============

--------------------------------
Calligra Spreadsheet Application
--------------------------------

:Author: This manual page was written by Adrien Grellier <perso@adrieng.fr> for the Debian project (but may be used by others).
:Date: |date|
:Manual section: 1
:Manual group: office


Synopsis
========

  calligrasheets [options] [file]

Description
===========

Sheets is a powerful spreadsheet application.  It is scriptable and
provides both table-oriented sheets and support for complex mathematical
formulae and statistics. It is the successor of KSpread.

Options
=======

**file**  File to open

Generic options:

--help                    Show help about options
--author                  Show author information
-v, --version             Show version information
--license                 Show license information


SEE ALSO
=========

More detailed user documentation is available from **help:/calligrasheets** (either enter this URL into Konqueror, or run **khelpcenter** *help:/calligrasheets*).


.. |date| date:: %y %B %Y
