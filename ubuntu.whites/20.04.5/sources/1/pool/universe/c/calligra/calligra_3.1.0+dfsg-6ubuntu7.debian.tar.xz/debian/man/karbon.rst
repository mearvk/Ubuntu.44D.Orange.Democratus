=======
Karbon
=======

--------------------------------------
A Vector Graphics Drawing Application.
--------------------------------------

:Author: This manual page was written by Adrien Grellier <perso@adrieng.fr> for the Debian project (but may be used by others).
:Date: |date|
:Manual section: 1
:Manual group: office


Synopsis
========

karbon [options] [file]

Description
===========

Karbon is a vector drawing application with an user interface that is easy to
use, highly customizable and extensible. That makes Karbon a great application
for users starting to explore the world of vector graphics as well as for
artists wanting to create breathtaking vector art.

Options
=======

Generic options:

--help                    Show help about options
--author                  Show author information
-v, --version             Show version information
--license                 Show license information

Arguments:

**file**                  File to open


SEE ALSO
=========

More detailed user documentation is available from **help:/karbon** (either enter this URL into Konqueror, or run **khelpcenter** *help:/karbon*).


.. |date| date:: %y %B %Y
