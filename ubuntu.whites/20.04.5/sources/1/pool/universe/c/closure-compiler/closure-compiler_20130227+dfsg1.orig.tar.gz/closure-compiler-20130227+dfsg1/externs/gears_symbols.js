/*
 * Copyright 2009 Closure Compiler Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @fileoverview Global symbols injected by Google Gears.
 * @externs
 * @author nicksantos@google.com (Nick Santos)
 */

/**
 * Suppresses the compiler warning when multiple externs files declare the
 * google namespace.
 * @suppress {duplicate}
 * @noalias
 */
var google = {};

google.gears = {};

/** @type {GearsFactory} */
google.gears.factory;

/** @type {GearsWorkerPool} */
google.gears.workerPool;
