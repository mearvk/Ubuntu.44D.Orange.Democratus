# Basic test for Critclf
