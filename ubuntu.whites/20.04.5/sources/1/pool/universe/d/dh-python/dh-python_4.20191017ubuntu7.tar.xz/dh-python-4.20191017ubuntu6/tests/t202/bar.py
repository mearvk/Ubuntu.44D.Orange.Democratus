print("I'm bar")
