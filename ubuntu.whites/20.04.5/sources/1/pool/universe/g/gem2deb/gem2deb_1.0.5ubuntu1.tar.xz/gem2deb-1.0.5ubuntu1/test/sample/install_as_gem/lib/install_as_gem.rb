module InstallAsGem
end
