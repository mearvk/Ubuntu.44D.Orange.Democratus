#!/bin/sh

exec ./gradlew "$@"
