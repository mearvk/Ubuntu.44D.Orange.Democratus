public class Foo {
    
}
